package com.collegeevent.event;

import com.collegeevent.database.DatabaseManager;
import com.collegeevent.model.Event;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class EventManager {
    private DatabaseManager dbManager;
    
    /**
     * Constructor - Initialize with database manager
     * @param dbManager Database manager instance
     */
    public EventManager(DatabaseManager dbManager) {
        this.dbManager = dbManager;
    }
    
    /**
     * Create a new event
     * @param event The event object to be created
     * @return int The ID of the newly created event, or -1 if failed
     */
    public int createEvent(Event event) {
        int eventId = -1;
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "INSERT INTO events (event_name, description, event_date, start_time, "
                         + "end_time, venue_id, max_participants, organizer, status) "
                         + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, event.getEventName());
            pstmt.setString(2, event.getDescription());
            pstmt.setDate(3, event.getSqlEventDate());
            pstmt.setTime(4, event.getSqlStartTime());
            pstmt.setTime(5, event.getSqlEndTime());
            pstmt.setInt(6, event.getVenueId());
            pstmt.setInt(7, event.getMaxParticipants());
            pstmt.setString(8, event.getOrganizer());
            pstmt.setString(9, event.getStatus());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the ID of the newly inserted event
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    eventId = rs.getInt(1);
                }
            }
            
            pstmt.close();
            System.out.println("Event created successfully with ID: " + eventId);
            
        } catch (SQLException e) {
            System.out.println("Error creating event!");
            e.printStackTrace();
        }
        
        return eventId;
    }
    
    /**
     * Get an event by its ID
     * @param eventId The ID of the event to retrieve
     * @return Event object if found, null otherwise
     */
    public Event getEventById(int eventId) {
        Event event = null;
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM events WHERE event_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, eventId);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                event = new Event();
                event.setEventId(rs.getInt("event_id"));
                event.setEventName(rs.getString("event_name"));
                event.setDescription(rs.getString("description"));
                event.setEventDate(rs.getDate("event_date").toLocalDate());
                event.setStartTime(rs.getTime("start_time").toLocalTime());
                event.setEndTime(rs.getTime("end_time").toLocalTime());
                event.setVenueId(rs.getInt("venue_id"));
                event.setMaxParticipants(rs.getInt("max_participants"));
                event.setOrganizer(rs.getString("organizer"));
                event.setStatus(rs.getString("status"));
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting event by ID!");
            e.printStackTrace();
        }
        
        return event;
    }
    
    /**
     * Get all events
     * @return List of all events
     */
    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM events ORDER BY event_date, start_time";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            while (rs.next()) {
                Event event = new Event();
                event.setEventId(rs.getInt("event_id"));
                event.setEventName(rs.getString("event_name"));
                event.setDescription(rs.getString("description"));
                event.setEventDate(rs.getDate("event_date").toLocalDate());
                event.setStartTime(rs.getTime("start_time").toLocalTime());
                event.setEndTime(rs.getTime("end_time").toLocalTime());
                event.setVenueId(rs.getInt("venue_id"));
                event.setMaxParticipants(rs.getInt("max_participants"));
                event.setOrganizer(rs.getString("organizer"));
                event.setStatus(rs.getString("status"));
                
                events.add(event);
            }
            
            rs.close();
            stmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting all events!");
            e.printStackTrace();
        }
        
        return events;
    }
    
    /**
     * Get upcoming events (events with date >= today)
     * @return List of upcoming events
     */
    public List<Event> getUpcomingEvents() {
        List<Event> events = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM events WHERE event_date >= ? ORDER BY event_date, start_time";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setDate(1, Date.valueOf(LocalDate.now()));
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Event event = new Event();
                event.setEventId(rs.getInt("event_id"));
                event.setEventName(rs.getString("event_name"));
                event.setDescription(rs.getString("description"));
                event.setEventDate(rs.getDate("event_date").toLocalDate());
                event.setStartTime(rs.getTime("start_time").toLocalTime());
                event.setEndTime(rs.getTime("end_time").toLocalTime());
                event.setVenueId(rs.getInt("venue_id"));
                event.setMaxParticipants(rs.getInt("max_participants"));
                event.setOrganizer(rs.getString("organizer"));
                event.setStatus(rs.getString("status"));
                
                events.add(event);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting upcoming events!");
            e.printStackTrace();
        }
        
        return events;
    }
    
    /**
     * Update an existing event
     * @param event The event object with updated information
     * @return boolean Success or failure
     */
    public boolean updateEvent(Event event) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "UPDATE events SET event_name = ?, description = ?, event_date = ?, "
                         + "start_time = ?, end_time = ?, venue_id = ?, max_participants = ?, "
                         + "organizer = ?, status = ? WHERE event_id = ?";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, event.getEventName());
            pstmt.setString(2, event.getDescription());
            pstmt.setDate(3, event.getSqlEventDate());
            pstmt.setTime(4, event.getSqlStartTime());
            pstmt.setTime(5, event.getSqlEndTime());
            pstmt.setInt(6, event.getVenueId());
            pstmt.setInt(7, event.getMaxParticipants());
            pstmt.setString(8, event.getOrganizer());
            pstmt.setString(9, event.getStatus());
            pstmt.setInt(10, event.getEventId());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Event updated successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error updating event!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Delete an event by its ID
     * @param eventId The ID of the event to delete
     * @return boolean Success or failure
     */
    public boolean deleteEvent(int eventId) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "DELETE FROM events WHERE event_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, eventId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Event deleted successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error deleting event!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Search events by name or description
     * @param keyword The search keyword
     * @return List of matching events
     */
    public List<Event> searchEvents(String keyword) {
        List<Event> events = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM events WHERE event_name LIKE ? OR description LIKE ? "
                         + "ORDER BY event_date, start_time";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            String searchPattern = "%" + keyword + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Event event = new Event();
                event.setEventId(rs.getInt("event_id"));
                event.setEventName(rs.getString("event_name"));
                event.setDescription(rs.getString("description"));
                event.setEventDate(rs.getDate("event_date").toLocalDate());
                event.setStartTime(rs.getTime("start_time").toLocalTime());
                event.setEndTime(rs.getTime("end_time").toLocalTime());
                event.setVenueId(rs.getInt("venue_id"));
                event.setMaxParticipants(rs.getInt("max_participants"));
                event.setOrganizer(rs.getString("organizer"));
                event.setStatus(rs.getString("status"));
                
                events.add(event);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error searching events!");
            e.printStackTrace();
        }
        
        return events;
    }
    
    /**
     * Update the status of an event
     * @param eventId The ID of the event to update
     * @param status The new status
     * @return boolean Success or failure
     */
    public boolean updateEventStatus(int eventId, String status) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "UPDATE events SET status = ? WHERE event_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, status);
            pstmt.setInt(2, eventId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Event status updated successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error updating event status!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Get the current participant count for an event
     * @param eventId The ID of the event
     * @return int Number of participants
     */
    public int getEventParticipantCount(int eventId) {
        Connection conn = dbManager.getConnection();
        int count = 0;
        
        try {
            String query = "SELECT COUNT(*) FROM registrations WHERE event_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, eventId);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                count = rs.getInt(1);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting event participant count!");
            e.printStackTrace();
        }
        
        return count;
    }
    
    /**
     * Check if an event is full (reached max participants)
     * @param eventId The ID of the event
     * @return boolean True if full, false otherwise
     */
    public boolean isEventFull(int eventId) {
        Event event = getEventById(eventId);
        int currentCount = getEventParticipantCount(eventId);
        
        return event != null && event.getMaxParticipants() <= currentCount;
    }
}
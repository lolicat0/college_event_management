package com.collegeevent.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {
    // Database connection parameters
    private static final String DB_URL = "jdbc:mysql://localhost:3306/college_event_db";
    private static final String USER = "root"; // Change this to your actual MySQL username
    private static final String PASSWORD = "Lolicat@290528"; // Change this to your actual MySQL password
    
    private Connection connection;
    
    /**
     * Constructor - Establishes connection to the database
     */
    public DatabaseManager() {
        try {
            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Open a connection
            System.out.println("Connecting to database...");
            connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
            System.out.println("Database connection successful!");
            
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database connection failed!");
            e.printStackTrace();
        }
    }
    
    /**
     * Get the database connection
     * @return Connection object
     */
    public Connection getConnection() {
        return connection;
    }
    
    /**
     * Close the database connection
     */
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            System.out.println("Error closing database connection!");
            e.printStackTrace();
        }
    }
    
    /**
     * Execute an SQL query that returns a result (SELECT)
     * @param query SQL query string
     * @return ResultSet containing the query results
     */
    public ResultSet executeQuery(String query) {
        ResultSet resultSet = null;
        try {
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(query);
        } catch (SQLException e) {
            System.out.println("Error executing query: " + query);
            e.printStackTrace();
        }
        return resultSet;
    }
    
    /**
     * Execute an SQL update query (INSERT, UPDATE, DELETE)
     * @param query SQL query string
     * @return int number of rows affected
     */
    public int executeUpdate(String query) {
        int rowsAffected = 0;
        try {
            Statement statement = connection.createStatement();
            rowsAffected = statement.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println("Error executing update: " + query);
            e.printStackTrace();
        }
        return rowsAffected;
    }
    
    /**
     * Execute prepared statement
     * @param query SQL query with placeholders
     * @param params Array of parameters to be set in the prepared statement
     * @return int number of rows affected
     */
    public int executePreparedStatement(String query, Object[] params) {
        int rowsAffected = 0;
        try {
            PreparedStatement pstmt = connection.prepareStatement(query);
            
            // Set parameters
            for (int i = 0; i < params.length; i++) {
                pstmt.setObject(i + 1, params[i]);
            }
            
            rowsAffected = pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException e) {
            System.out.println("Error executing prepared statement!");
            e.printStackTrace();
        }
        return rowsAffected;
    }
    
    /**
     * Create the database and tables if they don't exist
     */
    public void initializeDatabase() {
        try {
            // Create tables
            Statement stmt = connection.createStatement();
            
            String createEventsTable = "CREATE TABLE IF NOT EXISTS events ("
                    + "event_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "event_name VARCHAR(100) NOT NULL,"
                    + "description TEXT,"
                    + "event_date DATE NOT NULL,"
                    + "start_time TIME NOT NULL,"
                    + "end_time TIME NOT NULL,"
                    + "venue_id INT,"
                    + "max_participants INT,"
                    + "organizer VARCHAR(100) NOT NULL,"
                    + "status VARCHAR(20) DEFAULT 'Upcoming',"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
                    + ")";
            
            String createStudentsTable = "CREATE TABLE IF NOT EXISTS students ("
                    + "student_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "registration_number VARCHAR(20) UNIQUE NOT NULL,"
                    + "first_name VARCHAR(50) NOT NULL,"
                    + "last_name VARCHAR(50) NOT NULL,"
                    + "email VARCHAR(100) UNIQUE NOT NULL,"
                    + "phone VARCHAR(15),"
                    + "department VARCHAR(50),"
                    + "year_of_study INT,"
                    + "password VARCHAR(100) NOT NULL,"
                    + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
                    + ")";
            
            String createVenuesTable = "CREATE TABLE IF NOT EXISTS venues ("
                    + "venue_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "venue_name VARCHAR(100) NOT NULL,"
                    + "capacity INT NOT NULL,"
                    + "location VARCHAR(100),"
                    + "facilities TEXT,"
                    + "status VARCHAR(20) DEFAULT 'Available'"
                    + ")";
            
            String createRegistrationsTable = "CREATE TABLE IF NOT EXISTS registrations ("
                    + "registration_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "event_id INT NOT NULL,"
                    + "student_id INT NOT NULL,"
                    + "registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                    + "attendance_status VARCHAR(20) DEFAULT 'Registered',"
                    + "FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE,"
                    + "FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,"
                    + "UNIQUE KEY unique_registration (event_id, student_id)"
                    + ")";
            
            // Execute the create table statements
            stmt.executeUpdate(createEventsTable);
            stmt.executeUpdate(createStudentsTable);
            stmt.executeUpdate(createVenuesTable);
            stmt.executeUpdate(createRegistrationsTable);
            
            System.out.println("Database tables created successfully!");
            
        } catch (SQLException e) {
            System.out.println("Error initializing database!");
            e.printStackTrace();
        }
    }
}
package com.collegeevent;

import com.collegeevent.ui.MainFrame;

/**
 * Main class for the College Event Management System
 * This is the entry point of the application
 */
public class CollegeEventManagementSystem {
    
    /**
     * Main method to launch the application
     * @param args Command line arguments (not used)
     */
    public static void main(String[] args) {
        // Display a splash screen with application information
        System.out.println("**********************************************");
        System.out.println("*   College Event Management System v1.0     *");
        System.out.println("*                                            *");
        System.out.println("* A comprehensive system for managing:       *");
        System.out.println("* - College events                           *");
        System.out.println("* - Student registrations                    *");
        System.out.println("* - Venue bookings                           *");
        System.out.println("* - Attendance tracking                      *");
        System.out.println("*                                            *");
        System.out.println("**********************************************");
        
        // Launch the main application window
        javax.swing.SwingUtilities.invokeLater(() -> {
            // Set the look and feel to the system look and feel
            try {
                javax.swing.UIManager.setLookAndFeel(
                    javax.swing.UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                System.err.println("Error setting look and feel: " + e.getMessage());
            }
            
            // Create the main application frame
            new MainFrame();
        });
    }
}
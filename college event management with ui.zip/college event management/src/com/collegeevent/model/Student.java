package com.collegeevent.model;

public class Student {
    private int studentId;
    private String registrationNumber;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String department;
    private int yearOfStudy;
    private String password;
    
    // Default constructor
    public Student() {
    }
    
    // Constructor with all fields
    public Student(int studentId, String registrationNumber, String firstName, String lastName,
                  String email, String phone, String department, int yearOfStudy, String password) {
        this.studentId = studentId;
        this.registrationNumber = registrationNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.yearOfStudy = yearOfStudy;
        this.password = password;
    }
    
    // Constructor for creating new students (without ID)
    public Student(String registrationNumber, String firstName, String lastName,
                  String email, String phone, String department, int yearOfStudy, String password) {
        this.registrationNumber = registrationNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.yearOfStudy = yearOfStudy;
        this.password = password;
    }
    
    // Getters and Setters
    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getYearOfStudy() {
        return yearOfStudy;
    }

    public void setYearOfStudy(int yearOfStudy) {
        this.yearOfStudy = yearOfStudy;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    // Get full name
    public String getFullName() {
        return firstName + " " + lastName;
    }
    
    @Override
    public String toString() {
        return "Student [ID: " + studentId + ", Registration: " + registrationNumber + 
               ", Name: " + getFullName() + ", Email: " + email + ", Department: " + 
               department + ", Year: " + yearOfStudy + "]";
    }
}
package com.collegeevent.model;

import java.time.LocalDateTime;

public class Registration {
    private int registrationId;
    private int eventId;
    private int studentId;
    private LocalDateTime registrationDate;
    private String attendanceStatus;
    
    // Default constructor
    public Registration() {
    }
    
    // Constructor with all fields
    public Registration(int registrationId, int eventId, int studentId, 
                        LocalDateTime registrationDate, String attendanceStatus) {
        this.registrationId = registrationId;
        this.eventId = eventId;
        this.studentId = studentId;
        this.registrationDate = registrationDate;
        this.attendanceStatus = attendanceStatus;
    }
    
    // Constructor for creating new registrations (without ID)
    public Registration(int eventId, int studentId) {
        this.eventId = eventId;
        this.studentId = studentId;
        this.registrationDate = LocalDateTime.now();
        this.attendanceStatus = "Registered";
    }
    
    // Getters and Setters
    public int getRegistrationId() {
        return registrationId;
    }

    public void setRegistrationId(int registrationId) {
        this.registrationId = registrationId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public LocalDateTime getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDateTime registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getAttendanceStatus() {
        return attendanceStatus;
    }

    public void setAttendanceStatus(String attendanceStatus) {
        this.attendanceStatus = attendanceStatus;
    }
    
    @Override
    public String toString() {
        return "Registration [ID: " + registrationId + ", Event ID: " + eventId + 
               ", Student ID: " + studentId + ", Status: " + attendanceStatus + "]";
    }
}
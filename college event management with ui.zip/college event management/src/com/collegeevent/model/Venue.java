package com.collegeevent.model;

public class Venue {
    private int venueId;
    private String venueName;
    private int capacity;
    private String location;
    private String facilities;
    private String status;
    
    // Default constructor
    public Venue() {
    }
    
    // Constructor with all fields
    public Venue(int venueId, String venueName, int capacity, String location, 
                String facilities, String status) {
        this.venueId = venueId;
        this.venueName = venueName;
        this.capacity = capacity;
        this.location = location;
        this.facilities = facilities;
        this.status = status;
    }
    
    // Constructor for creating new venues (without ID)
    public Venue(String venueName, int capacity, String location, String facilities) {
        this.venueName = venueName;
        this.capacity = capacity;
        this.location = location;
        this.facilities = facilities;
        this.status = "Available";
    }
    
    // Getters and Setters
    public int getVenueId() {
        return venueId;
    }

    public void setVenueId(int venueId) {
        this.venueId = venueId;
    }

    public String getVenueName() {
        return venueName;
    }

    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getFacilities() {
        return facilities;
    }

    public void setFacilities(String facilities) {
        this.facilities = facilities;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    @Override
    public String toString() {
        return "Venue [ID: " + venueId + ", Name: " + venueName + ", Capacity: " + 
               capacity + ", Location: " + location + ", Status: " + status + "]";
    }
}
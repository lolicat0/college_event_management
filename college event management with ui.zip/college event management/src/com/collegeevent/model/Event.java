package com.collegeevent.model;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;

// Event class to represent college events
public class Event {
    private int eventId;
    private String eventName;
    private String description;
    private LocalDate eventDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private int venueId;
    private int maxParticipants;
    private String organizer;
    private String status;
    
    // Default constructor
    public Event() {
    }
    
    // Constructor with all fields
    public Event(int eventId, String eventName, String description, LocalDate eventDate,
                 LocalTime startTime, LocalTime endTime, int venueId, 
                 int maxParticipants, String organizer, String status) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.description = description;
        this.eventDate = eventDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.venueId = venueId;
        this.maxParticipants = maxParticipants;
        this.organizer = organizer;
        this.status = status;
    }
    
    // Constructor for creating new events (without ID)
    public Event(String eventName, String description, LocalDate eventDate,
                 LocalTime startTime, LocalTime endTime, int venueId, 
                 int maxParticipants, String organizer) {
        this.eventName = eventName;
        this.description = description;
        this.eventDate = eventDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.venueId = venueId;
        this.maxParticipants = maxParticipants;
        this.organizer = organizer;
        this.status = "Upcoming";
    }
    
    // Getters and Setters
    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getEventDate() {
        return eventDate;
    }

    public void setEventDate(LocalDate eventDate) {
        this.eventDate = eventDate;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public int getVenueId() {
        return venueId;
    }

    public void setVenueId(int venueId) {
        this.venueId = venueId;
    }

    public int getMaxParticipants() {
        return maxParticipants;
    }

    public void setMaxParticipants(int maxParticipants) {
        this.maxParticipants = maxParticipants;
    }

    public String getOrganizer() {
        return organizer;
    }

    public void setOrganizer(String organizer) {
        this.organizer = organizer;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    // Convert LocalDate to SQL Date
    public Date getSqlEventDate() {
        return Date.valueOf(eventDate);
    }
    
    // Convert LocalTime to SQL Time
    public Time getSqlStartTime() {
        return Time.valueOf(startTime);
    }
    
    public Time getSqlEndTime() {
        return Time.valueOf(endTime);
    }
    
    @Override
    public String toString() {
        return "Event [ID: " + eventId + ", Name: " + eventName + ", Date: " + eventDate + 
               ", Time: " + startTime + " - " + endTime + ", Venue ID: " + venueId + 
               ", Status: " + status + "]";
    }
}
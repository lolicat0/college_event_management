package com.collegeevent.ui;

import java.awt.event.*;  // This contains java.awt.Event
import com.collegeevent.model.Event;  // Your custom Event class
import com.collegeevent.database.DatabaseManager;
import com.collegeevent.event.EventManager;
import com.collegeevent.student.StudentManager;
import com.collegeevent.venue.VenueManager;
import com.collegeevent.registration.RegistrationManager;
import com.collegeevent.model.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class MainFrame extends JFrame {
    // Database and manager objects
    private DatabaseManager dbManager;
    private EventManager eventManager;
    private StudentManager studentManager;
    private VenueManager venueManager;
    private RegistrationManager registrationManager;
    
    // Current logged in student (null if not logged in)
    private Student currentStudent;
    
    // Main panels
    private JPanel loginPanel;
    private JPanel mainPanel;
    private JPanel eventsPanel;
    private JPanel studentsPanel;
    private JPanel venuesPanel;
    private JPanel registrationsPanel;
    private JPanel myEventsPanel;
    
    // Main constructor
    public MainFrame() {
        // Initialize database and managers
        dbManager = new DatabaseManager();
        dbManager.initializeDatabase();
        
        eventManager = new EventManager(dbManager);
        studentManager = new StudentManager(dbManager);
        venueManager = new VenueManager(dbManager);
        registrationManager = new RegistrationManager(dbManager);
        
        // Set up the frame
        setTitle("College Event Management System");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Add window listener to close database connection when window is closed
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dbManager.closeConnection();
                System.out.println("Database connection closed.");
            }
        });
        
        // Initialize UI components
        initializeUI();
        
        // Show the login panel initially
        showLoginPanel();
        
        // Make the frame visible
        setVisible(true);
    }
    
    // Initialize UI components
    private void initializeUI() {
        // Create the main panel with card layout to switch between panels
        mainPanel = new JPanel(new CardLayout());
        
        // Initialize all panels
        initializeLoginPanel();
        initializeEventsPanel();
        initializeStudentsPanel();
        initializeVenuesPanel();
        initializeRegistrationsPanel();
        initializeMyEventsPanel();
        
        // Add panels to the main panel
        mainPanel.add(loginPanel, "login");
        mainPanel.add(eventsPanel, "events");
        mainPanel.add(studentsPanel, "students");
        mainPanel.add(venuesPanel, "venues");
        mainPanel.add(registrationsPanel, "registrations");
        mainPanel.add(myEventsPanel, "myEvents");
        
        // Add main panel to the frame
        add(mainPanel);
    }
    
    // Show a specific panel using the card layout
    private void showPanel(String panelName) {
        CardLayout cardLayout = (CardLayout) mainPanel.getLayout();
        cardLayout.show(mainPanel, panelName);
    }
    
    // Show the login panel
    private void showLoginPanel() {
        showPanel("login");
    }
    
    // Initialize the login panel
    private void initializeLoginPanel() {
        loginPanel = new JPanel();
        loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.Y_AXIS));
        loginPanel.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
        
        // Title label
        JLabel titleLabel = new JLabel("College Event Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Subtitle label
        JLabel subtitleLabel = new JLabel("Login or Register");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Login form
        JPanel loginFormPanel = new JPanel();
        loginFormPanel.setLayout(new BoxLayout(loginFormPanel, BoxLayout.Y_AXIS));
        loginFormPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        loginFormPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Registration number field
        JPanel regNoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel regNoLabel = new JLabel("Registration Number: ");
        JTextField regNoField = new JTextField(20);
        regNoPanel.add(regNoLabel);
        regNoPanel.add(regNoField);
        
        // Password field
        JPanel passwordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel passwordLabel = new JLabel("Password: ");
        JPasswordField passwordField = new JPasswordField(20);
        passwordPanel.add(passwordLabel);
        passwordPanel.add(passwordField);
        
        // Login button
        JButton loginButton = new JButton("Login");
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Register button
        JButton registerButton = new JButton("Register as New Student");
        registerButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Admin login button
        JButton adminLoginButton = new JButton("Login as Administrator");
        adminLoginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Add components to login form panel
        loginFormPanel.add(regNoPanel);
        loginFormPanel.add(passwordPanel);
        loginFormPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        loginFormPanel.add(loginButton);
        loginFormPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        loginFormPanel.add(registerButton);
        loginFormPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        loginFormPanel.add(adminLoginButton);
        
        // Add components to login panel
        loginPanel.add(Box.createVerticalGlue());
        loginPanel.add(titleLabel);
        loginPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        loginPanel.add(subtitleLabel);
        loginPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        loginPanel.add(loginFormPanel);
        loginPanel.add(Box.createVerticalGlue());
        
        // Login button action
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String regNo = regNoField.getText();
                String password = new String(passwordField.getPassword());
                
                if (regNo.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(MainFrame.this, 
                        "Please enter both registration number and password.", 
                        "Login Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Authenticate student
                Student student = studentManager.authenticateStudent(regNo, password);
                
                if (student != null) {
                    // Login successful
                    currentStudent = student;
                    JOptionPane.showMessageDialog(MainFrame.this,
                        "Welcome, " + student.getFullName() + "!",
                        "Login Successful", JOptionPane.INFORMATION_MESSAGE);
                    
                    // Show the student dashboard
                    showPanel("myEvents");
                    refreshMyEventsPanel();
                    
                    // Clear the login fields
                    regNoField.setText("");
                    passwordField.setText("");
                } else {
                    // Login failed
                    JOptionPane.showMessageDialog(MainFrame.this,
                        "Invalid registration number or password. Please try again.",
                        "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        // Register button action
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showStudentRegistrationDialog();
            }
        });
        
        // Admin login button action
        adminLoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Simple admin login (in a real app, this would be more secure)
                String adminUsername = JOptionPane.showInputDialog(MainFrame.this,
                    "Enter admin username:");
                
                if (adminUsername != null && !adminUsername.isEmpty()) {
                    String adminPassword = JOptionPane.showInputDialog(MainFrame.this,
                        "Enter admin password:");
                    
                    if (adminPassword != null && !adminPassword.isEmpty()) {
                        // Check if admin credentials are valid (hardcoded for demo)
                        if (adminUsername.equals("admin") && adminPassword.equals("admin123")) {
                            // Admin login successful
                            JOptionPane.showMessageDialog(MainFrame.this,
                                "Welcome, Administrator!",
                                "Admin Login Successful", JOptionPane.INFORMATION_MESSAGE);
                            
                            // Show the events panel (admin dashboard)
                            showPanel("events");
                            refreshEventsPanel();
                        } else {
                            // Admin login failed
                            JOptionPane.showMessageDialog(MainFrame.this,
                                "Invalid admin credentials. Please try again.",
                                "Admin Login Failed", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        });
    }
    
    // Show student registration dialog
    private void showStudentRegistrationDialog() {
        // Create a dialog for student registration
        JDialog registrationDialog = new JDialog(this, "Student Registration", true);
        registrationDialog.setSize(500, 600);
        registrationDialog.setLocationRelativeTo(this);
        registrationDialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Registration form fields
        JTextField regNoField = new JTextField(20);
        JTextField firstNameField = new JTextField(20);
        JTextField lastNameField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JTextField phoneField = new JTextField(20);
        JTextField departmentField = new JTextField(20);
        JComboBox<Integer> yearComboBox = new JComboBox<>(new Integer[]{1, 2, 3, 4, 5});
        JPasswordField passwordField = new JPasswordField(20);
        JPasswordField confirmPasswordField = new JPasswordField(20);
        
        // Create form field panels
        JPanel regNoPanel = createFormFieldPanel("Registration Number:", regNoField);
        JPanel firstNamePanel = createFormFieldPanel("First Name:", firstNameField);
        JPanel lastNamePanel = createFormFieldPanel("Last Name:", lastNameField);
        JPanel emailPanel = createFormFieldPanel("Email:", emailField);
        JPanel phonePanel = createFormFieldPanel("Phone:", phoneField);
        JPanel departmentPanel = createFormFieldPanel("Department:", departmentField);
        JPanel yearPanel = createFormFieldPanel("Year of Study:", yearComboBox);
        JPanel passwordPanel = createFormFieldPanel("Password:", passwordField);
        JPanel confirmPasswordPanel = createFormFieldPanel("Confirm Password:", confirmPasswordField);
        
        // Add field panels to form panel
        formPanel.add(regNoPanel);
        formPanel.add(firstNamePanel);
        formPanel.add(lastNamePanel);
        formPanel.add(emailPanel);
        formPanel.add(phonePanel);
        formPanel.add(departmentPanel);
        formPanel.add(yearPanel);
        formPanel.add(passwordPanel);
        formPanel.add(confirmPasswordPanel);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton registerButton = new JButton("Register");
        JButton cancelButton = new JButton("Cancel");
        buttonPanel.add(registerButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        registrationDialog.add(formPanel, BorderLayout.CENTER);
        registrationDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Register button action
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get values from form fields
                String regNo = regNoField.getText();
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                String email = emailField.getText();
                String phone = phoneField.getText();
                String department = departmentField.getText();
                int yearOfStudy = (Integer) yearComboBox.getSelectedItem();
                String password = new String(passwordField.getPassword());
                String confirmPassword = new String(confirmPasswordField.getPassword());
                
                // Validate form fields
                if (regNo.isEmpty() || firstName.isEmpty() || lastName.isEmpty() ||
                    email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(registrationDialog,
                        "Please fill in all required fields.",
                        "Registration Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Check if passwords match
                if (!password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(registrationDialog,
                        "Passwords do not match. Please try again.",
                        "Registration Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Create new student object
                Student student = new Student(regNo, firstName, lastName, email, phone, department, yearOfStudy, password);
                
                // Register the student
                int studentId = studentManager.registerStudent(student);
                
                if (studentId > 0) {
                    // Registration successful
                    JOptionPane.showMessageDialog(registrationDialog,
                        "Registration successful! You can now login with your registration number and password.",
                        "Registration Successful", JOptionPane.INFORMATION_MESSAGE);
                    registrationDialog.dispose();
                } else {
                    // Registration failed
                    JOptionPane.showMessageDialog(registrationDialog,
                        "Registration failed. Registration number or email may already be in use.",
                        "Registration Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrationDialog.dispose();
            }
        });
        
        // Show the dialog
        registrationDialog.setVisible(true);
    }
    
    // Helper method to create a form field panel
    private JPanel createFormFieldPanel(String labelText, JComponent field) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel label = new JLabel(labelText);
        label.setPreferredSize(new Dimension(150, 25));
        panel.add(label);
        panel.add(field);
        return panel;
    }
    
    // Initialize the events panel
    private void initializeEventsPanel() {
        eventsPanel = new JPanel(new BorderLayout());
        
        // Title panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Events Management", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        // Navigation panel
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton homeButton = new JButton("Home");
        JButton studentsButton = new JButton("Students");
        JButton venuesButton = new JButton("Venues");
        JButton registrationsButton = new JButton("Registrations");
        JButton logoutButton = new JButton("Logout");
        
        navPanel.add(homeButton);
        navPanel.add(studentsButton);
        navPanel.add(venuesButton);
        navPanel.add(registrationsButton);
        navPanel.add(logoutButton);
        
        titlePanel.add(navPanel, BorderLayout.SOUTH);
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        String[] columns = {"Event ID", "Event Name", "Date", "Time", "Venue", "Participants", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        JTable eventsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(eventsTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addButton = new JButton("Add Event");
        JButton editButton = new JButton("Edit Event");
        JButton deleteButton = new JButton("Delete Event");
        JButton viewButton = new JButton("View Registrations");
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        JButton refreshButton = new JButton("Refresh");
        
        buttonPanel.add(searchField);
        buttonPanel.add(searchButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);
        
        // Add panels to events panel
        eventsPanel.add(titlePanel, BorderLayout.NORTH);
        eventsPanel.add(tablePanel, BorderLayout.CENTER);
        eventsPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Load events into table
        loadEventsTable(tableModel);
        
        // Home button action
        homeButton.addActionListener(e -> showPanel("events"));
        
        // Students button action
        studentsButton.addActionListener(e -> {
            showPanel("students");
            refreshStudentsPanel();
        });
        
        // Venues button action
        venuesButton.addActionListener(e -> {
            showPanel("venues");
            refreshVenuesPanel();
        });
        
        // Registrations button action
        registrationsButton.addActionListener(e -> {
            showPanel("registrations");
            refreshRegistrationsPanel();
        });
        
        // Logout button action
        logoutButton.addActionListener(e -> {
            currentStudent = null;
            showLoginPanel();
        });
        
        // Add event button action
        addButton.addActionListener(e -> showAddEventDialog());
        
        // Refresh button action
        refreshButton.addActionListener(e -> refreshEventsPanel());
        
        // Edit event button action
        editButton.addActionListener(e -> {
            int selectedRow = eventsTable.getSelectedRow();
            if (selectedRow >= 0) {
                int eventId = (int) tableModel.getValueAt(selectedRow, 0);
                showEditEventDialog(eventId);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select an event to edit.", 
                    "Edit Event", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Delete event button action
        deleteButton.addActionListener(e -> {
            int selectedRow = eventsTable.getSelectedRow();
            if (selectedRow >= 0) {
                int eventId = (int) tableModel.getValueAt(selectedRow, 0);
                int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this event?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean success = eventManager.deleteEvent(eventId);
                    if (success) {
                        JOptionPane.showMessageDialog(this,
                            "Event deleted successfully!",
                            "Delete Event", JOptionPane.INFORMATION_MESSAGE);
                        refreshEventsPanel();
                    } else {
                        JOptionPane.showMessageDialog(this,
                            "Failed to delete event. It may be referenced by registrations.",
                            "Delete Event", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select an event to delete.", 
                    "Delete Event", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // View registrations button action
        viewButton.addActionListener(e -> {
            int selectedRow = eventsTable.getSelectedRow();
            if (selectedRow >= 0) {
                int eventId = (int) tableModel.getValueAt(selectedRow, 0);
                showEventRegistrationsDialog(eventId);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select an event to view registrations.", 
                    "View Registrations", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Search button action
        searchButton.addActionListener(e -> {
            String keyword = searchField.getText();
            if (!keyword.isEmpty()) {
                List<Event> events = eventManager.searchEvents(keyword);
                updateEventsTable(tableModel, events);
            } else {
                loadEventsTable(tableModel);
            }
        });
    }
    
    // Initialize the students panel
    private void initializeStudentsPanel() {
        studentsPanel = new JPanel(new BorderLayout());
        
        // Title panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Students Management", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        // Navigation panel
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton homeButton = new JButton("Home");
        JButton eventsButton = new JButton("Events");
        JButton venuesButton = new JButton("Venues");
        JButton registrationsButton = new JButton("Registrations");
        JButton logoutButton = new JButton("Logout");
        
        navPanel.add(homeButton);
        navPanel.add(eventsButton);
        navPanel.add(venuesButton);
        navPanel.add(registrationsButton);
        navPanel.add(logoutButton);
        
        titlePanel.add(navPanel, BorderLayout.SOUTH);
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        String[] columns = {"Student ID", "Registration No", "Name", "Email", "Phone", "Department", "Year"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        JTable studentsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(studentsTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addButton = new JButton("Add Student");
        JButton editButton = new JButton("Edit Student");
        JButton deleteButton = new JButton("Delete Student");
        JButton viewButton = new JButton("View Registrations");
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        JButton refreshButton = new JButton("Refresh");
        
        buttonPanel.add(searchField);
        buttonPanel.add(searchButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);
        
        // Add panels to students panel
        studentsPanel.add(titlePanel, BorderLayout.NORTH);
        studentsPanel.add(tablePanel, BorderLayout.CENTER);
        studentsPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Load students into table
        loadStudentsTable(tableModel);
        
        // Home button action
        homeButton.addActionListener(e -> {
            showPanel("events");
            refreshEventsPanel();
        });
        
        // Events button action
        eventsButton.addActionListener(e -> {
            showPanel("events");
            refreshEventsPanel();
        });
        
        // Venues button action
        venuesButton.addActionListener(e -> {
            showPanel("venues");
            refreshVenuesPanel();
        });
        
        // Registrations button action
        registrationsButton.addActionListener(e -> {
            showPanel("registrations");
            refreshRegistrationsPanel();
        });
        
        // Logout button action
        logoutButton.addActionListener(e -> {
            currentStudent = null;
            showLoginPanel();
        });
        
        // Add student button action
        addButton.addActionListener(e -> showStudentRegistrationDialog());
        
        // Refresh button action
        refreshButton.addActionListener(e -> refreshStudentsPanel());
        
        // Edit student button action
        editButton.addActionListener(e -> {
            int selectedRow = studentsTable.getSelectedRow();
            if (selectedRow >= 0) {
                int studentId = (int) tableModel.getValueAt(selectedRow, 0);
                showEditStudentDialog(studentId);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select a student to edit.", 
                    "Edit Student", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Delete student button action
        deleteButton.addActionListener(e -> {
            int selectedRow = studentsTable.getSelectedRow();
            if (selectedRow >= 0) {
                int studentId = (int) tableModel.getValueAt(selectedRow, 0);
                int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this student?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean success = studentManager.deleteStudent(studentId);
                    if (success) {
                        JOptionPane.showMessageDialog(this,
                            "Student deleted successfully!",
                            "Delete Student", JOptionPane.INFORMATION_MESSAGE);
                        refreshStudentsPanel();
                    } else {
                        JOptionPane.showMessageDialog(this,
                            "Failed to delete student. They may have active registrations.",
                            "Delete Student", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select a student to delete.", 
                    "Delete Student", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // View registrations button action
        viewButton.addActionListener(e -> {
            int selectedRow = studentsTable.getSelectedRow();
            if (selectedRow >= 0) {
                int studentId = (int) tableModel.getValueAt(selectedRow, 0);
                showStudentRegistrationsDialog(studentId);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select a student to view registrations.", 
                    "View Registrations", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Search button action
        searchButton.addActionListener(e -> {
            String keyword = searchField.getText();
            if (!keyword.isEmpty()) {
                List<Student> students = studentManager.searchStudents(keyword);
                updateStudentsTable(tableModel, students);
            } else {
                loadStudentsTable(tableModel);
            }
        });
    }
    
    // Initialize the venues panel
    private void initializeVenuesPanel() {
        venuesPanel = new JPanel(new BorderLayout());
        
        // Title panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Venues Management", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        // Navigation panel
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton homeButton = new JButton("Home");
        JButton eventsButton = new JButton("Events");
        JButton studentsButton = new JButton("Students");
        JButton registrationsButton = new JButton("Registrations");
        JButton logoutButton = new JButton("Logout");
        
        navPanel.add(homeButton);
        navPanel.add(eventsButton);
        navPanel.add(studentsButton);
        navPanel.add(registrationsButton);
        navPanel.add(logoutButton);
        
        titlePanel.add(navPanel, BorderLayout.SOUTH);
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        String[] columns = {"Venue ID", "Venue Name", "Capacity", "Location", "Facilities", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        JTable venuesTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(venuesTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addButton = new JButton("Add Venue");
        JButton editButton = new JButton("Edit Venue");
        JButton deleteButton = new JButton("Delete Venue");
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        JButton refreshButton = new JButton("Refresh");
        
        buttonPanel.add(searchField);
        buttonPanel.add(searchButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        
        // Add panels to venues panel
        venuesPanel.add(titlePanel, BorderLayout.NORTH);
        venuesPanel.add(tablePanel, BorderLayout.CENTER);
        venuesPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Load venues into table
        loadVenuesTable(tableModel);
        
        // Home button action
        homeButton.addActionListener(e -> {
            showPanel("events");
            refreshEventsPanel();
        });
        
        // Events button action
        eventsButton.addActionListener(e -> {
            showPanel("events");
            refreshEventsPanel();
        });
        
        // Students button action
        studentsButton.addActionListener(e -> {
            showPanel("students");
            refreshStudentsPanel();
        });
        
        // Registrations button action
        registrationsButton.addActionListener(e -> {
            showPanel("registrations");
            refreshRegistrationsPanel();
        });
        // Logout button action
        logoutButton.addActionListener(e -> {
            currentStudent = null;
            showLoginPanel();
        });
        
        // Refresh button action
        refreshButton.addActionListener(e -> refreshVenuesPanel());
        
        // Add venue button action
        addButton.addActionListener(e -> showAddVenueDialog());
        
        // Edit venue button action
        editButton.addActionListener(e -> {
            int selectedRow = venuesTable.getSelectedRow();
            if (selectedRow >= 0) {
                int venueId = (int) tableModel.getValueAt(selectedRow, 0);
                showEditVenueDialog(venueId);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select a venue to edit.", 
                    "Edit Venue", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Delete venue button action
        deleteButton.addActionListener(e -> {
            int selectedRow = venuesTable.getSelectedRow();
            if (selectedRow >= 0) {
                int venueId = (int) tableModel.getValueAt(selectedRow, 0);
                int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this venue?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean success = venueManager.deleteVenue(venueId);
                    if (success) {
                        JOptionPane.showMessageDialog(this,
                            "Venue deleted successfully!",
                            "Delete Venue", JOptionPane.INFORMATION_MESSAGE);
                        refreshVenuesPanel();
                    } else {
                        JOptionPane.showMessageDialog(this,
                            "Failed to delete venue. It may be used in events.",
                            "Delete Venue", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select a venue to delete.", 
                    "Delete Venue", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Search button action
        searchButton.addActionListener(e -> {
            String keyword = searchField.getText();
            if (!keyword.isEmpty()) {
                List<Venue> venues = venueManager.searchVenues(keyword);
                updateVenuesTable(tableModel, venues);
            } else {
                loadVenuesTable(tableModel);
            }
        });
    }
    
    // Initialize the registrations panel
    private void initializeRegistrationsPanel() {
        registrationsPanel = new JPanel(new BorderLayout());
        
        // Title panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Registrations Management", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        // Navigation panel
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton homeButton = new JButton("Home");
        JButton eventsButton = new JButton("Events");
        JButton studentsButton = new JButton("Students");
        JButton venuesButton = new JButton("Venues");
        JButton logoutButton = new JButton("Logout");
        
        navPanel.add(homeButton);
        navPanel.add(eventsButton);
        navPanel.add(studentsButton);
        navPanel.add(venuesButton);
        navPanel.add(logoutButton);
        
        titlePanel.add(navPanel, BorderLayout.SOUTH);
        
        // Combo box panel for event selection
        JPanel comboPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel eventLabel = new JLabel("Select Event:");
        JComboBox<String> eventComboBox = new JComboBox<>();
        
        // Load events into combo box
        eventComboBox.addItem("-- All Events --");
        List<Event> events = eventManager.getAllEvents();
        for (Event event : events) {
            eventComboBox.addItem(event.getEventId() + " - " + event.getEventName());
        }
        
        comboPanel.add(eventLabel);
        comboPanel.add(eventComboBox);
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        String[] columns = {"Registration ID", "Event", "Student", "Registration Date", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        JTable registrationsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(registrationsTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        tablePanel.add(comboPanel, BorderLayout.NORTH);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addButton = new JButton("Add Registration");
        JButton markButton = new JButton("Mark Attendance");
        JButton cancelButton = new JButton("Cancel Registration");
        JButton refreshButton = new JButton("Refresh");
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(addButton);
        buttonPanel.add(markButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to registrations panel
        registrationsPanel.add(titlePanel, BorderLayout.NORTH);
        registrationsPanel.add(tablePanel, BorderLayout.CENTER);
        registrationsPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Load all registrations initially
        loadAllRegistrationsTable(tableModel);
        
        // Home button action
        homeButton.addActionListener(e -> {
            showPanel("events");
            refreshEventsPanel();
        });
        
        // Events button action
        eventsButton.addActionListener(e -> {
            showPanel("events");
            refreshEventsPanel();
        });
        
        // Students button action
        studentsButton.addActionListener(e -> {
            showPanel("students");
            refreshStudentsPanel();
        });
        
        // Venues button action
        venuesButton.addActionListener(e -> {
            showPanel("venues");
            refreshVenuesPanel();
        });
        
        // Logout button action
        logoutButton.addActionListener(e -> {
            currentStudent = null;
            showLoginPanel();
        });
        
        // Refresh button action
        refreshButton.addActionListener(e -> refreshRegistrationsPanel());
        
        // Event combo box action
        eventComboBox.addActionListener(e -> {
            int selectedIndex = eventComboBox.getSelectedIndex();
            if (selectedIndex == 0) {
                // All events selected
                loadAllRegistrationsTable(tableModel);
            } else {
                // Specific event selected
                String selectedItem = (String) eventComboBox.getSelectedItem();
                int eventId = Integer.parseInt(selectedItem.split(" - ")[0]);
                loadEventRegistrationsTable(tableModel, eventId);
            }
        });
        
        // Add registration button action
        addButton.addActionListener(e -> showAddRegistrationDialog());
        
        // Mark attendance button action
        markButton.addActionListener(e -> {
            int selectedRow = registrationsTable.getSelectedRow();
            if (selectedRow >= 0) {
                int registrationId = (int) tableModel.getValueAt(selectedRow, 0);
                showMarkAttendanceDialog(registrationId);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select a registration to mark attendance.", 
                    "Mark Attendance", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Cancel registration button action
        cancelButton.addActionListener(e -> {
            int selectedRow = registrationsTable.getSelectedRow();
            if (selectedRow >= 0) {
                String eventStr = (String) tableModel.getValueAt(selectedRow, 1);
                String studentStr = (String) tableModel.getValueAt(selectedRow, 2);
                
                int eventId = Integer.parseInt(eventStr.split(" - ")[0]);
                int studentId = Integer.parseInt(studentStr.split(" - ")[0]);
                
                int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to cancel this registration?",
                    "Confirm Cancel", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean success = registrationManager.cancelRegistration(studentId, eventId);
                    if (success) {
                        JOptionPane.showMessageDialog(this,
                            "Registration canceled successfully!",
                            "Cancel Registration", JOptionPane.INFORMATION_MESSAGE);
                        refreshRegistrationsPanel();
                    } else {
                        JOptionPane.showMessageDialog(this,
                            "Failed to cancel registration.",
                            "Cancel Registration", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select a registration to cancel.", 
                    "Cancel Registration", JOptionPane.INFORMATION_MESSAGE);
            }
        });
    }
    
    // Initialize the my events panel (student view)
    private void initializeMyEventsPanel() {
        myEventsPanel = new JPanel(new BorderLayout());
        
        // Title panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("My Events Dashboard", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        // Navigation panel
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton myEventsButton = new JButton("My Events");
        JButton browseEventsButton = new JButton("Browse Events");
        JButton profileButton = new JButton("My Profile");
        JButton logoutButton = new JButton("Logout");
        
        navPanel.add(myEventsButton);
        navPanel.add(browseEventsButton);
        navPanel.add(profileButton);
        navPanel.add(logoutButton);
        
        titlePanel.add(navPanel, BorderLayout.SOUTH);
        
        // Welcome panel
        JPanel welcomePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel welcomeLabel = new JLabel("Welcome, Student!");
        welcomePanel.add(welcomeLabel);
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        String[] columns = {"Event ID", "Event Name", "Date", "Time", "Venue", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        JTable myEventsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(myEventsTable);
        tablePanel.add(welcomePanel, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton viewButton = new JButton("View Event Details");
        JButton cancelButton = new JButton("Cancel Registration");
        JButton refreshButton = new JButton("Refresh");
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to my events panel
        myEventsPanel.add(titlePanel, BorderLayout.NORTH);
        myEventsPanel.add(tablePanel, BorderLayout.CENTER);
        myEventsPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // My events button action
        myEventsButton.addActionListener(e -> {
            if (currentStudent != null) {
                refreshMyEventsPanel();
            }
        });
        
        // Browse events button action
        browseEventsButton.addActionListener(e -> showBrowseEventsDialog());
        
        // Profile button action
        profileButton.addActionListener(e -> {
            if (currentStudent != null) {
                showEditStudentDialog(currentStudent.getStudentId());
            }
        });
        
        // Logout button action
        logoutButton.addActionListener(e -> {
            currentStudent = null;
            showLoginPanel();
        });
        
        // Refresh button action
        refreshButton.addActionListener(e -> refreshMyEventsPanel());
        
        // View event details button action
        viewButton.addActionListener(e -> {
            int selectedRow = myEventsTable.getSelectedRow();
            if (selectedRow >= 0) {
                int eventId = (int) tableModel.getValueAt(selectedRow, 0);
                showEventDetailsDialog(eventId);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select an event to view details.", 
                    "View Event", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Cancel registration button action
        cancelButton.addActionListener(e -> {
            int selectedRow = myEventsTable.getSelectedRow();
            if (selectedRow >= 0 && currentStudent != null) {
                int eventId = (int) tableModel.getValueAt(selectedRow, 0);
                int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to cancel your registration for this event?",
                    "Confirm Cancel", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean success = registrationManager.cancelRegistration(
                        currentStudent.getStudentId(), eventId);
                    
                    if (success) {
                        JOptionPane.showMessageDialog(this,
                            "Registration canceled successfully!",
                            "Cancel Registration", JOptionPane.INFORMATION_MESSAGE);
                        refreshMyEventsPanel();
                    } else {
                        JOptionPane.showMessageDialog(this,
                            "Failed to cancel registration.",
                            "Cancel Registration", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Please select an event to cancel registration.", 
                    "Cancel Registration", JOptionPane.INFORMATION_MESSAGE);
            }
        });
    }
    
    // Show dialog to browse available events and register
    private void showBrowseEventsDialog() {
        if (currentStudent == null) {
            JOptionPane.showMessageDialog(this,
                "You must be logged in to browse events.",
                "Login Required", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Create a dialog for browsing events
        JDialog browseDialog = new JDialog(this, "Browse Events", true);
        browseDialog.setSize(800, 500);
        browseDialog.setLocationRelativeTo(this);
        browseDialog.setLayout(new BorderLayout());
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        String[] columns = {"Event ID", "Event Name", "Date", "Time", "Venue", "Available Spots", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        JTable eventsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(eventsTable);
        
        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        JButton refreshButton = new JButton("Show All");
        
        searchPanel.add(new JLabel("Search Events: "));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(refreshButton);
        
        tablePanel.add(searchPanel, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton viewButton = new JButton("View Details");
        JButton registerButton = new JButton("Register for Event");
        JButton closeButton = new JButton("Close");
        
        buttonPanel.add(viewButton);
        buttonPanel.add(registerButton);
        buttonPanel.add(closeButton);
        
        // Add panels to dialog
        browseDialog.add(tablePanel, BorderLayout.CENTER);
        browseDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Load upcoming events
        List<Event> upcomingEvents = eventManager.getUpcomingEvents();
        
        // Add events to table
        for (Event event : upcomingEvents) {
            Venue venue = venueManager.getVenueById(event.getVenueId());
            String venueName = venue != null ? venue.getVenueName() : "Unknown";
            
            int participantCount = eventManager.getEventParticipantCount(event.getEventId());
            int availableSpots = event.getMaxParticipants() - participantCount;
            
            tableModel.addRow(new Object[] {
                event.getEventId(),
                event.getEventName(),
                event.getEventDate(),
                event.getStartTime() + " - " + event.getEndTime(),
                venueName,
                availableSpots + "/" + event.getMaxParticipants(),
                event.getStatus()
            });
        }
        
        // Search button action
        searchButton.addActionListener(e -> {
            String keyword = searchField.getText();
            if (!keyword.isEmpty()) {
                List<Event> events = eventManager.searchEvents(keyword);
                tableModel.setRowCount(0); // Clear table
                
                for (Event event : events) {
                    Venue venue = venueManager.getVenueById(event.getVenueId());
                    String venueName = venue != null ? venue.getVenueName() : "Unknown";
                    
                    int participantCount = eventManager.getEventParticipantCount(event.getEventId());
                    int availableSpots = event.getMaxParticipants() - participantCount;
                    
                    tableModel.addRow(new Object[] {
                        event.getEventId(),
                        event.getEventName(),
                        event.getEventDate(),
                        event.getStartTime() + " - " + event.getEndTime(),
                        venueName,
                        availableSpots + "/" + event.getMaxParticipants(),
                        event.getStatus()
                    });
                }
            } else {
                JOptionPane.showMessageDialog(browseDialog, 
                    "Please enter a search keyword.", 
                    "Search Events", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Refresh button action
        refreshButton.addActionListener(e -> {
            tableModel.setRowCount(0); // Clear table
            
            List<Event> events = eventManager.getUpcomingEvents();
            
            for (Event event : events) {
                Venue venue = venueManager.getVenueById(event.getVenueId());
                String venueName = venue != null ? venue.getVenueName() : "Unknown";
                
                int participantCount = eventManager.getEventParticipantCount(event.getEventId());
                int availableSpots = event.getMaxParticipants() - participantCount;
                
                tableModel.addRow(new Object[] {
                    event.getEventId(),
                    event.getEventName(),
                    event.getEventDate(),
                    event.getStartTime() + " - " + event.getEndTime(),
                    venueName,
                    availableSpots + "/" + event.getMaxParticipants(),
                    event.getStatus()
                });
            }
        });
        
        // View details button action
        viewButton.addActionListener(e -> {
            int selectedRow = eventsTable.getSelectedRow();
            if (selectedRow >= 0) {
                int eventId = (int) tableModel.getValueAt(selectedRow, 0);
                showEventDetailsDialog(eventId);
            } else {
                JOptionPane.showMessageDialog(browseDialog, 
                    "Please select an event to view details.", 
                    "View Event", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Register button action
        registerButton.addActionListener(e -> {
            int selectedRow = eventsTable.getSelectedRow();
            if (selectedRow >= 0 && currentStudent != null) {
                int eventId = (int) tableModel.getValueAt(selectedRow, 0);
                
                // Check if student is already registered
                if (registrationManager.isStudentRegisteredForEvent(
                        currentStudent.getStudentId(), eventId)) {
                    JOptionPane.showMessageDialog(browseDialog,
                        "You are already registered for this event.",
                        "Already Registered", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                
                // Check if event is full
                if (eventManager.isEventFull(eventId)) {
                    JOptionPane.showMessageDialog(browseDialog,
                        "This event is full. No more registrations are allowed.",
                        "Event Full", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                int confirm = JOptionPane.showConfirmDialog(browseDialog,
                    "Are you sure you want to register for this event?",
                    "Confirm Registration", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    int registrationId = registrationManager.registerStudentForEvent(
                        eventId, currentStudent.getStudentId());
                    
                    if (registrationId > 0) {
                        JOptionPane.showMessageDialog(browseDialog,
                            "Registration successful!",
                            "Registration", JOptionPane.INFORMATION_MESSAGE);
                        
                        // Refresh the table
                        refreshButton.doClick();
                    } else {
                        JOptionPane.showMessageDialog(browseDialog,
                            "Registration failed.",
                            "Registration", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(browseDialog, 
                    "Please select an event to register for.", 
                    "Register for Event", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Close button action
        closeButton.addActionListener(e -> browseDialog.dispose());
        
        // Show the dialog
        browseDialog.setVisible(true);
    }
    // Show dialog to add a new event
    private void showAddEventDialog() {
        // Create a dialog for adding an event
        JDialog addEventDialog = new JDialog(this, "Add New Event", true);
        addEventDialog.setSize(500, 600);
        addEventDialog.setLocationRelativeTo(this);
        addEventDialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Event form fields
        JTextField nameField = new JTextField(20);
        JTextArea descriptionArea = new JTextArea(5, 20);
        descriptionArea.setLineWrap(true);
        JScrollPane descScrollPane = new JScrollPane(descriptionArea);
        
        JSpinner dateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
        dateSpinner.setEditor(dateEditor);
        
        JSpinner startTimeSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor startTimeEditor = new JSpinner.DateEditor(startTimeSpinner, "HH:mm");
        startTimeSpinner.setEditor(startTimeEditor);
        
        JSpinner endTimeSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor endTimeEditor = new JSpinner.DateEditor(endTimeSpinner, "HH:mm");
        endTimeSpinner.setEditor(endTimeEditor);
        
        // Venue combo box
        JComboBox<String> venueComboBox = new JComboBox<>();
        List<Venue> venues = venueManager.getAvailableVenues();
        for (Venue venue : venues) {
            venueComboBox.addItem(venue.getVenueId() + " - " + venue.getVenueName());
        }
        
        JSpinner maxParticipantsSpinner = new JSpinner(new SpinnerNumberModel(50, 1, 1000, 1));
        JTextField organizerField = new JTextField(20);
        
        // Create form field panels
        JPanel namePanel = createFormFieldPanel("Event Name:", nameField);
        JPanel descriptionPanel = createFormFieldPanel("Description:", descScrollPane);
        JPanel datePanel = createFormFieldPanel("Event Date:", dateSpinner);
        JPanel startTimePanel = createFormFieldPanel("Start Time:", startTimeSpinner);
        JPanel endTimePanel = createFormFieldPanel("End Time:", endTimeSpinner);
        JPanel venuePanel = createFormFieldPanel("Venue:", venueComboBox);
        JPanel maxParticipantsPanel = createFormFieldPanel("Max Participants:", maxParticipantsSpinner);
        JPanel organizerPanel = createFormFieldPanel("Organizer:", organizerField);
        
        // Add field panels to form panel
        formPanel.add(namePanel);
        formPanel.add(descriptionPanel);
        formPanel.add(datePanel);
        formPanel.add(startTimePanel);
        formPanel.add(endTimePanel);
        formPanel.add(venuePanel);
        formPanel.add(maxParticipantsPanel);
        formPanel.add(organizerPanel);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton createButton = new JButton("Create Event");
        JButton cancelButton = new JButton("Cancel");
        buttonPanel.add(createButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        addEventDialog.add(formPanel, BorderLayout.CENTER);
        addEventDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Create button action
        createButton.addActionListener(e -> {
            // Get values from form fields
            String eventName = nameField.getText();
            String description = descriptionArea.getText();
            java.util.Date eventDateUtil = (java.util.Date) dateSpinner.getValue();
            java.util.Date startTimeUtil = (java.util.Date) startTimeSpinner.getValue();
            java.util.Date endTimeUtil = (java.util.Date) endTimeSpinner.getValue();
            
            LocalDate eventDate = eventDateUtil.toInstant()
                .atZone(java.time.ZoneId.systemDefault()).toLocalDate();
            LocalTime startTime = startTimeUtil.toInstant()
                .atZone(java.time.ZoneId.systemDefault()).toLocalTime();
            LocalTime endTime = endTimeUtil.toInstant()
                .atZone(java.time.ZoneId.systemDefault()).toLocalTime();
            
            String venueString = (String) venueComboBox.getSelectedItem();
            int venueId = Integer.parseInt(venueString.split(" - ")[0]);
            
            int maxParticipants = (Integer) maxParticipantsSpinner.getValue();
            String organizer = organizerField.getText();
            
            // Validate form fields
            if (eventName.isEmpty() || description.isEmpty() || organizer.isEmpty()) {
                JOptionPane.showMessageDialog(addEventDialog,
                    "Please fill in all required fields.",
                    "Create Event Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if end time is after start time
            if (!endTime.isAfter(startTime)) {
                JOptionPane.showMessageDialog(addEventDialog,
                    "End time must be after start time.",
                    "Create Event Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if venue is available at the selected date and time
            if (!venueManager.isVenueAvailable(venueId, eventDate, startTime, endTime)) {
                JOptionPane.showMessageDialog(addEventDialog,
                    "The selected venue is not available at the specified date and time.",
                    "Create Event Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Create new event object
            Event event = new Event(
                eventName, description, eventDate, startTime, endTime,
                venueId, maxParticipants, organizer);
            
            // Add the event
            int eventId = eventManager.createEvent(event);
            
            if (eventId > 0) {
                // Event creation successful
                JOptionPane.showMessageDialog(addEventDialog,
                    "Event created successfully!",
                    "Create Event", JOptionPane.INFORMATION_MESSAGE);
                addEventDialog.dispose();
                
                // Refresh the events table
                refreshEventsPanel();
            } else {
                // Event creation failed
                JOptionPane.showMessageDialog(addEventDialog,
                    "Failed to create event.",
                    "Create Event Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> addEventDialog.dispose());
        
        // Show the dialog
        addEventDialog.setVisible(true);
    }
    
    // Show dialog to edit an event
    private void showEditEventDialog(int eventId) {
        // Get the event from database
        Event event = eventManager.getEventById(eventId);
        
        if (event == null) {
            JOptionPane.showMessageDialog(this,
                "Event not found!",
                "Edit Event Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Create a dialog for editing the event
        JDialog editEventDialog = new JDialog(this, "Edit Event", true);
        editEventDialog.setSize(500, 600);
        editEventDialog.setLocationRelativeTo(this);
        editEventDialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Event form fields
        JTextField nameField = new JTextField(event.getEventName(), 20);
        JTextArea descriptionArea = new JTextArea(event.getDescription(), 5, 20);
        descriptionArea.setLineWrap(true);
        JScrollPane descScrollPane = new JScrollPane(descriptionArea);
        
        // Date spinner
        java.util.Date eventDateUtil = java.util.Date.from(
            event.getEventDate().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant());
        JSpinner dateSpinner = new JSpinner(new SpinnerDateModel(eventDateUtil, null, null, java.util.Calendar.DAY_OF_MONTH));
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
        dateSpinner.setEditor(dateEditor);
        
        // Time spinners
        java.util.Date startTimeUtil = java.util.Date.from(
            event.getStartTime().atDate(LocalDate.now()).atZone(java.time.ZoneId.systemDefault()).toInstant());
        JSpinner startTimeSpinner = new JSpinner(new SpinnerDateModel(startTimeUtil, null, null, java.util.Calendar.HOUR_OF_DAY));
        JSpinner.DateEditor startTimeEditor = new JSpinner.DateEditor(startTimeSpinner, "HH:mm");
        startTimeSpinner.setEditor(startTimeEditor);
        
        java.util.Date endTimeUtil = java.util.Date.from(
            event.getEndTime().atDate(LocalDate.now()).atZone(java.time.ZoneId.systemDefault()).toInstant());
        JSpinner endTimeSpinner = new JSpinner(new SpinnerDateModel(endTimeUtil, null, null, java.util.Calendar.HOUR_OF_DAY));
        JSpinner.DateEditor endTimeEditor = new JSpinner.DateEditor(endTimeSpinner, "HH:mm");
        endTimeSpinner.setEditor(endTimeEditor);
        
        // Venue combo box
        JComboBox<String> venueComboBox = new JComboBox<>();
        List<Venue> venues = venueManager.getAllVenues(); // Get all venues for editing
        int selectedIndex = 0;
        for (int i = 0; i < venues.size(); i++) {
            Venue venue = venues.get(i);
            venueComboBox.addItem(venue.getVenueId() + " - " + venue.getVenueName());
            if (venue.getVenueId() == event.getVenueId()) {
                selectedIndex = i;
            }
        }
        venueComboBox.setSelectedIndex(selectedIndex);
        
        JSpinner maxParticipantsSpinner = new JSpinner(
            new SpinnerNumberModel(event.getMaxParticipants(), 1, 1000, 1));
        JTextField organizerField = new JTextField(event.getOrganizer(), 20);
        
        // Status combo box
        JComboBox<String> statusComboBox = new JComboBox<>(
            new String[]{"Upcoming", "Ongoing", "Completed", "Cancelled"});
        statusComboBox.setSelectedItem(event.getStatus());
        
        // Create form field panels
        JPanel namePanel = createFormFieldPanel("Event Name:", nameField);
        JPanel descriptionPanel = createFormFieldPanel("Description:", descScrollPane);
        JPanel datePanel = createFormFieldPanel("Event Date:", dateSpinner);
        JPanel startTimePanel = createFormFieldPanel("Start Time:", startTimeSpinner);
        JPanel endTimePanel = createFormFieldPanel("End Time:", endTimeSpinner);
        JPanel venuePanel = createFormFieldPanel("Venue:", venueComboBox);
        JPanel maxParticipantsPanel = createFormFieldPanel("Max Participants:", maxParticipantsSpinner);
        JPanel organizerPanel = createFormFieldPanel("Organizer:", organizerField);
        JPanel statusPanel = createFormFieldPanel("Status:", statusComboBox);
        
        // Add field panels to form panel
        formPanel.add(namePanel);
        formPanel.add(descriptionPanel);
        formPanel.add(datePanel);
        formPanel.add(startTimePanel);
        formPanel.add(endTimePanel);
        formPanel.add(venuePanel);
        formPanel.add(maxParticipantsPanel);
        formPanel.add(organizerPanel);
        formPanel.add(statusPanel);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton updateButton = new JButton("Update Event");
        JButton cancelButton = new JButton("Cancel");
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        editEventDialog.add(formPanel, BorderLayout.CENTER);
        editEventDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Update button action
        updateButton.addActionListener(e -> {
            // Get values from form fields
            String eventName = nameField.getText();
            String description = descriptionArea.getText();
            java.util.Date newEventDateUtil = (java.util.Date) dateSpinner.getValue();
            java.util.Date newStartTimeUtil = (java.util.Date) startTimeSpinner.getValue();
            java.util.Date newEndTimeUtil = (java.util.Date) endTimeSpinner.getValue();
            
            LocalDate newEventDate = newEventDateUtil.toInstant()
                .atZone(java.time.ZoneId.systemDefault()).toLocalDate();
            LocalTime newStartTime = newStartTimeUtil.toInstant()
                .atZone(java.time.ZoneId.systemDefault()).toLocalTime();
            LocalTime newEndTime = newEndTimeUtil.toInstant()
                .atZone(java.time.ZoneId.systemDefault()).toLocalTime();
            
            String venueString = (String) venueComboBox.getSelectedItem();
            int newVenueId = Integer.parseInt(venueString.split(" - ")[0]);
            
            int newMaxParticipants = (Integer) maxParticipantsSpinner.getValue();
            String newOrganizer = organizerField.getText();
            String newStatus = (String) statusComboBox.getSelectedItem();
            
            // Validate form fields
            if (eventName.isEmpty() || description.isEmpty() || newOrganizer.isEmpty()) {
                JOptionPane.showMessageDialog(editEventDialog,
                    "Please fill in all required fields.",
                    "Update Event Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if end time is after start time
            if (!newEndTime.isAfter(newStartTime)) {
                JOptionPane.showMessageDialog(editEventDialog,
                    "End time must be after start time.",
                    "Update Event Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if venue is available at the selected date and time (if changed)
            if (newVenueId != event.getVenueId() || 
                !newEventDate.equals(event.getEventDate()) ||
                !newStartTime.equals(event.getStartTime()) ||
                !newEndTime.equals(event.getEndTime())) {
                
                // Check if venue is available, excluding this event
                if (!isVenueAvailableForUpdateEvent(newVenueId, newEventDate, newStartTime, newEndTime, eventId)) {
                    JOptionPane.showMessageDialog(editEventDialog,
                        "The selected venue is not available at the specified date and time.",
                        "Update Event Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            
            // Update event object
            event.setEventName(eventName);
            event.setDescription(description);
            event.setEventDate(newEventDate);
            event.setStartTime(newStartTime);
            event.setEndTime(newEndTime);
            event.setVenueId(newVenueId);
            event.setMaxParticipants(newMaxParticipants);
            event.setOrganizer(newOrganizer);
            event.setStatus(newStatus);
            
            // Update the event
            boolean success = eventManager.updateEvent(event);
            
            if (success) {
                // Event update successful
                JOptionPane.showMessageDialog(editEventDialog,
                    "Event updated successfully!",
                    "Update Event", JOptionPane.INFORMATION_MESSAGE);
                editEventDialog.dispose();
                
                // Refresh the events table
                refreshEventsPanel();
            } else {
                // Event update failed
                JOptionPane.showMessageDialog(editEventDialog,
                    "Failed to update event.",
                    "Update Event Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> editEventDialog.dispose());
        
        // Show the dialog
        editEventDialog.setVisible(true);
    }
    
    // Show dialog to add a new venue
    private void showAddVenueDialog() {
        // Create a dialog for adding a venue
        JDialog addVenueDialog = new JDialog(this, "Add New Venue", true);
        addVenueDialog.setSize(500, 400);
        addVenueDialog.setLocationRelativeTo(this);
        addVenueDialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Venue form fields
        JTextField nameField = new JTextField(20);
        JSpinner capacitySpinner = new JSpinner(new SpinnerNumberModel(100, 1, 10000, 10));
        JTextField locationField = new JTextField(20);
        JTextArea facilitiesArea = new JTextArea(5, 20);
        facilitiesArea.setLineWrap(true);
        JScrollPane facilitiesScrollPane = new JScrollPane(facilitiesArea);
        
        // Create form field panels
        JPanel namePanel = createFormFieldPanel("Venue Name:", nameField);
        JPanel capacityPanel = createFormFieldPanel("Capacity:", capacitySpinner);
        JPanel locationPanel = createFormFieldPanel("Location:", locationField);
        JPanel facilitiesPanel = createFormFieldPanel("Facilities:", facilitiesScrollPane);
        
        // Add field panels to form panel
        formPanel.add(namePanel);
        formPanel.add(capacityPanel);
        formPanel.add(locationPanel);
        formPanel.add(facilitiesPanel);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton createButton = new JButton("Create Venue");
        JButton cancelButton = new JButton("Cancel");
        buttonPanel.add(createButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        addVenueDialog.add(formPanel, BorderLayout.CENTER);
        addVenueDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Create button action
        createButton.addActionListener(e -> {
            // Get values from form fields
            String venueName = nameField.getText();
            int capacity = (Integer) capacitySpinner.getValue();
            String location = locationField.getText();
            String facilities = facilitiesArea.getText();
            
            // Validate form fields
            if (venueName.isEmpty() || location.isEmpty()) {
                JOptionPane.showMessageDialog(addVenueDialog,
                    "Please fill in all required fields.",
                    "Create Venue Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Create new venue object
            Venue venue = new Venue(venueName, capacity, location, facilities);
            
            // Add the venue
            int venueId = venueManager.addVenue(venue);
            
            if (venueId > 0) {
                // Venue creation successful
                JOptionPane.showMessageDialog(addVenueDialog,
                    "Venue created successfully!",
                    "Create Venue", JOptionPane.INFORMATION_MESSAGE);
                addVenueDialog.dispose();
                
                // Refresh the venues table
                refreshVenuesPanel();
            } else {
                // Venue creation failed
                JOptionPane.showMessageDialog(addVenueDialog,
                    "Failed to create venue.",
                    "Create Venue Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> addVenueDialog.dispose());
        
        // Show the dialog
        addVenueDialog.setVisible(true);
    }
    
    // Helper method to check if a venue is available for updating an event
    private boolean isVenueAvailableForUpdateEvent(int venueId, LocalDate eventDate, 
            LocalTime startTime, LocalTime endTime, int currentEventId) {
        // Get all events for the venue on the specified date
        List<Event> events = eventManager.getAllEvents();
        Venue venue = venueManager.getVenueById(venueId);
        
        // Check if venue exists and is available
        if (venue == null || !"Available".equals(venue.getStatus())) {
            return false;
        }
        
        // Check for conflicts with other events
        for (Event event : events) {
            // Skip the current event being updated
            if (event.getEventId() == currentEventId) {
                continue;
            }
            
            // Check if event is at the same venue and date
            if (event.getVenueId() == venueId && event.getEventDate().equals(eventDate)) {
                // Check if the time slots overlap
                LocalTime eventStart = event.getStartTime();
                LocalTime eventEnd = event.getEndTime();
                
                // Time slots overlap if:
                // 1. New start time is within existing event time slot
                // 2. New end time is within existing event time slot
                // 3. New time slot completely contains existing event time slot
                if ((startTime.compareTo(eventStart) >= 0 && startTime.compareTo(eventEnd) < 0) ||
                    (endTime.compareTo(eventStart) > 0 && endTime.compareTo(eventEnd) <= 0) ||
                    (startTime.compareTo(eventStart) <= 0 && endTime.compareTo(eventEnd) >= 0)) {
                    return false; // Time slot conflict
                }
            }
        }
        
        return true; // No conflicts found
    }
    
    // Helper method to load events table
    private void loadEventsTable(DefaultTableModel tableModel) {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Get all events
        List<Event> events = eventManager.getAllEvents();
        
        // Add events to table
        for (Event event : events) {
            Venue venue = venueManager.getVenueById(event.getVenueId());
            String venueName = venue != null ? venue.getVenueName() : "Unknown";
            
            int participantCount = eventManager.getEventParticipantCount(event.getEventId());
            
            tableModel.addRow(new Object[] {
                event.getEventId(),
                event.getEventName(),
                event.getEventDate(),
                event.getStartTime() + " - " + event.getEndTime(),
                venueName,
                participantCount + "/" + event.getMaxParticipants(),
                event.getStatus()
            });
        }
    }
    
    // Helper method to load students table
    private void loadStudentsTable(DefaultTableModel tableModel) {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Get all students
        List<Student> students = studentManager.getAllStudents();
        
        // Add students to table
        for (Student student : students) {
            tableModel.addRow(new Object[] {
                student.getStudentId(),
                student.getRegistrationNumber(),
                student.getFullName(),
                student.getEmail(),
                student.getPhone(),
                student.getDepartment(),
                student.getYearOfStudy()
            });
        }
    }
    
    // Helper method to load venues table
    private void loadVenuesTable(DefaultTableModel tableModel) {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Get all venues
        List<Venue> venues = venueManager.getAllVenues();
        
        // Add venues to table
        for (Venue venue : venues) {
            tableModel.addRow(new Object[] {
                venue.getVenueId(),
                venue.getVenueName(),
                venue.getCapacity(),
                venue.getLocation(),
                venue.getFacilities(),
                venue.getStatus()
            });
        }
    }
    
    // Helper method to update events table with search results
    private void updateEventsTable(DefaultTableModel tableModel, List<Event> events) {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Add events to table
        for (Event event : events) {
            Venue venue = venueManager.getVenueById(event.getVenueId());
            String venueName = venue != null ? venue.getVenueName() : "Unknown";
            
            int participantCount = eventManager.getEventParticipantCount(event.getEventId());
            
            tableModel.addRow(new Object[] {
                event.getEventId(),
                event.getEventName(),
                event.getEventDate(),
                event.getStartTime() + " - " + event.getEndTime(),
                venueName,
                participantCount + "/" + event.getMaxParticipants(),
                event.getStatus()
            });
        }
    }
    
    // Helper method to update students table with search results
    private void updateStudentsTable(DefaultTableModel tableModel, List<Student> students) {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Add students to table
        for (Student student : students) {
            tableModel.addRow(new Object[] {
                student.getStudentId(),
                student.getRegistrationNumber(),
                student.getFullName(),
                student.getEmail(),
                student.getPhone(),
                student.getDepartment(),
                student.getYearOfStudy()
            });
        }
    }
    
    // Helper method to update venues table with search results
    private void updateVenuesTable(DefaultTableModel tableModel, List<Venue> venues) {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Add venues to table
        for (Venue venue : venues) {
            tableModel.addRow(new Object[] {
                venue.getVenueId(),
                venue.getVenueName(),
                venue.getCapacity(),
                venue.getLocation(),
                venue.getFacilities(),
                venue.getStatus()
            });
        }
    }
    
    // Helper method to load all registrations table
    private void loadAllRegistrationsTable(DefaultTableModel tableModel) {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Get all events
        List<Event> events = eventManager.getAllEvents();
        
        // For each event, get registrations
        for (Event event : events) {
            List<Registration> registrations = registrationManager.getRegistrationsByEvent(event.getEventId());
            
            for (Registration registration : registrations) {
                Student student = studentManager.getStudentById(registration.getStudentId());
                String studentName = student != null ? student.getStudentId() + " - " + student.getFullName() : "Unknown";
                
                tableModel.addRow(new Object[] {
                    registration.getRegistrationId(),
                    event.getEventId() + " - " + event.getEventName(),
                    studentName,
                    registration.getRegistrationDate(),
                    registration.getAttendanceStatus()
                });
            }
        }
    }
    
    // Helper method to load event registrations table
    private void loadEventRegistrationsTable(DefaultTableModel tableModel, int eventId) {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Get the event
        Event event = eventManager.getEventById(eventId);
        
        if (event != null) {
            // Get registrations for the event
            List<Registration> registrations = registrationManager.getRegistrationsByEvent(eventId);
            
            for (Registration registration : registrations) {
                Student student = studentManager.getStudentById(registration.getStudentId());
                String studentName = student != null ? student.getStudentId() + " - " + student.getFullName() : "Unknown";
                
                tableModel.addRow(new Object[] {
                    registration.getRegistrationId(),
                    event.getEventId() + " - " + event.getEventName(),
                    studentName,
                    registration.getRegistrationDate(),
                    registration.getAttendanceStatus()
                });
            }
        }
    }
    
    // Helper method to load student events table
    private void loadStudentEventsTable(DefaultTableModel tableModel, int studentId) {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Get events registered by student
        List<Event> events = registrationManager.getRegisteredEventsByStudent(studentId);
        
        // Add events to table
        for (Event event : events) {
            Venue venue = venueManager.getVenueById(event.getVenueId());
            String venueName = venue != null ? venue.getVenueName() : "Unknown";
            
            // Get registration status
            String status = "Unknown";
            List<Registration> registrations = registrationManager.getRegistrationsByStudent(studentId);
            for (Registration registration : registrations) {
                if (registration.getEventId() == event.getEventId()) {
                    status = registration.getAttendanceStatus();
                    break;
                }
            }
            
            tableModel.addRow(new Object[] {
                event.getEventId(),
                event.getEventName(),
                event.getEventDate(),
                event.getStartTime() + " - " + event.getEndTime(),
                venueName,
                status
            });
        }
    }
    
    // Refresh events panel
    private void refreshEventsPanel() {
        DefaultTableModel tableModel = (DefaultTableModel) 
            ((JTable) ((JScrollPane) eventsPanel.getComponent(1)).getViewport().getView()).getModel();
        loadEventsTable(tableModel);
    }
    
    // Refresh students panel
    private void refreshStudentsPanel() {
        DefaultTableModel tableModel = (DefaultTableModel) 
            ((JTable) ((JScrollPane) studentsPanel.getComponent(1)).getViewport().getView()).getModel();
        loadStudentsTable(tableModel);
    }
    
    // Refresh venues panel
    private void refreshVenuesPanel() {
        DefaultTableModel tableModel = (DefaultTableModel) 
            ((JTable) ((JScrollPane) venuesPanel.getComponent(1)).getViewport().getView()).getModel();
        loadVenuesTable(tableModel);
    }
    
    // Refresh registrations panel
private void refreshRegistrationsPanel() {
    DefaultTableModel tableModel = (DefaultTableModel) 
        ((JTable) ((JScrollPane) ((JPanel) registrationsPanel.getComponent(1)).getComponent(1)).getViewport().getView()).getModel();
    loadAllRegistrationsTable(tableModel);
    
    // Refresh event combo box
    JComboBox<String> eventComboBox = (JComboBox<String>) 
        ((JPanel) ((JPanel) registrationsPanel.getComponent(1)).getComponent(0)).getComponent(1);
    eventComboBox.removeAllItems();
    eventComboBox.addItem("-- All Events --");
    
    List<Event> events = eventManager.getAllEvents();
    for (Event event : events) {
        eventComboBox.addItem(event.getEventId() + " - " + event.getEventName());
    }
}

// Refresh my events panel
private void refreshMyEventsPanel() {
    if (currentStudent != null) {
        // Update welcome label
        JLabel welcomeLabel = (JLabel) ((JPanel) ((JPanel) myEventsPanel.getComponent(1)).getComponent(0)).getComponent(0);
        welcomeLabel.setText("Welcome, " + currentStudent.getFullName() + "!");
        
        // Refresh table
        DefaultTableModel tableModel = (DefaultTableModel) 
            ((JTable) ((JScrollPane) ((JPanel) myEventsPanel.getComponent(1)).getComponent(1)).getViewport().getView()).getModel();
        loadStudentEventsTable(tableModel, currentStudent.getStudentId());
    }
}

    
    // Show event details dialog
    private void showEventDetailsDialog(int eventId) {
        // Get the event from database
        Event event = eventManager.getEventById(eventId);
        
        if (event == null) {
            JOptionPane.showMessageDialog(this,
                "Event not found!",
                "View Event Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Get venue information
        Venue venue = venueManager.getVenueById(event.getVenueId());
        String venueName = venue != null ? venue.getVenueName() : "Unknown";
        String venueLocation = venue != null ? venue.getLocation() : "Unknown";
        
        // Get participant count
        int participantCount = eventManager.getEventParticipantCount(event.getEventId());
        
        // Create a dialog for viewing event details
        JDialog detailsDialog = new JDialog(this, "Event Details", true);
        detailsDialog.setSize(600, 500);
        detailsDialog.setLocationRelativeTo(this);
        detailsDialog.setLayout(new BorderLayout());
        
        // Details panel
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Event title
        JLabel titleLabel = new JLabel(event.getEventName());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Event details
        JPanel infoPanel = new JPanel(new GridLayout(0, 2, 10, 5));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        infoPanel.add(new JLabel("Date:"));
        infoPanel.add(new JLabel(event.getEventDate().toString()));
        
        infoPanel.add(new JLabel("Time:"));
        infoPanel.add(new JLabel(event.getStartTime() + " - " + event.getEndTime()));
        
        infoPanel.add(new JLabel("Venue:"));
        infoPanel.add(new JLabel(venueName));
        
        infoPanel.add(new JLabel("Location:"));
        infoPanel.add(new JLabel(venueLocation));
        
        infoPanel.add(new JLabel("Participants:"));
        infoPanel.add(new JLabel(participantCount + " / " + event.getMaxParticipants()));
        
        infoPanel.add(new JLabel("Organizer:"));
        infoPanel.add(new JLabel(event.getOrganizer()));
        
        infoPanel.add(new JLabel("Status:"));
        infoPanel.add(new JLabel(event.getStatus()));
        
        // Description
        JLabel descLabel = new JLabel("Description:");
        descLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JTextArea descArea = new JTextArea(event.getDescription());
        descArea.setEditable(false);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        descArea.setBackground(detailsPanel.getBackground());
        JScrollPane descScroll = new JScrollPane(descArea);
        descScroll.setBorder(BorderFactory.createEmptyBorder());
        descScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Registration status (for student view)
        JPanel regPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        regPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel regLabel = new JLabel("Registration Status: ");
        JLabel regStatusLabel = new JLabel("Not Registered");
        
        if (currentStudent != null) {
            boolean isRegistered = registrationManager.isStudentRegisteredForEvent(
                currentStudent.getStudentId(), event.getEventId());
            
            if (isRegistered) {
                // Find registration status
                List<Registration> registrations = registrationManager.getRegistrationsByStudent(
                    currentStudent.getStudentId());
                
                for (Registration reg : registrations) {
                    if (reg.getEventId() == event.getEventId()) {
                        regStatusLabel.setText(reg.getAttendanceStatus());
                        break;
                    }
                }
            }
        }
        
        regPanel.add(regLabel);
        regPanel.add(regStatusLabel);
        
        // Add components to details panel
        detailsPanel.add(titleLabel);
        detailsPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        detailsPanel.add(infoPanel);
        detailsPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        detailsPanel.add(descLabel);
        detailsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        detailsPanel.add(descScroll);
        
        if (currentStudent != null) {
            detailsPanel.add(Box.createRigidArea(new Dimension(0, 10)));
            detailsPanel.add(regPanel);
        }
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        // Register button (for student view)
        if (currentStudent != null) {
            boolean isRegistered = registrationManager.isStudentRegisteredForEvent(
                currentStudent.getStudentId(), event.getEventId());
            
            if (!isRegistered && "Upcoming".equals(event.getStatus())) {
                JButton registerButton = new JButton("Register for Event");
                
                registerButton.addActionListener(e -> {
                    // Check if event is full
                    if (eventManager.isEventFull(event.getEventId())) {
                        JOptionPane.showMessageDialog(detailsDialog,
                            "This event is full. No more registrations are allowed.",
                            "Event Full", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    
                    int confirm = JOptionPane.showConfirmDialog(detailsDialog,
                        "Are you sure you want to register for this event?",
                        "Confirm Registration", JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        int registrationId = registrationManager.registerStudentForEvent(
                            event.getEventId(), currentStudent.getStudentId());
                        
                        if (registrationId > 0) {
                            JOptionPane.showMessageDialog(detailsDialog,
                                "Registration successful!",
                                "Registration", JOptionPane.INFORMATION_MESSAGE);
                            
                            // Update registration status
                            regStatusLabel.setText("Registered");
                            
                            // Remove register button
                            buttonPanel.remove(registerButton);
                            buttonPanel.revalidate();
                            buttonPanel.repaint();
                            
                            // Refresh my events panel
                            refreshMyEventsPanel();
                        } else {
                            JOptionPane.showMessageDialog(detailsDialog,
                                "Registration failed.",
                                "Registration", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                });
                
                buttonPanel.add(registerButton);
            }
        }
        
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> detailsDialog.dispose());
        buttonPanel.add(closeButton);
        
        // Add panels to dialog
        detailsDialog.add(detailsPanel, BorderLayout.CENTER);
        detailsDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Show the dialog
        detailsDialog.setVisible(true);
    }
    
    // Show edit student dialog
    private void showEditStudentDialog(int studentId) {
        // Get the student from database
        Student student = studentManager.getStudentById(studentId);
        
        if (student == null) {
            JOptionPane.showMessageDialog(this,
                "Student not found!",
                "Edit Student Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Create a dialog for editing the student
        JDialog editStudentDialog = new JDialog(this, "Edit Student", true);
        editStudentDialog.setSize(500, 600);
        editStudentDialog.setLocationRelativeTo(this);
        editStudentDialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Student form fields
        JTextField regNoField = new JTextField(student.getRegistrationNumber(), 20);
        regNoField.setEditable(false); // Registration number cannot be changed
        
        JTextField firstNameField = new JTextField(student.getFirstName(), 20);
        JTextField lastNameField = new JTextField(student.getLastName(), 20);
        JTextField emailField = new JTextField(student.getEmail(), 20);
        JTextField phoneField = new JTextField(student.getPhone(), 20);
        JTextField departmentField = new JTextField(student.getDepartment(), 20);
        
        JComboBox<Integer> yearComboBox = new JComboBox<>(new Integer[]{1, 2, 3, 4, 5});
        yearComboBox.setSelectedItem(student.getYearOfStudy());
        
        JPasswordField passwordField = new JPasswordField(20);
        JPasswordField confirmPasswordField = new JPasswordField(20);
        
        // Create form field panels
        JPanel regNoPanel = createFormFieldPanel("Registration Number:", regNoField);
        JPanel firstNamePanel = createFormFieldPanel("First Name:", firstNameField);
        JPanel lastNamePanel = createFormFieldPanel("Last Name:", lastNameField);
        JPanel emailPanel = createFormFieldPanel("Email:", emailField);
        JPanel phonePanel = createFormFieldPanel("Phone:", phoneField);
        JPanel departmentPanel = createFormFieldPanel("Department:", departmentField);
        JPanel yearPanel = createFormFieldPanel("Year of Study:", yearComboBox);
        JPanel passwordPanel = createFormFieldPanel("New Password:", passwordField);
        JPanel confirmPasswordPanel = createFormFieldPanel("Confirm Password:", confirmPasswordField);
        
        // Add field panels to form panel
        formPanel.add(regNoPanel);
        formPanel.add(firstNamePanel);
        formPanel.add(lastNamePanel);
        formPanel.add(emailPanel);
        formPanel.add(phonePanel);
        formPanel.add(departmentPanel);
        formPanel.add(yearPanel);
        formPanel.add(passwordPanel);
        formPanel.add(confirmPasswordPanel);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton updateButton = new JButton("Update Student");
        JButton cancelButton = new JButton("Cancel");
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        editStudentDialog.add(formPanel, BorderLayout.CENTER);
        editStudentDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Update button action
        updateButton.addActionListener(e -> {
            // Get values from form fields
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();
            String department = departmentField.getText();
            int yearOfStudy = (Integer) yearComboBox.getSelectedItem();
            String password = new String(passwordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());
            
            // Validate form fields
            if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(editStudentDialog,
                    "Please fill in all required fields.",
                    "Update Student Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Update student object
            student.setFirstName(firstName);
            student.setLastName(lastName);
            student.setEmail(email);
            student.setPhone(phone);
            student.setDepartment(department);
            student.setYearOfStudy(yearOfStudy);
            
            // Update the student
            boolean success = studentManager.updateStudent(student);
            
            // Update password if provided
            if (!password.isEmpty()) {
                // Check if passwords match
                if (!password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(editStudentDialog,
                        "Passwords do not match. Please try again.",
                        "Update Password Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                boolean passwordSuccess = studentManager.updatePassword(student.getStudentId(), password);
                success = success && passwordSuccess;
            }
            
            if (success) {
                // Student update successful
                JOptionPane.showMessageDialog(editStudentDialog,
                    "Student information updated successfully!",
                    "Update Student", JOptionPane.INFORMATION_MESSAGE);
                editStudentDialog.dispose();
                
                // Refresh the students table if admin view
                if (currentStudent == null) {
                    refreshStudentsPanel();
                } else {
                    // If student is updating their own profile
                    refreshMyEventsPanel();
                }
            } else {
                // Student update failed
                JOptionPane.showMessageDialog(editStudentDialog,
                    "Failed to update student information.",
                    "Update Student Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> editStudentDialog.dispose());
        
        // Show the dialog
        editStudentDialog.setVisible(true);
    }
    
    // Show dialog to edit a venue
    private void showEditVenueDialog(int venueId) {
        // Get the venue from database
        Venue venue = venueManager.getVenueById(venueId);
        
        if (venue == null) {
            JOptionPane.showMessageDialog(this,
                "Venue not found!",
                "Edit Venue Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Create a dialog for editing the venue
        JDialog editVenueDialog = new JDialog(this, "Edit Venue", true);
        editVenueDialog.setSize(500, 400);
        editVenueDialog.setLocationRelativeTo(this);
        editVenueDialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Venue form fields
        JTextField nameField = new JTextField(venue.getVenueName(), 20);
        JSpinner capacitySpinner = new JSpinner(new SpinnerNumberModel(venue.getCapacity(), 1, 10000, 10));
        JTextField locationField = new JTextField(venue.getLocation(), 20);
        JTextArea facilitiesArea = new JTextArea(venue.getFacilities(), 5, 20);
        facilitiesArea.setLineWrap(true);
        JScrollPane facilitiesScrollPane = new JScrollPane(facilitiesArea);
        
        // Status combo box
        JComboBox<String> statusComboBox = new JComboBox<>(
            new String[]{"Available", "Unavailable", "Under Maintenance"});
        statusComboBox.setSelectedItem(venue.getStatus());
        
        // Create form field panels
        JPanel namePanel = createFormFieldPanel("Venue Name:", nameField);
        JPanel capacityPanel = createFormFieldPanel("Capacity:", capacitySpinner);
        JPanel locationPanel = createFormFieldPanel("Location:", locationField);
        JPanel facilitiesPanel = createFormFieldPanel("Facilities:", facilitiesScrollPane);
        JPanel statusPanel = createFormFieldPanel("Status:", statusComboBox);
        
        // Add field panels to form panel
        formPanel.add(namePanel);
        formPanel.add(capacityPanel);
        formPanel.add(locationPanel);
        formPanel.add(facilitiesPanel);
        formPanel.add(statusPanel);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton updateButton = new JButton("Update Venue");
        JButton cancelButton = new JButton("Cancel");
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        editVenueDialog.add(formPanel, BorderLayout.CENTER);
        editVenueDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Update button action
        updateButton.addActionListener(e -> {
            // Get values from form fields
            String venueName = nameField.getText();
            int capacity = (Integer) capacitySpinner.getValue();
            String location = locationField.getText();
            String facilities = facilitiesArea.getText();
            String status = (String) statusComboBox.getSelectedItem();
            
            // Validate form fields
            if (venueName.isEmpty() || location.isEmpty()) {
                JOptionPane.showMessageDialog(editVenueDialog,
                    "Please fill in all required fields.",
                    "Update Venue Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Update venue object
            venue.setVenueName(venueName);
            venue.setCapacity(capacity);
            venue.setLocation(location);
            venue.setFacilities(facilities);
            venue.setStatus(status);
            
            // Update the venue
            boolean success = venueManager.updateVenue(venue);
            
            if (success) {
                // Venue update successful
                JOptionPane.showMessageDialog(editVenueDialog,
                    "Venue updated successfully!",
                    "Update Venue", JOptionPane.INFORMATION_MESSAGE);
                editVenueDialog.dispose();
                
                // Refresh the venues table
                refreshVenuesPanel();
            } else {
                // Venue update failed
                JOptionPane.showMessageDialog(editVenueDialog,
                    "Failed to update venue.",
                    "Update Venue Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> editVenueDialog.dispose());
        
        // Show the dialog
        editVenueDialog.setVisible(true);
    }
    
    // Show dialog to view registrations for an event
    private void showEventRegistrationsDialog(int eventId) {
        // Get the event from database
        Event event = eventManager.getEventById(eventId);
        
        if (event == null) {
            JOptionPane.showMessageDialog(this,
                "Event not found!",
                "View Registrations Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Create a dialog for viewing event registrations
        JDialog registrationsDialog = new JDialog(this, "Event Registrations", true);
        registrationsDialog.setSize(700, 500);
        registrationsDialog.setLocationRelativeTo(this);
        registrationsDialog.setLayout(new BorderLayout());
        
        // Event info panel
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        infoPanel.add(new JLabel("Event: " + event.getEventName()));
        infoPanel.add(new JLabel("  |  Date: " + event.getEventDate()));
        infoPanel.add(new JLabel("  |  Status: " + event.getStatus()));
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        String[] columns = {"Registration ID", "Student", "Registration Date", "Attendance Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        JTable registrationsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(registrationsTable);
        tablePanel.add(infoPanel, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Load registrations
        List<Registration> registrations = registrationManager.getRegistrationsByEvent(eventId);
        
        for (Registration registration : registrations) {
            Student student = studentManager.getStudentById(registration.getStudentId());
            String studentName = student != null ? student.getRegistrationNumber() + " - " + student.getFullName() : "Unknown";
            
            tableModel.addRow(new Object[] {
                registration.getRegistrationId(),
                studentName,
                registration.getRegistrationDate(),
                registration.getAttendanceStatus()
            });
        }
        
        // Stats panel
        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        int totalRegistrations = registrations.size();
        int presentCount = 0;
        int absentCount = 0;
        
        for (Registration registration : registrations) {
            if ("Present".equals(registration.getAttendanceStatus())) {
                presentCount++;
            } else if ("Absent".equals(registration.getAttendanceStatus())) {
                absentCount++;
            }
        }
        
        statsPanel.add(new JLabel("Total Registrations: " + totalRegistrations));
        statsPanel.add(new JLabel("  |  Present: " + presentCount));
        statsPanel.add(new JLabel("  |  Absent: " + absentCount));
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton markButton = new JButton("Mark Attendance");
        JButton exportButton = new JButton("Export List");
        JButton closeButton = new JButton("Close");
        
        buttonPanel.add(markButton);
        buttonPanel.add(exportButton);
        buttonPanel.add(closeButton);
        
        // Add panels to dialog
        registrationsDialog.add(tablePanel, BorderLayout.CENTER);
        registrationsDialog.add(statsPanel, BorderLayout.NORTH);
        registrationsDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Mark attendance button action
        markButton.addActionListener(e -> {
            int selectedRow = registrationsTable.getSelectedRow();
            if (selectedRow >= 0) {
                int registrationId = (int) tableModel.getValueAt(selectedRow, 0);
                showMarkAttendanceDialog(registrationId);
                
                // Refresh the table after marking attendance
                tableModel.setRowCount(0);
                
                List<Registration> updatedRegistrations = registrationManager.getRegistrationsByEvent(eventId);
                
                for (Registration registration : updatedRegistrations) {
                    Student student = studentManager.getStudentById(registration.getStudentId());
                    String studentName = student != null ? student.getRegistrationNumber() + " - " + student.getFullName() : "Unknown";
                    
                    tableModel.addRow(new Object[] {
                        registration.getRegistrationId(),
                        studentName,
                        registration.getRegistrationDate(),
                        registration.getAttendanceStatus()
                    });
                }
            } else {
                JOptionPane.showMessageDialog(registrationsDialog, 
                    "Please select a registration to mark attendance.", 
                    "Mark Attendance", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Export button action
        exportButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(registrationsDialog,
                "Export functionality would be implemented here.",
                "Export List", JOptionPane.INFORMATION_MESSAGE);
        });
        
        // Close button action
        closeButton.addActionListener(e -> registrationsDialog.dispose());
        
        // Show the dialog
        registrationsDialog.setVisible(true);
    }
    
    // Show dialog to view registrations for a student
    private void showStudentRegistrationsDialog(int studentId) {
        // Get the student from database
        Student student = studentManager.getStudentById(studentId);
        
        if (student == null) {
            JOptionPane.showMessageDialog(this,
                "Student not found!",
                "View Registrations Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Create a dialog for viewing student registrations
        JDialog registrationsDialog = new JDialog(this, "Student Registrations", true);
        registrationsDialog.setSize(700, 500);
        registrationsDialog.setLocationRelativeTo(this);
        registrationsDialog.setLayout(new BorderLayout());
        
        // Student info panel
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        infoPanel.add(new JLabel("Student: " + student.getFullName()));
        infoPanel.add(new JLabel("  |  Registration: " + student.getRegistrationNumber()));
        infoPanel.add(new JLabel("  |  Department: " + student.getDepartment()));
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        String[] columns = {"Registration ID", "Event", "Date", "Registration Date", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        JTable registrationsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(registrationsTable);
        tablePanel.add(infoPanel, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Load registrations
        List<Registration> registrations = registrationManager.getRegistrationsByStudent(studentId);
        
        for (Registration registration : registrations) {
            Event event = eventManager.getEventById(registration.getEventId());
            String eventName = event != null ? event.getEventName() : "Unknown";
            String eventDate = event != null ? event.getEventDate().toString() : "Unknown";
            
            tableModel.addRow(new Object[] {
                registration.getRegistrationId(),
                event.getEventId() + " - " + eventName,
                eventDate,
                registration.getRegistrationDate(),
                registration.getAttendanceStatus()
            });
        }
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton cancelButton = new JButton("Cancel Registration");
        JButton closeButton = new JButton("Close");
        
        buttonPanel.add(cancelButton);
        buttonPanel.add(closeButton);
        
        // Add panels to dialog
        registrationsDialog.add(tablePanel, BorderLayout.CENTER);
        registrationsDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Cancel registration button action
        cancelButton.addActionListener(e -> {
            int selectedRow = registrationsTable.getSelectedRow();
            if (selectedRow >= 0) {
                String eventStr = (String) tableModel.getValueAt(selectedRow, 1);
                int eventId = Integer.parseInt(eventStr.split(" - ")[0]);
                
                int confirm = JOptionPane.showConfirmDialog(registrationsDialog,
                    "Are you sure you want to cancel this registration?",
                    "Confirm Cancel", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean success = registrationManager.cancelRegistration(studentId, eventId);
                    if (success) {
                        JOptionPane.showMessageDialog(registrationsDialog,
                            "Registration canceled successfully!",
                            "Cancel Registration", JOptionPane.INFORMATION_MESSAGE);
                        tableModel.removeRow(selectedRow);
                    } else {
                        JOptionPane.showMessageDialog(registrationsDialog,
                            "Failed to cancel registration.",
                            "Cancel Registration", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(registrationsDialog, 
                    "Please select a registration to cancel.", 
                    "Cancel Registration", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        // Close button action
        closeButton.addActionListener(e -> registrationsDialog.dispose());
        
        // Show the dialog
        registrationsDialog.setVisible(true);
    }
    
    // Show dialog to mark attendance
    private void showMarkAttendanceDialog(int registrationId) {
        // Create a dialog for marking attendance
        JDialog markAttendanceDialog = new JDialog(this, "Mark Attendance", true);
        markAttendanceDialog.setSize(300, 150);
        markAttendanceDialog.setLocationRelativeTo(this);
        markAttendanceDialog.setLayout(new BorderLayout());
        
        // Status panel
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel statusLabel = new JLabel("Attendance Status:");
        JComboBox<String> statusComboBox = new JComboBox<>(
            new String[]{"Registered", "Present", "Absent", "Excused"});
        
        statusPanel.add(statusLabel);
        statusPanel.add(statusComboBox);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");
        
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        markAttendanceDialog.add(statusPanel, BorderLayout.CENTER);
        markAttendanceDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Save button action
        saveButton.addActionListener(e -> {
            String status = (String) statusComboBox.getSelectedItem();
            
            boolean success = registrationManager.updateAttendanceStatus(registrationId, status);
            
            if (success) {
                JOptionPane.showMessageDialog(markAttendanceDialog,
                    "Attendance marked successfully!",
                    "Mark Attendance", JOptionPane.INFORMATION_MESSAGE);
                markAttendanceDialog.dispose();
                
                // Refresh registrations panel
                refreshRegistrationsPanel();
            } else {
                JOptionPane.showMessageDialog(markAttendanceDialog,
                    "Failed to mark attendance.",
                    "Mark Attendance Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> markAttendanceDialog.dispose());
        
        // Show the dialog
        markAttendanceDialog.setVisible(true);
    }
    
    // Show dialog to add a registration
    private void showAddRegistrationDialog() {
        // Create a dialog for adding a registration
        JDialog addRegistrationDialog = new JDialog(this, "Add Registration", true);
        addRegistrationDialog.setSize(400, 200);
        addRegistrationDialog.setLocationRelativeTo(this);
        addRegistrationDialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Event combo box
        JComboBox<String> eventComboBox = new JComboBox<>();
        List<Event> events = eventManager.getUpcomingEvents();
        for (Event event : events) {
            eventComboBox.addItem(event.getEventId() + " - " + event.getEventName());
        }
        
        // Student combo box
        JComboBox<String> studentComboBox = new JComboBox<>();
        List<Student> students = studentManager.getAllStudents();
        for (Student student : students) {
            studentComboBox.addItem(student.getStudentId() + " - " + student.getFullName());
        }
        
        // Create form field panels
        JPanel eventPanel = createFormFieldPanel("Event:", eventComboBox);
        JPanel studentPanel = createFormFieldPanel("Student:", studentComboBox);
        
        // Add field panels to form panel
        formPanel.add(eventPanel);
        formPanel.add(studentPanel);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton registerButton = new JButton("Register");
        JButton cancelButton = new JButton("Cancel");
        buttonPanel.add(registerButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        addRegistrationDialog.add(formPanel, BorderLayout.CENTER);
        addRegistrationDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Register button action
        registerButton.addActionListener(e -> {
            // Check if both event and student are selected
            if (eventComboBox.getSelectedIndex() == -1 || studentComboBox.getSelectedIndex() == -1) {
                JOptionPane.showMessageDialog(addRegistrationDialog,
                    "Please select both an event and a student.",
                    "Add Registration Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Get selected event and student IDs
            String eventString = (String) eventComboBox.getSelectedItem();
            String studentString = (String) studentComboBox.getSelectedItem();
            
            int eventId = Integer.parseInt(eventString.split(" - ")[0]);
            int studentId = Integer.parseInt(studentString.split(" - ")[0]);
            
            // Check if student is already registered for the event
            if (registrationManager.isStudentRegisteredForEvent(studentId, eventId)) {
                JOptionPane.showMessageDialog(addRegistrationDialog,
                    "This student is already registered for this event.",
                    "Add Registration Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if event is full
            if (eventManager.isEventFull(eventId)) {
                JOptionPane.showMessageDialog(addRegistrationDialog,
                    "This event is full. No more registrations are allowed.",
                    "Add Registration Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Register student for event
            int registrationId = registrationManager.registerStudentForEvent(eventId, studentId);
            
            if (registrationId > 0) {
                JOptionPane.showMessageDialog(addRegistrationDialog,
                    "Registration successful!",
                    "Add Registration", JOptionPane.INFORMATION_MESSAGE);
                addRegistrationDialog.dispose();
                
                // Refresh registrations panel
                refreshRegistrationsPanel();
            } else {
                JOptionPane.showMessageDialog(addRegistrationDialog,
                    "Registration failed.",
                    "Add Registration Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> addRegistrationDialog.dispose());
        
        // Show the dialog
        addRegistrationDialog.setVisible(true);
    }
    
    // Main method (if you want to run the UI separately for testing)
    public static void main(String[] args) {
        // Set look and feel to the system look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Create and display the main frame
        SwingUtilities.invokeLater(() -> new MainFrame());
    }
}
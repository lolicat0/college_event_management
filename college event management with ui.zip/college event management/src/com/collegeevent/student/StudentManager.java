// Student Management Module
// This module handles student-related operations

package com.collegeevent.student;

import com.collegeevent.database.DatabaseManager;
import com.collegeevent.model.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class StudentManager {
    private DatabaseManager dbManager;
    
    /**
     * Constructor - Initialize with database manager
     * @param dbManager Database manager instance
     */
    public StudentManager(DatabaseManager dbManager) {
        this.dbManager = dbManager;
    }
    
    /**
     * Register a new student
     * @param student The student object to be registered
     * @return int The ID of the newly registered student, or -1 if failed
     */
    public int registerStudent(Student student) {
        int studentId = -1;
        Connection conn = dbManager.getConnection();
        
        try {
            // Check if the registration number or email already exists
            if (isRegistrationNumberExists(student.getRegistrationNumber()) || 
                isEmailExists(student.getEmail())) {
                System.out.println("Registration number or email already exists!");
                return studentId;
            }
            
            String query = "INSERT INTO students (registration_number, first_name, last_name, "
                         + "email, phone, department, year_of_study, password) "
                         + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, student.getRegistrationNumber());
            pstmt.setString(2, student.getFirstName());
            pstmt.setString(3, student.getLastName());
            pstmt.setString(4, student.getEmail());
            pstmt.setString(5, student.getPhone());
            pstmt.setString(6, student.getDepartment());
            pstmt.setInt(7, student.getYearOfStudy());
            pstmt.setString(8, student.getPassword());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the ID of the newly inserted student
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    studentId = rs.getInt(1);
                }
                rs.close();
            }
            
            pstmt.close();
            System.out.println("Student registered successfully with ID: " + studentId);
            
        } catch (SQLException e) {
            System.out.println("Error registering student!");
            e.printStackTrace();
        }
        
        return studentId;
    }
    
    /**
     * Check if a registration number already exists
     * @param registrationNumber The registration number to check
     * @return boolean True if exists, false otherwise
     */
    public boolean isRegistrationNumberExists(String registrationNumber) {
        Connection conn = dbManager.getConnection();
        boolean exists = false;
        
        try {
            String query = "SELECT COUNT(*) FROM students WHERE registration_number = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, registrationNumber);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next() && rs.getInt(1) > 0) {
                exists = true;
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error checking registration number!");
            e.printStackTrace();
        }
        
        return exists;
    }
    
    /**
     * Check if an email already exists
     * @param email The email to check
     * @return boolean True if exists, false otherwise
     */
    public boolean isEmailExists(String email) {
        Connection conn = dbManager.getConnection();
        boolean exists = false;
        
        try {
            String query = "SELECT COUNT(*) FROM students WHERE email = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, email);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next() && rs.getInt(1) > 0) {
                exists = true;
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error checking email!");
            e.printStackTrace();
        }
        
        return exists;
    }
    
    /**
     * Get a student by ID
     * @param studentId The ID of the student to retrieve
     * @return Student object if found, null otherwise
     */
    public Student getStudentById(int studentId) {
        Student student = null;
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM students WHERE student_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, studentId);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                student = new Student();
                student.setStudentId(rs.getInt("student_id"));
                student.setRegistrationNumber(rs.getString("registration_number"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getString("phone"));
                student.setDepartment(rs.getString("department"));
                student.setYearOfStudy(rs.getInt("year_of_study"));
                student.setPassword(rs.getString("password"));
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting student by ID!");
            e.printStackTrace();
        }
        
        return student;
    }
    
    /**
     * Get a student by registration number
     * @param registrationNumber The registration number of the student
     * @return Student object if found, null otherwise
     */
    public Student getStudentByRegistrationNumber(String registrationNumber) {
        Student student = null;
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM students WHERE registration_number = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, registrationNumber);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                student = new Student();
                student.setStudentId(rs.getInt("student_id"));
                student.setRegistrationNumber(rs.getString("registration_number"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getString("phone"));
                student.setDepartment(rs.getString("department"));
                student.setYearOfStudy(rs.getInt("year_of_study"));
                student.setPassword(rs.getString("password"));
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting student by registration number!");
            e.printStackTrace();
        }
        
        return student;
    }
    
    /**
     * Get all students
     * @return List of all students
     */
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM students ORDER BY last_name, first_name";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            while (rs.next()) {
                Student student = new Student();
                student.setStudentId(rs.getInt("student_id"));
                student.setRegistrationNumber(rs.getString("registration_number"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getString("phone"));
                student.setDepartment(rs.getString("department"));
                student.setYearOfStudy(rs.getInt("year_of_study"));
                student.setPassword(rs.getString("password"));
                
                students.add(student);
            }
            
            rs.close();
            stmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting all students!");
            e.printStackTrace();
        }
        
        return students;
    }
    
    /**
     * Update a student's information
     * @param student The student object with updated information
     * @return boolean Success or failure
     */
    public boolean updateStudent(Student student) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "UPDATE students SET first_name = ?, last_name = ?, email = ?, "
                         + "phone = ?, department = ?, year_of_study = ? WHERE student_id = ?";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, student.getFirstName());
            pstmt.setString(2, student.getLastName());
            pstmt.setString(3, student.getEmail());
            pstmt.setString(4, student.getPhone());
            pstmt.setString(5, student.getDepartment());
            pstmt.setInt(6, student.getYearOfStudy());
            pstmt.setInt(7, student.getStudentId());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Student updated successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error updating student!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Update a student's password
     * @param studentId The ID of the student
     * @param newPassword The new password
     * @return boolean Success or failure
     */
    public boolean updatePassword(int studentId, String newPassword) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "UPDATE students SET password = ? WHERE student_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, newPassword);
            pstmt.setInt(2, studentId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Password updated successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error updating password!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Delete a student by ID
     * @param studentId The ID of the student to delete
     * @return boolean Success or failure
     */
    public boolean deleteStudent(int studentId) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "DELETE FROM students WHERE student_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, studentId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Student deleted successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error deleting student!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Authenticate a student by registration number and password
     * @param registrationNumber The registration number
     * @param password The password
     * @return Student object if authentication successful, null otherwise
     */
    public Student authenticateStudent(String registrationNumber, String password) {
        Student student = null;
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM students WHERE registration_number = ? AND password = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, registrationNumber);
            pstmt.setString(2, password);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                student = new Student();
                student.setStudentId(rs.getInt("student_id"));
                student.setRegistrationNumber(rs.getString("registration_number"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getString("phone"));
                student.setDepartment(rs.getString("department"));
                student.setYearOfStudy(rs.getInt("year_of_study"));
                student.setPassword(rs.getString("password"));
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error authenticating student!");
            e.printStackTrace();
        }
        
        return student;
    }
    
    /**
     * Search students by name or registration number
     * @param keyword The search keyword
     * @return List of matching students
     */
    public List<Student> searchStudents(String keyword) {
        List<Student> students = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM students WHERE registration_number LIKE ? "
                         + "OR first_name LIKE ? OR last_name LIKE ? "
                         + "ORDER BY last_name, first_name";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            String searchPattern = "%" + keyword + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Student student = new Student();
                student.setStudentId(rs.getInt("student_id"));
                student.setRegistrationNumber(rs.getString("registration_number"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getString("phone"));
                student.setDepartment(rs.getString("department"));
                student.setYearOfStudy(rs.getInt("year_of_study"));
                student.setPassword(rs.getString("password"));
                
                students.add(student);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error searching students!");
            e.printStackTrace();
        }
        
        return students;
    }
}
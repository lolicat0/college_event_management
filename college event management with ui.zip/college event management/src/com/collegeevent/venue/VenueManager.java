package com.collegeevent.venue;

import com.collegeevent.database.DatabaseManager;
import com.collegeevent.model.Venue;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class VenueManager {
    private DatabaseManager dbManager;
    
    /**
     * Constructor - Initialize with database manager
     * @param dbManager Database manager instance
     */
    public VenueManager(DatabaseManager dbManager) {
        this.dbManager = dbManager;
    }
    
    /**
     * Add a new venue
     * @param venue The venue object to be added
     * @return int The ID of the newly added venue, or -1 if failed
     */
    public int addVenue(Venue venue) {
        int venueId = -1;
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "INSERT INTO venues (venue_name, capacity, location, facilities, status) "
                         + "VALUES (?, ?, ?, ?, ?)";
            
            PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, venue.getVenueName());
            pstmt.setInt(2, venue.getCapacity());
            pstmt.setString(3, venue.getLocation());
            pstmt.setString(4, venue.getFacilities());
            pstmt.setString(5, venue.getStatus());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the ID of the newly inserted venue
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    venueId = rs.getInt(1);
                }
                rs.close();
            }
            
            pstmt.close();
            System.out.println("Venue added successfully with ID: " + venueId);
            
        } catch (SQLException e) {
            System.out.println("Error adding venue!");
            e.printStackTrace();
        }
        
        return venueId;
    }
    
    /**
     * Get a venue by ID
     * @param venueId The ID of the venue to retrieve
     * @return Venue object if found, null otherwise
     */
    public Venue getVenueById(int venueId) {
        Venue venue = null;
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM venues WHERE venue_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, venueId);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                venue = new Venue();
                venue.setVenueId(rs.getInt("venue_id"));
                venue.setVenueName(rs.getString("venue_name"));
                venue.setCapacity(rs.getInt("capacity"));
                venue.setLocation(rs.getString("location"));
                venue.setFacilities(rs.getString("facilities"));
                venue.setStatus(rs.getString("status"));
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting venue by ID!");
            e.printStackTrace();
        }
        
        return venue;
    }
    
    /**
     * Get all venues
     * @return List of all venues
     */
    public List<Venue> getAllVenues() {
        List<Venue> venues = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM venues ORDER BY venue_name";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            while (rs.next()) {
                Venue venue = new Venue();
                venue.setVenueId(rs.getInt("venue_id"));
                venue.setVenueName(rs.getString("venue_name"));
                venue.setCapacity(rs.getInt("capacity"));
                venue.setLocation(rs.getString("location"));
                venue.setFacilities(rs.getString("facilities"));
                venue.setStatus(rs.getString("status"));
                
                venues.add(venue);
            }
            
            rs.close();
            stmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting all venues!");
            e.printStackTrace();
        }
        
        return venues;
    }
    
    /**
     * Get available venues
     * @return List of available venues
     */
    public List<Venue> getAvailableVenues() {
        List<Venue> venues = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM venues WHERE status = 'Available' ORDER BY venue_name";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            while (rs.next()) {
                Venue venue = new Venue();
                venue.setVenueId(rs.getInt("venue_id"));
                venue.setVenueName(rs.getString("venue_name"));
                venue.setCapacity(rs.getInt("capacity"));
                venue.setLocation(rs.getString("location"));
                venue.setFacilities(rs.getString("facilities"));
                venue.setStatus(rs.getString("status"));
                
                venues.add(venue);
            }
            
            rs.close();
            stmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting available venues!");
            e.printStackTrace();
        }
        
        return venues;
    }
    
    /**
     * Update a venue's information
     * @param venue The venue object with updated information
     * @return boolean Success or failure
     */
    public boolean updateVenue(Venue venue) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "UPDATE venues SET venue_name = ?, capacity = ?, location = ?, "
                         + "facilities = ?, status = ? WHERE venue_id = ?";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, venue.getVenueName());
            pstmt.setInt(2, venue.getCapacity());
            pstmt.setString(3, venue.getLocation());
            pstmt.setString(4, venue.getFacilities());
            pstmt.setString(5, venue.getStatus());
            pstmt.setInt(6, venue.getVenueId());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Venue updated successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error updating venue!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Update a venue's status
     * @param venueId The ID of the venue
     * @param status The new status
     * @return boolean Success or failure
     */
    public boolean updateVenueStatus(int venueId, String status) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "UPDATE venues SET status = ? WHERE venue_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, status);
            pstmt.setInt(2, venueId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Venue status updated successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error updating venue status!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Delete a venue by ID
     * @param venueId The ID of the venue to delete
     * @return boolean Success or failure
     */
    public boolean deleteVenue(int venueId) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            // First check if venue is being used in any events
            String checkQuery = "SELECT COUNT(*) FROM events WHERE venue_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setInt(1, venueId);
            
            ResultSet rs = checkStmt.executeQuery();
            boolean venueInUse = false;
            
            if (rs.next() && rs.getInt(1) > 0) {
                venueInUse = true;
                System.out.println("Cannot delete venue as it is being used in events!");
            }
            
            rs.close();
            checkStmt.close();
            
            if (!venueInUse) {
                String deleteQuery = "DELETE FROM venues WHERE venue_id = ?";
                PreparedStatement deleteStmt = conn.prepareStatement(deleteQuery);
                deleteStmt.setInt(1, venueId);
                
                int rowsAffected = deleteStmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    success = true;
                    System.out.println("Venue deleted successfully!");
                }
                
                deleteStmt.close();
            }
            
        } catch (SQLException e) {
            System.out.println("Error deleting venue!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Search venues by name or location
     * @param keyword The search keyword
     * @return List of matching venues
     */
    public List<Venue> searchVenues(String keyword) {
        List<Venue> venues = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM venues WHERE venue_name LIKE ? OR location LIKE ? "
                         + "ORDER BY venue_name";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            String searchPattern = "%" + keyword + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Venue venue = new Venue();
                venue.setVenueId(rs.getInt("venue_id"));
                venue.setVenueName(rs.getString("venue_name"));
                venue.setCapacity(rs.getInt("capacity"));
                venue.setLocation(rs.getString("location"));
                venue.setFacilities(rs.getString("facilities"));
                venue.setStatus(rs.getString("status"));
                
                venues.add(venue);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error searching venues!");
            e.printStackTrace();
        }
        
        return venues;
    }
    
    /**
     * Check if a venue is available on a specific date and time
     * @param venueId The ID of the venue
     * @param eventDate The date to check
     * @param startTime The start time
     * @param endTime The end time
     * @return boolean True if available, false otherwise
     */
    public boolean isVenueAvailable(int venueId, LocalDate eventDate, LocalTime startTime, LocalTime endTime) {
        Connection conn = dbManager.getConnection();
        boolean isAvailable = true;
        
        try {
            // Check if venue exists and is marked as available
            String venueQuery = "SELECT status FROM venues WHERE venue_id = ?";
            PreparedStatement venueStmt = conn.prepareStatement(venueQuery);
            venueStmt.setInt(1, venueId);
            
            ResultSet venueRs = venueStmt.executeQuery();
            
            if (venueRs.next()) {
                String status = venueRs.getString("status");
                if (!status.equals("Available")) {
                    isAvailable = false;
                }
            } else {
                // Venue does not exist
                isAvailable = false;
            }
            
            venueRs.close();
            venueStmt.close();
            
            if (isAvailable) {
                // Check if venue is already booked for an event on the same date and time
                String eventQuery = "SELECT * FROM events WHERE venue_id = ? AND event_date = ? "
                                  + "AND ((start_time <= ? AND end_time > ?) "
                                  + "OR (start_time < ? AND end_time >= ?) "
                                  + "OR (start_time >= ? AND end_time <= ?))";
                
                PreparedStatement eventStmt = conn.prepareStatement(eventQuery);
                eventStmt.setInt(1, venueId);
                eventStmt.setDate(2, Date.valueOf(eventDate));
                eventStmt.setTime(3, Time.valueOf(startTime));
                eventStmt.setTime(4, Time.valueOf(startTime));
                eventStmt.setTime(5, Time.valueOf(endTime));
                eventStmt.setTime(6, Time.valueOf(endTime));
                eventStmt.setTime(7, Time.valueOf(startTime));
                eventStmt.setTime(8, Time.valueOf(endTime));
                
                ResultSet eventRs = eventStmt.executeQuery();
                
                if (eventRs.next()) {
                    // Found a conflicting event
                    isAvailable = false;
                }
                
                eventRs.close();
                eventStmt.close();
            }
            
        } catch (SQLException e) {
            System.out.println("Error checking venue availability!");
            e.printStackTrace();
            isAvailable = false; // Assume not available in case of error
        }
        
        return isAvailable;
    }
    
    /**
     * Get all venues with minimum capacity
     * @param minCapacity The minimum capacity required
     * @return List of venues with capacity >= minCapacity
     */
    public List<Venue> getVenuesByCapacity(int minCapacity) {
        List<Venue> venues = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM venues WHERE capacity >= ? AND status = 'Available' "
                         + "ORDER BY capacity";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, minCapacity);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Venue venue = new Venue();
                venue.setVenueId(rs.getInt("venue_id"));
                venue.setVenueName(rs.getString("venue_name"));
                venue.setCapacity(rs.getInt("capacity"));
                venue.setLocation(rs.getString("location"));
                venue.setFacilities(rs.getString("facilities"));
                venue.setStatus(rs.getString("status"));
                
                venues.add(venue);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting venues by capacity!");
            e.printStackTrace();
        }
        
        return venues;
    }
}
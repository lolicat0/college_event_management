package com.collegeevent.registration;

import com.collegeevent.database.DatabaseManager;
import com.collegeevent.model.Registration;
import com.collegeevent.model.Student;
import com.collegeevent.model.Event;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class RegistrationManager {
    private DatabaseManager dbManager;
    
    /**
     * Constructor - Initialize with database manager
     * @param dbManager Database manager instance
     */
    public RegistrationManager(DatabaseManager dbManager) {
        this.dbManager = dbManager;
    }
    
    /**
     * Register a student for an event
     * @param eventId The ID of the event
     * @param studentId The ID of the student
     * @return int The ID of the new registration, or -1 if failed
     */
    public int registerStudentForEvent(int eventId, int studentId) {
        int registrationId = -1;
        Connection conn = dbManager.getConnection();
        
        try {
            // Check if student is already registered for this event
            if (isStudentRegisteredForEvent(studentId, eventId)) {
                System.out.println("Student is already registered for this event!");
                return registrationId;
            }
            
            String query = "INSERT INTO registrations (event_id, student_id, registration_date, attendance_status) "
                         + "VALUES (?, ?, ?, ?)";
            
            PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, eventId);
            pstmt.setInt(2, studentId);
            pstmt.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            pstmt.setString(4, "Registered");
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the ID of the newly inserted registration
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    registrationId = rs.getInt(1);
                }
                rs.close();
            }
            
            pstmt.close();
            System.out.println("Student registered for event successfully with ID: " + registrationId);
            
        } catch (SQLException e) {
            System.out.println("Error registering student for event!");
            e.printStackTrace();
        }
        
        return registrationId;
    }
    
    /**
     * Check if a student is already registered for an event
     * @param studentId The ID of the student
     * @param eventId The ID of the event
     * @return boolean True if already registered, false otherwise
     */
    public boolean isStudentRegisteredForEvent(int studentId, int eventId) {
        Connection conn = dbManager.getConnection();
        boolean isRegistered = false;
        
        try {
            String query = "SELECT COUNT(*) FROM registrations WHERE student_id = ? AND event_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, eventId);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next() && rs.getInt(1) > 0) {
                isRegistered = true;
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error checking if student is registered for event!");
            e.printStackTrace();
        }
        
        return isRegistered;
    }
    
    /**
     * Cancel a student's registration for an event
     * @param studentId The ID of the student
     * @param eventId The ID of the event
     * @return boolean Success or failure
     */
    public boolean cancelRegistration(int studentId, int eventId) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "DELETE FROM registrations WHERE student_id = ? AND event_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, eventId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Registration canceled successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error canceling registration!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Get all registrations for an event
     * @param eventId The ID of the event
     * @return List of registrations for the event
     */
    public List<Registration> getRegistrationsByEvent(int eventId) {
        List<Registration> registrations = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM registrations WHERE event_id = ? ORDER BY registration_date";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, eventId);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Registration registration = new Registration();
                registration.setRegistrationId(rs.getInt("registration_id"));
                registration.setEventId(rs.getInt("event_id"));
                registration.setStudentId(rs.getInt("student_id"));
                registration.setRegistrationDate(rs.getTimestamp("registration_date").toLocalDateTime());
                registration.setAttendanceStatus(rs.getString("attendance_status"));
                
                registrations.add(registration);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting registrations by event!");
            e.printStackTrace();
        }
        
        return registrations;
    }
    
    /**
     * Get all registrations for a student
     * @param studentId The ID of the student
     * @return List of registrations for the student
     */
    public List<Registration> getRegistrationsByStudent(int studentId) {
        List<Registration> registrations = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT * FROM registrations WHERE student_id = ? ORDER BY registration_date DESC";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, studentId);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Registration registration = new Registration();
                registration.setRegistrationId(rs.getInt("registration_id"));
                registration.setEventId(rs.getInt("event_id"));
                registration.setStudentId(rs.getInt("student_id"));
                registration.setRegistrationDate(rs.getTimestamp("registration_date").toLocalDateTime());
                registration.setAttendanceStatus(rs.getString("attendance_status"));
                
                registrations.add(registration);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting registrations by student!");
            e.printStackTrace();
        }
        
        return registrations;
    }
    
    /**
     * Get a list of registered students for an event
     * @param eventId The ID of the event
     * @return List of students registered for the event
     */
    public List<Student> getRegisteredStudentsForEvent(int eventId) {
        List<Student> students = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT s.* FROM students s "
                         + "JOIN registrations r ON s.student_id = r.student_id "
                         + "WHERE r.event_id = ? "
                         + "ORDER BY s.last_name, s.first_name";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, eventId);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Student student = new Student();
                student.setStudentId(rs.getInt("student_id"));
                student.setRegistrationNumber(rs.getString("registration_number"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getString("phone"));
                student.setDepartment(rs.getString("department"));
                student.setYearOfStudy(rs.getInt("year_of_study"));
                student.setPassword(rs.getString("password"));
                
                students.add(student);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting registered students for event!");
            e.printStackTrace();
        }
        
        return students;
    }
    /**
     * Get a list of events registered by a student
     * @param studentId The ID of the student
     * @return List of events registered by the student
     */
    public List<Event> getRegisteredEventsByStudent(int studentId) {
        List<Event> events = new ArrayList<>();
        Connection conn = dbManager.getConnection();
        
        try {
            String query = "SELECT e.* FROM events e "
                         + "JOIN registrations r ON e.event_id = r.event_id "
                         + "WHERE r.student_id = ? "
                         + "ORDER BY e.event_date, e.start_time";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, studentId);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Event event = new Event();
                event.setEventId(rs.getInt("event_id"));
                event.setEventName(rs.getString("event_name"));
                event.setDescription(rs.getString("description"));
                event.setEventDate(rs.getDate("event_date").toLocalDate());
                event.setStartTime(rs.getTime("start_time").toLocalTime());
                event.setEndTime(rs.getTime("end_time").toLocalTime());
                event.setVenueId(rs.getInt("venue_id"));
                event.setMaxParticipants(rs.getInt("max_participants"));
                event.setOrganizer(rs.getString("organizer"));
                event.setStatus(rs.getString("status"));
                
                events.add(event);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting registered events by student!");
            e.printStackTrace();
        }
        
        return events;
    }
    
    /**
     * Update attendance status for a registration
     * @param registrationId The ID of the registration
     * @param status The new attendance status
     * @return boolean Success or failure
     */
    public boolean updateAttendanceStatus(int registrationId, String status) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "UPDATE registrations SET attendance_status = ? WHERE registration_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, status);
            pstmt.setInt(2, registrationId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Attendance status updated successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error updating attendance status!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Mark attendance for a student at an event
     * @param studentId The ID of the student
     * @param eventId The ID of the event
     * @param status The attendance status (e.g., "Present", "Absent")
     * @return boolean Success or failure
     */
    public boolean markAttendance(int studentId, int eventId, String status) {
        Connection conn = dbManager.getConnection();
        boolean success = false;
        
        try {
            String query = "UPDATE registrations SET attendance_status = ? "
                         + "WHERE student_id = ? AND event_id = ?";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, status);
            pstmt.setInt(2, studentId);
            pstmt.setInt(3, eventId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Attendance marked successfully!");
            }
            
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error marking attendance!");
            e.printStackTrace();
        }
        
        return success;
    }
    
    /**
     * Get attendance count for an event by status
     * @param eventId The ID of the event
     * @param status The attendance status
     * @return int Count of students with the specified status
     */
    public int getAttendanceCountByStatus(int eventId, String status) {
        Connection conn = dbManager.getConnection();
        int count = 0;
        
        try {
            String query = "SELECT COUNT(*) FROM registrations "
                         + "WHERE event_id = ? AND attendance_status = ?";
            
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, eventId);
            pstmt.setString(2, status);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                count = rs.getInt(1);
            }
            
            rs.close();
            pstmt.close();
            
        } catch (SQLException e) {
            System.out.println("Error getting attendance count by status!");
            e.printStackTrace();
        }
        
        return count;
    }
}
package main.java.com.collegeevent;

import main.java.com.collegeevent.view.MainView;

/**
 * Main class for College Event Management System
 */
public class Main {
    
    /**
     * Main method to start the application
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        // Display a welcome message
        System.out.println("\n\n");
        System.out.println("*********************************************");
        System.out.println("*                                           *");
        System.out.println("*     COLLEGE EVENT MANAGEMENT SYSTEM       *");
        System.out.println("*                                           *");
        System.out.println("*********************************************");
        System.out.println("\n\n");
        
        // Start the application by displaying the main menu
        MainView mainView = new MainView();
        mainView.displayMainMenu();
    }
}
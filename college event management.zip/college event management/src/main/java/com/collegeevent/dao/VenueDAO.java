package main.java.com.collegeevent.dao;

import main.java.com.collegeevent.model.Venue;
import main.java.com.collegeevent.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Venue entity
 */
public class VenueDAO {
    
    /**
     * Create a new venue
     * @param venue Venue object to create
     * @return The created venue with ID
     * @throws SQLException if database operation fails
     */
    public Venue createVenue(Venue venue) throws SQLException {
        String query = "INSERT INTO venues (venue_name, location, capacity, facilities) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, venue.getVenueName());
            stmt.setString(2, venue.getLocation());
            stmt.setInt(3, venue.getCapacity());
            stmt.setString(4, venue.getFacilities());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating venue failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    venue.setVenueId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating venue failed, no ID obtained.");
                }
            }
            
            return venue;
        }
    }
    
    /**
     * Get venue by ID
     * @param venueId ID of the venue to retrieve
     * @return Venue object or null if not found
     * @throws SQLException if database operation fails
     */
    public Venue getVenueById(int venueId) throws SQLException {
        String query = "SELECT * FROM venues WHERE venue_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, venueId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToVenue(rs);
                }
            }
        }
        return null;
    }
    
    /**
     * Get all venues
     * @return List of venues
     * @throws SQLException if database operation fails
     */
    public List<Venue> getAllVenues() throws SQLException {
        String query = "SELECT * FROM venues ORDER BY venue_name";
        
        List<Venue> venues = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                venues.add(mapResultSetToVenue(rs));
            }
        }
        
        return venues;
    }
    
    /**
     * Update a venue
     * @param venue Venue object to update
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateVenue(Venue venue) throws SQLException {
        String query = "UPDATE venues SET venue_name = ?, location = ?, capacity = ?, facilities = ? WHERE venue_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, venue.getVenueName());
            stmt.setString(2, venue.getLocation());
            stmt.setInt(3, venue.getCapacity());
            stmt.setString(4, venue.getFacilities());
            stmt.setInt(5, venue.getVenueId());
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Delete a venue
     * @param venueId ID of the venue to delete
     * @return true if deleted successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean deleteVenue(int venueId) throws SQLException {
        String query = "DELETE FROM venues WHERE venue_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, venueId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Get venues by capacity
     * @param minCapacity Minimum capacity required
     * @return List of venues with sufficient capacity
     * @throws SQLException if database operation fails
     */
    public List<Venue> getVenuesByCapacity(int minCapacity) throws SQLException {
        String query = "SELECT * FROM venues WHERE capacity >= ? ORDER BY capacity";
        
        List<Venue> venues = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, minCapacity);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    venues.add(mapResultSetToVenue(rs));
                }
            }
        }
        
        return venues;
    }
    
    /**
     * Search venues by name or location
     * @param searchTerm Term to search for
     * @return List of matching venues
     * @throws SQLException if database operation fails
     */
    public List<Venue> searchVenues(String searchTerm) throws SQLException {
        String query = "SELECT * FROM venues WHERE venue_name LIKE ? OR location LIKE ? ORDER BY venue_name";
        
        List<Venue> venues = new ArrayList<>();
        String searchPattern = "%" + searchTerm + "%";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    venues.add(mapResultSetToVenue(rs));
                }
            }
        }
        
        return venues;
    }
    
    /**
     * Map ResultSet to Venue object
     * @param rs ResultSet containing venue data
     * @return Venue object
     * @throws SQLException if database operation fails
     */
    private Venue mapResultSetToVenue(ResultSet rs) throws SQLException {
        Venue venue = new Venue();
        
        venue.setVenueId(rs.getInt("venue_id"));
        venue.setVenueName(rs.getString("venue_name"));
        venue.setLocation(rs.getString("location"));
        venue.setCapacity(rs.getInt("capacity"));
        venue.setFacilities(rs.getString("facilities"));
        
        return venue;
    }
}
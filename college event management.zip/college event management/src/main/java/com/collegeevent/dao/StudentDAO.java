package main.java.com.collegeevent.dao;

import main.java.com.collegeevent.model.Student;
import main.java.com.collegeevent.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Student entity
 */
public class StudentDAO {
    
    /**
     * Create a new student
     * @param student Student object to create
     * @return The created student with ID
     * @throws SQLException if database operation fails
     */
    public Student createStudent(Student student) throws SQLException {
        String query = "INSERT INTO students (roll_number, first_name, last_name, email, phone, department, year_of_study) " +
                      "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, student.getRollNumber());
            stmt.setString(2, student.getFirstName());
            stmt.setString(3, student.getLastName());
            stmt.setString(4, student.getEmail());
            stmt.setString(5, student.getPhone());
            stmt.setString(6, student.getDepartment());
            stmt.setInt(7, student.getYearOfStudy());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating student failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    student.setStudentId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating student failed, no ID obtained.");
                }
            }
            
            return student;
        }
    }
    
    /**
     * Get student by ID
     * @param studentId ID of the student to retrieve
     * @return Student object or null if not found
     * @throws SQLException if database operation fails
     */
    public Student getStudentById(int studentId) throws SQLException {
        String query = "SELECT * FROM students WHERE student_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, studentId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToStudent(rs);
                }
            }
        }
        return null;
    }
    
    /**
     * Get student by roll number
     * @param rollNumber Roll number of the student
     * @return Student object or null if not found
     * @throws SQLException if database operation fails
     */
    public Student getStudentByRollNumber(String rollNumber) throws SQLException {
        String query = "SELECT * FROM students WHERE roll_number = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, rollNumber);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToStudent(rs);
                }
            }
        }
        return null;
    }
    
    /**
     * Get student by email
     * @param email Email of the student
     * @return Student object or null if not found
     * @throws SQLException if database operation fails
     */
    public Student getStudentByEmail(String email) throws SQLException {
        String query = "SELECT * FROM students WHERE email = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, email);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToStudent(rs);
                }
            }
        }
        return null;
    }
    
    /**
     * Get all students
     * @return List of students
     * @throws SQLException if database operation fails
     */
    public List<Student> getAllStudents() throws SQLException {
        String query = "SELECT * FROM students ORDER BY department, year_of_study, last_name, first_name";
        
        List<Student> students = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                students.add(mapResultSetToStudent(rs));
            }
        }
        
        return students;
    }
    
    /**
     * Update a student
     * @param student Student object to update
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateStudent(Student student) throws SQLException {
        String query = "UPDATE students SET roll_number = ?, first_name = ?, last_name = ?, " +
                      "email = ?, phone = ?, department = ?, year_of_study = ? " +
                      "WHERE student_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, student.getRollNumber());
            stmt.setString(2, student.getFirstName());
            stmt.setString(3, student.getLastName());
            stmt.setString(4, student.getEmail());
            stmt.setString(5, student.getPhone());
            stmt.setString(6, student.getDepartment());
            stmt.setInt(7, student.getYearOfStudy());
            stmt.setInt(8, student.getStudentId());
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Delete a student
     * @param studentId ID of the student to delete
     * @return true if deleted successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean deleteStudent(int studentId) throws SQLException {
        String query = "DELETE FROM students WHERE student_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, studentId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Search students by name, roll number, email, or department
     * @param searchTerm Term to search for
     * @return List of matching students
     * @throws SQLException if database operation fails
     */
    public List<Student> searchStudents(String searchTerm) throws SQLException {
        String query = "SELECT * FROM students WHERE " +
                      "roll_number LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR " +
                      "email LIKE ? OR department LIKE ? " +
                      "ORDER BY department, year_of_study, last_name, first_name";
        
        List<Student> students = new ArrayList<>();
        String searchPattern = "%" + searchTerm + "%";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);
            stmt.setString(4, searchPattern);
            stmt.setString(5, searchPattern);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    students.add(mapResultSetToStudent(rs));
                }
            }
        }
        
        return students;
    }
    
    /**
     * Get students by department
     * @param department Department name
     * @return List of students in the department
     * @throws SQLException if database operation fails
     */
    public List<Student> getStudentsByDepartment(String department) throws SQLException {
        String query = "SELECT * FROM students WHERE department = ? " +
                      "ORDER BY year_of_study, last_name, first_name";
        
        List<Student> students = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, department);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    students.add(mapResultSetToStudent(rs));
                }
            }
        }
        
        return students;
    }
    
    /**
     * Map ResultSet to Student object
     * @param rs ResultSet containing student data
     * @return Student object
     * @throws SQLException if database operation fails
     */
    private Student mapResultSetToStudent(ResultSet rs) throws SQLException {
        Student student = new Student();
        
        student.setStudentId(rs.getInt("student_id"));
        student.setRollNumber(rs.getString("roll_number"));
        student.setFirstName(rs.getString("first_name"));
        student.setLastName(rs.getString("last_name"));
        student.setEmail(rs.getString("email"));
        student.setPhone(rs.getString("phone"));
        student.setDepartment(rs.getString("department"));
        student.setYearOfStudy(rs.getInt("year_of_study"));
        
        return student;
    }
}
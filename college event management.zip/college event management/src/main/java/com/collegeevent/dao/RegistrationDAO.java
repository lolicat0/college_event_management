package main.java.com.collegeevent.dao;

import main.java.com.collegeevent.model.Registration;
import main.java.com.collegeevent.util.DatabaseUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Registration entity
 */
public class RegistrationDAO {
    
    /**
     * Create a new registration
     * @param registration Registration object to create
     * @return The created registration with ID
     * @throws SQLException if database operation fails
     */
    public Registration createRegistration(Registration registration) throws SQLException {
        String query = "INSERT INTO registrations (event_id, student_id, attendance_status) " +
                      "VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, registration.getEventId());
            stmt.setInt(2, registration.getStudentId());
            stmt.setString(3, registration.getAttendanceStatus());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating registration failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    registration.setRegistrationId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating registration failed, no ID obtained.");
                }
            }
            
            return registration;
        }
    }
    
    /**
     * Get registration by ID
     * @param registrationId ID of the registration to retrieve
     * @return Registration object or null if not found
     * @throws SQLException if database operation fails
     */
    public Registration getRegistrationById(int registrationId) throws SQLException {
        String query = "SELECT r.*, e.event_name, s.first_name, s.last_name, s.roll_number " +
                      "FROM registrations r " +
                      "JOIN events e ON r.event_id = e.event_id " +
                      "JOIN students s ON r.student_id = s.student_id " +
                      "WHERE r.registration_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, registrationId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToRegistration(rs);
                }
            }
        }
        return null;
    }
    
    /**
     * Get all registrations
     * @return List of registrations
     * @throws SQLException if database operation fails
     */
    public List<Registration> getAllRegistrations() throws SQLException {
        String query = "SELECT r.*, e.event_name, s.first_name, s.last_name, s.roll_number " +
                      "FROM registrations r " +
                      "JOIN events e ON r.event_id = e.event_id " +
                      "JOIN students s ON r.student_id = s.student_id " +
                      "ORDER BY r.registration_date DESC";
        
        List<Registration> registrations = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                registrations.add(mapResultSetToRegistration(rs));
            }
        }
        
        return registrations;
    }
    
    /**
     * Get registrations by event
     * @param eventId ID of the event
     * @return List of registrations for the event
     * @throws SQLException if database operation fails
     */
    public List<Registration> getRegistrationsByEvent(int eventId) throws SQLException {
        String query = "SELECT r.*, e.event_name, s.first_name, s.last_name, s.roll_number " +
                      "FROM registrations r " +
                      "JOIN events e ON r.event_id = e.event_id " +
                      "JOIN students s ON r.student_id = s.student_id " +
                      "WHERE r.event_id = ? " +
                      "ORDER BY s.last_name, s.first_name";
        
        List<Registration> registrations = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, eventId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    registrations.add(mapResultSetToRegistration(rs));
                }
            }
        }
        
        return registrations;
    }
    
    /**
     * Get registrations by student
     * @param studentId ID of the student
     * @return List of registrations for the student
     * @throws SQLException if database operation fails
     */
    public List<Registration> getRegistrationsByStudent(int studentId) throws SQLException {
        String query = "SELECT r.*, e.event_name, s.first_name, s.last_name, s.roll_number " +
                      "FROM registrations r " +
                      "JOIN events e ON r.event_id = e.event_id " +
                      "JOIN students s ON r.student_id = s.student_id " +
                      "WHERE r.student_id = ? " +
                      "ORDER BY e.event_date DESC, e.start_time DESC";
        
        List<Registration> registrations = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, studentId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    registrations.add(mapResultSetToRegistration(rs));
                }
            }
        }
        
        return registrations;
    }
    
    /**
     * Check if a student is already registered for an event
     * @param eventId ID of the event
     * @param studentId ID of the student
     * @return true if already registered, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean isStudentRegisteredForEvent(int eventId, int studentId) throws SQLException {
        String query = "SELECT COUNT(*) FROM registrations WHERE event_id = ? AND student_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, eventId);
            stmt.setInt(2, studentId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }
    
    /**
     * Get number of registrations for an event
     * @param eventId ID of the event
     * @return Number of registrations
     * @throws SQLException if database operation fails
     */
    public int getRegistrationCountForEvent(int eventId) throws SQLException {
        String query = "SELECT COUNT(*) FROM registrations WHERE event_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, eventId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }
    
    /**
     * Update a registration's attendance status
     * @param registrationId ID of the registration
     * @param attendanceStatus New attendance status
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateAttendanceStatus(int registrationId, String attendanceStatus) throws SQLException {
        String query = "UPDATE registrations SET attendance_status = ? WHERE registration_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, attendanceStatus);
            stmt.setInt(2, registrationId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Update a registration's feedback
     * @param registrationId ID of the registration
     * @param feedback Feedback text
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateFeedback(int registrationId, String feedback) throws SQLException {
        String query = "UPDATE registrations SET feedback = ? WHERE registration_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, feedback);
            stmt.setInt(2, registrationId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Delete a registration
     * @param registrationId ID of the registration to delete
     * @return true if deleted successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean deleteRegistration(int registrationId) throws SQLException {
        String query = "DELETE FROM registrations WHERE registration_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, registrationId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Map ResultSet to Registration object
     * @param rs ResultSet containing registration data
     * @return Registration object
     * @throws SQLException if database operation fails
     */
    private Registration mapResultSetToRegistration(ResultSet rs) throws SQLException {
        Registration registration = new Registration();
        
        registration.setRegistrationId(rs.getInt("registration_id"));
        registration.setEventId(rs.getInt("event_id"));
        registration.setStudentId(rs.getInt("student_id"));
        
        // Handle registration date (might be null in some cases)
        Timestamp registrationDate = rs.getTimestamp("registration_date");
        if (registrationDate != null) {
            registration.setRegistrationDate(registrationDate.toLocalDateTime());
        } else {
            registration.setRegistrationDate(LocalDateTime.now());
        }
        
        registration.setAttendanceStatus(rs.getString("attendance_status"));
        registration.setFeedback(rs.getString("feedback"));
        
        // Set joined data if available
        if (rs.getMetaData().getColumnCount() > 7) {
            registration.setEventName(rs.getString("event_name"));
            String firstName = rs.getString("first_name");
            String lastName = rs.getString("last_name");
            registration.setStudentName(firstName + " " + lastName);
            registration.setStudentRollNumber(rs.getString("roll_number"));
        }
        
        return registration;
    }
}
package main.java.com.collegeevent.dao;

import main.java.com.collegeevent.model.Event;
import main.java.com.collegeevent.util.DatabaseUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Event entity
 */
public class EventDAO {
    
    /**
     * Create a new event
     * @param event Event object to create
     * @return The created event with ID
     * @throws SQLException if database operation fails
     */
    public Event createEvent(Event event) throws SQLException {
        String query = "INSERT INTO events (event_name, description, event_date, start_time, end_time, " +
                "venue_id, organizer, max_participants, registration_deadline, event_status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, event.getEventName());
            stmt.setString(2, event.getDescription());
            stmt.setDate(3, Date.valueOf(event.getEventDate()));
            stmt.setTime(4, Time.valueOf(event.getStartTime()));
            stmt.setTime(5, Time.valueOf(event.getEndTime()));
            stmt.setInt(6, event.getVenueId());
            stmt.setString(7, event.getOrganizer());
            stmt.setInt(8, event.getMaxParticipants());
            stmt.setDate(9, Date.valueOf(event.getRegistrationDeadline()));
            stmt.setString(10, event.getEventStatus());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating event failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    event.setEventId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating event failed, no ID obtained.");
                }
            }
            
            return event;
        }
    }
    
    /**
     * Get event by ID
     * @param eventId ID of the event to retrieve
     * @return Event object or null if not found
     * @throws SQLException if database operation fails
     */
    public Event getEventById(int eventId) throws SQLException {
        String query = "SELECT e.*, v.venue_name FROM events e " +
                       "LEFT JOIN venues v ON e.venue_id = v.venue_id " +
                       "WHERE e.event_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, eventId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEvent(rs);
                }
            }
        }
        return null;
    }
    
    /**
     * Get all events
     * @return List of events
     * @throws SQLException if database operation fails
     */
    public List<Event> getAllEvents() throws SQLException {
        String query = "SELECT e.*, v.venue_name FROM events e " +
                       "LEFT JOIN venues v ON e.venue_id = v.venue_id " +
                       "ORDER BY e.event_date, e.start_time";
        
        List<Event> events = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                events.add(mapResultSetToEvent(rs));
            }
        }
        
        return events;
    }
    
    /**
     * Get upcoming events
     * @return List of upcoming events
     * @throws SQLException if database operation fails
     */
    public List<Event> getUpcomingEvents() throws SQLException {
        String query = "SELECT e.*, v.venue_name FROM events e " +
                       "LEFT JOIN venues v ON e.venue_id = v.venue_id " +
                       "WHERE e.event_date >= CURRENT_DATE() " +
                       "ORDER BY e.event_date, e.start_time";
        
        List<Event> events = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                events.add(mapResultSetToEvent(rs));
            }
        }
        
        return events;
    }
    
    /**
     * Update an event
     * @param event Event object to update
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateEvent(Event event) throws SQLException {
        String query = "UPDATE events SET event_name = ?, description = ?, event_date = ?, " +
                      "start_time = ?, end_time = ?, venue_id = ?, organizer = ?, " +
                      "max_participants = ?, registration_deadline = ?, event_status = ? " +
                      "WHERE event_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, event.getEventName());
            stmt.setString(2, event.getDescription());
            stmt.setDate(3, Date.valueOf(event.getEventDate()));
            stmt.setTime(4, Time.valueOf(event.getStartTime()));
            stmt.setTime(5, Time.valueOf(event.getEndTime()));
            stmt.setInt(6, event.getVenueId());
            stmt.setString(7, event.getOrganizer());
            stmt.setInt(8, event.getMaxParticipants());
            stmt.setDate(9, Date.valueOf(event.getRegistrationDeadline()));
            stmt.setString(10, event.getEventStatus());
            stmt.setInt(11, event.getEventId());
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Delete an event
     * @param eventId ID of the event to delete
     * @return true if deleted successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean deleteEvent(int eventId) throws SQLException {
        String query = "DELETE FROM events WHERE event_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, eventId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        }
    }
    
    /**
     * Search events by name, description, or organizer
     * @param searchTerm Term to search for
     * @return List of matching events
     * @throws SQLException if database operation fails
     */
    public List<Event> searchEvents(String searchTerm) throws SQLException {
        String query = "SELECT e.*, v.venue_name FROM events e " +
                       "LEFT JOIN venues v ON e.venue_id = v.venue_id " +
                       "WHERE e.event_name LIKE ? OR e.description LIKE ? OR e.organizer LIKE ? " +
                       "ORDER BY e.event_date, e.start_time";
        
        List<Event> events = new ArrayList<>();
        String searchPattern = "%" + searchTerm + "%";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    events.add(mapResultSetToEvent(rs));
                }
            }
        }
        
        return events;
    }
    
    /**
     * Get events by venue
     * @param venueId ID of the venue
     * @return List of events at the venue
     * @throws SQLException if database operation fails
     */
    public List<Event> getEventsByVenue(int venueId) throws SQLException {
        String query = "SELECT e.*, v.venue_name FROM events e " +
                       "LEFT JOIN venues v ON e.venue_id = v.venue_id " +
                       "WHERE e.venue_id = ? " +
                       "ORDER BY e.event_date, e.start_time";
        
        List<Event> events = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, venueId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    events.add(mapResultSetToEvent(rs));
                }
            }
        }
        
        return events;
    }
    
    /**
     * Map ResultSet to Event object
     * @param rs ResultSet containing event data
     * @return Event object
     * @throws SQLException if database operation fails
     */
    private Event mapResultSetToEvent(ResultSet rs) throws SQLException {
        Event event = new Event();
        
        event.setEventId(rs.getInt("event_id"));
        event.setEventName(rs.getString("event_name"));
        event.setDescription(rs.getString("description"));
        event.setEventDate(rs.getDate("event_date").toLocalDate());
        event.setStartTime(rs.getTime("start_time").toLocalTime());
        event.setEndTime(rs.getTime("end_time").toLocalTime());
        event.setVenueId(rs.getInt("venue_id"));
        event.setOrganizer(rs.getString("organizer"));
        event.setMaxParticipants(rs.getInt("max_participants"));
        event.setRegistrationDeadline(rs.getDate("registration_deadline").toLocalDate());
        event.setEventStatus(rs.getString("event_status"));
        
        // Set venue name if available from join
        if (rs.getString("venue_name") != null) {
            event.setVenueName(rs.getString("venue_name"));
        }
        
        return event;
    }
}
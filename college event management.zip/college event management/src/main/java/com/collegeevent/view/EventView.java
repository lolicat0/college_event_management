package main.java.com.collegeevent.view;

import main.java.com.collegeevent.controller.EventController;
import main.java.com.collegeevent.controller.VenueController;
import main.java.com.collegeevent.model.Event;
import main.java.com.collegeevent.model.Venue;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

/**
 * View class for Event-related operations
 */
public class EventView {
    private Scanner scanner;
    private EventController eventController;
    private VenueController venueController;
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    
    /**
     * Constructor
     * @param scanner Scanner for input
     */
    public EventView(Scanner scanner) {
        this.scanner = scanner;
        this.eventController = new EventController();
        this.venueController = new VenueController();
    }
    
    /**
     * Display event menu and handle user selections
     */
    public void displayEventMenu() {
        boolean running = true;
        
        while (running) {
            MainView.clearScreen();
            System.out.println("\n==================================");
            System.out.println("|        EVENT MANAGEMENT        |");
            System.out.println("==================================");
            System.out.println("\nEVENT MENU:");
            System.out.println("1. View All Events");
            System.out.println("2. View Upcoming Events");
            System.out.println("3. Search Events");
            System.out.println("4. Add New Event");
            System.out.println("5. Edit Event");
            System.out.println("6. Delete Event");
            System.out.println("7. View Event Details");
            System.out.println("8. Update Event Status");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nEnter your choice: ");
            
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                
                switch (choice) {
                    case 1:
                        viewAllEvents();
                        break;
                    case 2:
                        viewUpcomingEvents();
                        break;
                    case 3:
                        searchEvents();
                        break;
                    case 4:
                        addEvent();
                        break;
                    case 5:
                        editEvent();
                        break;
                    case 6:
                        deleteEvent();
                        break;
                    case 7:
                        viewEventDetails();
                        break;
                    case 8:
                        updateEventStatus();
                        break;
                    case 0:
                        running = false;
                        break;
                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                        MainView.pressEnterToContinue();
                }
            } catch (NumberFormatException e) {
                System.out.println("\nInvalid input. Please enter a number.");
                MainView.pressEnterToContinue();
            }
        }
    }
    
    /**
     * View all events
     */
    private void viewAllEvents() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|           ALL EVENTS           |");
        System.out.println("==================================");
        
        try {
            List<Event> events = eventController.getAllEvents();
            
            if (events.isEmpty()) {
                System.out.println("\nNo events found.");
            } else {
                displayEventsList(events);
            }
        } catch (SQLException e) {
            System.out.println("\nError fetching events: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * View upcoming events
     */
    private void viewUpcomingEvents() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|        UPCOMING EVENTS         |");
        System.out.println("==================================");
        
        try {
            List<Event> events = eventController.getUpcomingEvents();
            
            if (events.isEmpty()) {
                System.out.println("\nNo upcoming events found.");
            } else {
                displayEventsList(events);
            }
        } catch (SQLException e) {
            System.out.println("\nError fetching upcoming events: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Search events
     */
    private void searchEvents() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|          SEARCH EVENTS         |");
        System.out.println("==================================");
        
        System.out.print("\nEnter search term: ");
        String searchTerm = scanner.nextLine().trim();
        
        if (searchTerm.isEmpty()) {
            System.out.println("\nSearch term cannot be empty.");
            MainView.pressEnterToContinue();
            return;
        }
        
        try {
            List<Event> events = eventController.searchEvents(searchTerm);
            
            if (events.isEmpty()) {
                System.out.println("\nNo events found matching '" + searchTerm + "'.");
            } else {
                System.out.println("\nFound " + events.size() + " events matching '" + searchTerm + "':");
                displayEventsList(events);
            }
        } catch (SQLException e) {
            System.out.println("\nError searching events: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Add a new event
     */
    private void addEvent() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|           ADD EVENT            |");
        System.out.println("==================================");
        
        try {
            // Display available venues
            List<Venue> venues = venueController.getAllVenues();
            if (venues.isEmpty()) {
                System.out.println("\nNo venues available. Please add venues first.");
                MainView.pressEnterToContinue();
                return;
            }
            
            System.out.println("\nAvailable Venues:");
            for (Venue venue : venues) {
                System.out.println(venue.getVenueId() + ". " + venue.getVenueName() + 
                                  " (Capacity: " + venue.getCapacity() + ")");
            }
            
            // Get event details
            System.out.print("\nEnter event name: ");
            String eventName = scanner.nextLine().trim();
            
            System.out.print("Enter event description: ");
            String description = scanner.nextLine().trim();
            
            LocalDate eventDate = null;
            while (eventDate == null) {
                System.out.print("Enter event date (YYYY-MM-DD): ");
                try {
                    eventDate = LocalDate.parse(scanner.nextLine().trim(), dateFormatter);
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date format. Please use YYYY-MM-DD.");
                }
            }
            
            LocalTime startTime = null;
            while (startTime == null) {
                System.out.print("Enter start time (HH:MM): ");
                try {
                    startTime = LocalTime.parse(scanner.nextLine().trim(), timeFormatter);
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid time format. Please use HH:MM (24-hour format).");
                }
            }
            
            LocalTime endTime = null;
            while (endTime == null) {
                System.out.print("Enter end time (HH:MM): ");
                try {
                    endTime = LocalTime.parse(scanner.nextLine().trim(), timeFormatter);
                    if (endTime.isBefore(startTime)) {
                        System.out.println("End time cannot be before start time.");
                        endTime = null;
                    }
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid time format. Please use HH:MM (24-hour format).");
                }
            }
            
            int venueId = 0;
            boolean validVenue = false;
            while (!validVenue) {
                System.out.print("Enter venue ID: ");
                try {
                    venueId = Integer.parseInt(scanner.nextLine().trim());
                    
                    // Verify venue exists
                    Venue venue = venueController.getVenueById(venueId);
                    if (venue != null) {
                        validVenue = true;
                    } else {
                        System.out.println("Invalid venue ID. Please select from the list.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                }
            }
            
            System.out.print("Enter organizer: ");
            String organizer = scanner.nextLine().trim();
            
            int maxParticipants = 0;
            while (maxParticipants <= 0) {
                System.out.print("Enter maximum participants: ");
                try {
                    maxParticipants = Integer.parseInt(scanner.nextLine().trim());
                    if (maxParticipants <= 0) {
                        System.out.println("Maximum participants must be greater than zero.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                }
            }
            
            LocalDate registrationDeadline = null;
            while (registrationDeadline == null) {
                System.out.print("Enter registration deadline (YYYY-MM-DD): ");
                try {
                    registrationDeadline = LocalDate.parse(scanner.nextLine().trim(), dateFormatter);
                    if (registrationDeadline.isAfter(eventDate)) {
                        System.out.println("Registration deadline cannot be after event date.");
                        registrationDeadline = null;
                    }
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date format. Please use YYYY-MM-DD.");
                }
            }
            
            // Create the event
            Event event = eventController.createEvent(eventName, description, eventDate, startTime, endTime,
                                                    venueId, organizer, maxParticipants, registrationDeadline, "Upcoming");
            
            System.out.println("\nEvent created successfully with ID: " + event.getEventId());
            
        } catch (SQLException e) {
            System.out.println("\nError creating event: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Edit an existing event
     */
    private void editEvent() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|           EDIT EVENT           |");
        System.out.println("==================================");
        
        System.out.print("\nEnter event ID to edit: ");
        try {
            int eventId = Integer.parseInt(scanner.nextLine().trim());
            
            // Fetch the event
            Event event = eventController.getEventById(eventId);
            if (event == null) {
                System.out.println("\nEvent not found with ID: " + eventId);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Display current event details
            System.out.println("\nCurrent Event Details:");
            displayEventDetails(event);
            
            // Display available venues
            List<Venue> venues = venueController.getAllVenues();
            System.out.println("\nAvailable Venues:");
            for (Venue venue : venues) {
                System.out.println(venue.getVenueId() + ". " + venue.getVenueName() + 
                                  " (Capacity: " + venue.getCapacity() + ")");
            }
            
            // Update event details
            System.out.println("\nEnter new details (press Enter to keep current value):");
            
            System.out.print("Event name [" + event.getEventName() + "]: ");
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                event.setEventName(input);
            }
            
            System.out.print("Description [Press Enter to keep current]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                event.setDescription(input);
            }
            
            System.out.print("Event date [" + event.getEventDate().format(dateFormatter) + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                try {
                    event.setEventDate(LocalDate.parse(input, dateFormatter));
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date format. Keeping current value.");
                }
            }
            
            System.out.print("Start time [" + event.getStartTime().format(timeFormatter) + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                try {
                    event.setStartTime(LocalTime.parse(input, timeFormatter));
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid time format. Keeping current value.");
                }
            }
            
            System.out.print("End time [" + event.getEndTime().format(timeFormatter) + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                try {
                    LocalTime newEndTime = LocalTime.parse(input, timeFormatter);
                    if (newEndTime.isBefore(event.getStartTime())) {
                        System.out.println("End time cannot be before start time. Keeping current value.");
                    } else {
                        event.setEndTime(newEndTime);
                    }
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid time format. Keeping current value.");
                }
            }
            
            System.out.print("Venue ID [" + event.getVenueId() + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                try {
                    int newVenueId = Integer.parseInt(input);
                    
                    // Verify venue exists
                    Venue venue = venueController.getVenueById(newVenueId);
                    if (venue != null) {
                        event.setVenueId(newVenueId);
                    } else {
                        System.out.println("Invalid venue ID. Keeping current value.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Keeping current value.");
                }
            }
            
            System.out.print("Organizer [" + event.getOrganizer() + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                event.setOrganizer(input);
            }
            
            System.out.print("Maximum participants [" + event.getMaxParticipants() + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                try {
                    int newMaxParticipants = Integer.parseInt(input);
                    if (newMaxParticipants > 0) {
                        event.setMaxParticipants(newMaxParticipants);
                    } else {
                        System.out.println("Maximum participants must be greater than zero. Keeping current value.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Keeping current value.");
                }
            }
            
            System.out.print("Registration deadline [" + event.getRegistrationDeadline().format(dateFormatter) + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                try {
                    LocalDate newDeadline = LocalDate.parse(input, dateFormatter);
                    if (newDeadline.isAfter(event.getEventDate())) {
                        System.out.println("Registration deadline cannot be after event date. Keeping current value.");
                    } else {
                        event.setRegistrationDeadline(newDeadline);
                    }
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date format. Keeping current value.");
                }
            }
            
            System.out.print("Event status [" + event.getEventStatus() + "] (Upcoming/Ongoing/Completed/Cancelled): ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                if (input.equals("Upcoming") || input.equals("Ongoing") || 
                    input.equals("Completed") || input.equals("Cancelled")) {
                    event.setEventStatus(input);
                } else {
                    System.out.println("Invalid status. Keeping current value.");
                }
            }
            
            // Update the event
            boolean success = eventController.updateEvent(event);
            
            if (success) {
                System.out.println("\nEvent updated successfully.");
            } else {
                System.out.println("\nFailed to update event.");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid event ID. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError updating event: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Delete an event
     */
    private void deleteEvent() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|          DELETE EVENT          |");
        System.out.println("==================================");
        
        System.out.print("\nEnter event ID to delete: ");
        try {
            int eventId = Integer.parseInt(scanner.nextLine().trim());
            
            // Fetch the event to confirm it exists
            Event event = eventController.getEventById(eventId);
            if (event == null) {
                System.out.println("\nEvent not found with ID: " + eventId);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Confirm deletion
            System.out.println("\nEvent to delete:");
            System.out.println("ID: " + event.getEventId());
            System.out.println("Name: " + event.getEventName());
            System.out.println("Date: " + event.getEventDate().format(dateFormatter));
            
            System.out.print("\nAre you sure you want to delete this event? (y/n): ");
            String confirm = scanner.nextLine().trim().toLowerCase();
            
            if (confirm.equals("y") || confirm.equals("yes")) {
                boolean success = eventController.deleteEvent(eventId);
                
                if (success) {
                    System.out.println("\nEvent deleted successfully.");
                } else {
                    System.out.println("\nFailed to delete event. It may have associated registrations.");
                }
            } else {
                System.out.println("\nDeletion cancelled.");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid event ID. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError deleting event: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * View detailed information about an event
     */
    private void viewEventDetails() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|        EVENT DETAILS           |");
        System.out.println("==================================");
        
        System.out.print("\nEnter event ID: ");
        try {
            int eventId = Integer.parseInt(scanner.nextLine().trim());
            
            // Fetch the event
            Event event = eventController.getEventById(eventId);
            if (event == null) {
                System.out.println("\nEvent not found with ID: " + eventId);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Display event details
            displayEventDetails(event);
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid event ID. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError fetching event details: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Update the status of an event
     */
    private void updateEventStatus() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|      UPDATE EVENT STATUS       |");
        System.out.println("==================================");
        
        System.out.print("\nEnter event ID: ");
        try {
            int eventId = Integer.parseInt(scanner.nextLine().trim());
            
            // Fetch the event
            Event event = eventController.getEventById(eventId);
            if (event == null) {
                System.out.println("\nEvent not found with ID: " + eventId);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Display current event details
            System.out.println("\nCurrent Event Details:");
            System.out.println("ID: " + event.getEventId());
            System.out.println("Name: " + event.getEventName());
            System.out.println("Date: " + event.getEventDate().format(dateFormatter));
            System.out.println("Current Status: " + event.getEventStatus());
            
            // Get new status
            System.out.println("\nSelect new status:");
            System.out.println("1. Upcoming");
            System.out.println("2. Ongoing");
            System.out.println("3. Completed");
            System.out.println("4. Cancelled");
            System.out.print("\nEnter choice (1-4): ");
            
            int choice = Integer.parseInt(scanner.nextLine().trim());
            String newStatus;
            
            switch (choice) {
                case 1:
                    newStatus = "Upcoming";
                    break;
                case 2:
                    newStatus = "Ongoing";
                    break;
                case 3:
                    newStatus = "Completed";
                    break;
                case 4:
                    newStatus = "Cancelled";
                    break;
                default:
                    System.out.println("\nInvalid choice. Status update cancelled.");
                    MainView.pressEnterToContinue();
                    return;
            }
            
            // Update status
            boolean success = eventController.updateEventStatus(eventId, newStatus);
            
            if (success) {
                System.out.println("\nEvent status updated to " + newStatus + ".");
            } else {
                System.out.println("\nFailed to update event status.");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid input. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError updating event status: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("\n" + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Display a list of events
     * @param events List of events to display
     */
    private void displayEventsList(List<Event> events) {
        System.out.println("\n------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("%-5s | %-30s | %-12s | %-10s | %-20s | %-10s%n",
                         "ID", "Event Name", "Date", "Time", "Venue", "Status");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");
        
        for (Event event : events) {
            System.out.printf("%-5d | %-30s | %-12s | %s-%s | %-20s | %-10s%n",
                            event.getEventId(),
                            truncateString(event.getEventName(), 30),
                            event.getEventDate().format(dateFormatter),
                            event.getStartTime().format(timeFormatter),
                            event.getEndTime().format(timeFormatter),
                            truncateString(event.getVenueName(), 20),
                            event.getEventStatus());
        }
        
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("Total Events: " + events.size());
    }
    
    /**
     * Display detailed information about an event
     * @param event Event to display
     */
    private void displayEventDetails(Event event) {
        System.out.println("\n==================================");
        System.out.println("Event ID: " + event.getEventId());
        System.out.println("Name: " + event.getEventName());
        System.out.println("Description: " + event.getDescription());
        System.out.println("Date: " + event.getEventDate().format(dateFormatter));
        System.out.println("Time: " + event.getStartTime().format(timeFormatter) + " - " + 
                         event.getEndTime().format(timeFormatter));
        System.out.println("Venue: " + event.getVenueName() + " (ID: " + event.getVenueId() + ")");
        System.out.println("Organizer: " + event.getOrganizer());
        System.out.println("Maximum Participants: " + event.getMaxParticipants());
        System.out.println("Registration Deadline: " + event.getRegistrationDeadline().format(dateFormatter));
        System.out.println("Status: " + event.getEventStatus());
        System.out.println("==================================");
        
        try {
            // Display registration information
            boolean isRegistrationOpen = eventController.isRegistrationOpen(event.getEventId());
            boolean isEventFull = eventController.isEventFull(event.getEventId());
            int registrationCount = new main.java.com.collegeevent.dao.RegistrationDAO()
                                        .getRegistrationCountForEvent(event.getEventId());
            
            System.out.println("\nRegistration Information:");
            System.out.println("Total Registrations: " + registrationCount + "/" + event.getMaxParticipants());
            System.out.println("Registration Status: " + 
                             (isRegistrationOpen ? "Open" : "Closed") + 
                             (isEventFull ? " (Event is full)" : ""));
        } catch (SQLException e) {
            System.out.println("\nError fetching registration information: " + e.getMessage());
        }
    }
    
    /**
     * Truncate a string if it's longer than the specified length
     * @param str String to truncate
     * @param length Maximum length
     * @return Truncated string
     */
    private String truncateString(String str, int length) {
        if (str == null) {
            return "";
        }
        return str.length() <= length ? str : str.substring(0, length - 3) + "...";
    }
}
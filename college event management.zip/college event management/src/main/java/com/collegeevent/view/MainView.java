package main.java.com.collegeevent.view;

import main.java.com.collegeevent.util.DatabaseUtil;

import java.sql.SQLException;
import java.util.Scanner;

/**
 * Main view class for the application
 */
public class MainView {
    private Scanner scanner;
    private EventView eventView;
    private StudentView studentView;
    private RegistrationView registrationView;
    
    /**
     * Constructor
     */
    public MainView() {
        this.scanner = new Scanner(System.in);
        this.eventView = new EventView(scanner);
        this.studentView = new StudentView(scanner);
        this.registrationView = new RegistrationView(scanner);
    }
    
    /**
     * Display the main menu and handle user selections
     */
    public void displayMainMenu() {
        boolean running = true;
        
        // Test database connection
        if (!DatabaseUtil.testConnection()) {
            System.out.println("Failed to connect to the database. Please check your configuration.");
            return;
        }
        
        while (running) {
            clearScreen();
            System.out.println("\n==================================");
            System.out.println("| COLLEGE EVENT MANAGEMENT SYSTEM |");
            System.out.println("==================================");
            System.out.println("\nMAIN MENU:");
            System.out.println("1. Event Management");
            System.out.println("2. Student Management");
            System.out.println("3. Registration Management");
            System.out.println("0. Exit");
            System.out.print("\nEnter your choice: ");
            
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                
                switch (choice) {
                    case 1:
                        eventView.displayEventMenu();
                        break;
                    case 2:
                        studentView.displayStudentMenu();
                        break;
                    case 3:
                        registrationView.displayRegistrationMenu();
                        break;
                    case 0:
                        running = false;
                        System.out.println("\nThank you for using the College Event Management System!");
                        break;
                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                        pressEnterToContinue();
                }
            } catch (NumberFormatException e) {
                System.out.println("\nInvalid input. Please enter a number.");
                pressEnterToContinue();
            }
        }
        
        // Close database connection and scanner
        DatabaseUtil.closeConnection();
        scanner.close();
    }
    
    /**
     * Clear the console screen
     */
    public static void clearScreen() {
        try {
            final String os = System.getProperty("os.name");
            
            if (os.contains("Windows")) {
                // For Windows
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                // For Unix/Linux/MacOS
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Fallback if clearing screen fails
            for (int i = 0; i < 50; i++) {
                System.out.println();
            }
        }
    }
    
    /**
     * Wait for user to press Enter to continue
     */
    public static void pressEnterToContinue() {
        System.out.print("\nPress Enter to continue...");
        new Scanner(System.in).nextLine();
    }
}
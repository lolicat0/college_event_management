package main.java.com.collegeevent.view;

import main.java.com.collegeevent.controller.EventController;
import main.java.com.collegeevent.controller.RegistrationController;
import main.java.com.collegeevent.controller.StudentController;
import main.java.com.collegeevent.model.Event;
import main.java.com.collegeevent.model.Registration;
import main.java.com.collegeevent.model.Student;

import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

/**
 * View class for Registration-related operations
 */
public class RegistrationView {
    private Scanner scanner;
    private RegistrationController registrationController;
    private EventController eventController;
    private StudentController studentController;
    private DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    /**
     * Constructor
     * @param scanner Scanner for input
     */
    public RegistrationView(Scanner scanner) {
        this.scanner = scanner;
        this.registrationController = new RegistrationController();
        this.eventController = new EventController();
        this.studentController = new StudentController();
    }
    
    /**
     * Display registration menu and handle user selections
     */
    public void displayRegistrationMenu() {
        boolean running = true;
        
        while (running) {
            MainView.clearScreen();
            System.out.println("\n==================================");
            System.out.println("|     REGISTRATION MANAGEMENT    |");
            System.out.println("==================================");
            System.out.println("\nREGISTRATION MENU:");
            System.out.println("1. View All Registrations");
            System.out.println("2. View Registrations by Event");
            System.out.println("3. View Registrations by Student");
            System.out.println("4. Register Student for Event");
            System.out.println("5. Update Attendance Status");
            System.out.println("6. Add Feedback");
            System.out.println("7. Cancel Registration");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nEnter your choice: ");
            
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                
                switch (choice) {
                    case 1:
                        viewAllRegistrations();
                        break;
                    case 2:
                        viewRegistrationsByEvent();
                        break;
                    case 3:
                        viewRegistrationsByStudent();
                        break;
                    case 4:
                        registerStudentForEvent();
                        break;
                    case 5:
                        updateAttendanceStatus();
                        break;
                    case 6:
                        addFeedback();
                        break;
                    case 7:
                        cancelRegistration();
                        break;
                    case 0:
                        running = false;
                        break;
                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                        MainView.pressEnterToContinue();
                }
            } catch (NumberFormatException e) {
                System.out.println("\nInvalid input. Please enter a number.");
                MainView.pressEnterToContinue();
            }
        }
    }
    
    /**
     * View all registrations
     */
    private void viewAllRegistrations() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|       ALL REGISTRATIONS        |");
        System.out.println("==================================");
        
        try {
            List<Registration> registrations = registrationController.getAllRegistrations();
            
            if (registrations.isEmpty()) {
                System.out.println("\nNo registrations found.");
            } else {
                displayRegistrationsList(registrations);
            }
        } catch (SQLException e) {
            System.out.println("\nError fetching registrations: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * View registrations for a specific event
     */
    private void viewRegistrationsByEvent() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|    REGISTRATIONS BY EVENT      |");
        System.out.println("==================================");
        
        System.out.print("\nEnter event ID: ");
        try {
            int eventId = Integer.parseInt(scanner.nextLine().trim());
            
            // Verify event exists
            Event event = eventController.getEventById(eventId);
            if (event == null) {
                System.out.println("\nEvent not found with ID: " + eventId);
                MainView.pressEnterToContinue();
                return;
            }
            
            System.out.println("\nRegistrations for event: " + event.getEventName());
            
            List<Registration> registrations = registrationController.getRegistrationsByEvent(eventId);
            
            if (registrations.isEmpty()) {
                System.out.println("\nNo registrations found for this event.");
            } else {
                displayRegistrationsList(registrations);
            }
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid event ID. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError fetching registrations: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * View registrations for a specific student
     */
    private void viewRegistrationsByStudent() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|    REGISTRATIONS BY STUDENT    |");
        System.out.println("==================================");
        
        System.out.print("\nEnter student ID: ");
        try {
            int studentId = Integer.parseInt(scanner.nextLine().trim());
            
            // Verify student exists
            Student student = studentController.getStudentById(studentId);
            if (student == null) {
                System.out.println("\nStudent not found with ID: " + studentId);
                MainView.pressEnterToContinue();
                return;
            }
            
            System.out.println("\nRegistrations for student: " + student.getFullName());
            
            List<Registration> registrations = registrationController.getRegistrationsByStudent(studentId);
            
            if (registrations.isEmpty()) {
                System.out.println("\nNo registrations found for this student.");
            } else {
                displayRegistrationsList(registrations);
            }
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid student ID. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError fetching registrations: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Register a student for an event
     */
    private void registerStudentForEvent() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|     REGISTER FOR EVENT         |");
        System.out.println("==================================");
        
        try {
            // First display available events
            List<Event> events = eventController.getUpcomingEvents();
            if (events.isEmpty()) {
                System.out.println("\nNo upcoming events available for registration.");
                MainView.pressEnterToContinue();
                return;
            }
            
            System.out.println("\nAvailable Events:");
            System.out.println("------------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-5s | %-30s | %-12s | %-20s | %-10s%n",
                            "ID", "Event Name", "Date", "Venue", "Status");
            System.out.println("------------------------------------------------------------------------------------------------------------------------------");
            
            for (Event event : events) {
                if (eventController.isRegistrationOpen(event.getEventId()) && 
                    !eventController.isEventFull(event.getEventId())) {
                    System.out.printf("%-5d | %-30s | %-12s | %-20s | %-10s%n",
                                    event.getEventId(),
                                    truncateString(event.getEventName(), 30),
                                    event.getEventDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                                    truncateString(event.getVenueName(), 20),
                                    event.getEventStatus());
                }
            }
            System.out.println("------------------------------------------------------------------------------------------------------------------------------");
            
            System.out.print("\nEnter event ID: ");
            int eventId = Integer.parseInt(scanner.nextLine().trim());
            
            // Verify event exists and registration is open
            Event event = eventController.getEventById(eventId);
            if (event == null) {
                System.out.println("\nEvent not found with ID: " + eventId);
                MainView.pressEnterToContinue();
                return;
            }
            
            if (!eventController.isRegistrationOpen(eventId)) {
                System.out.println("\nRegistration is closed for this event.");
                MainView.pressEnterToContinue();
                return;
            }
            
            if (eventController.isEventFull(eventId)) {
                System.out.println("\nThis event is full. No more registrations allowed.");
                MainView.pressEnterToContinue();
                return;
            }
            
            // Then get student details
            System.out.println("\nEnter student details:");
            System.out.println("1. Use existing student (by ID)");
            System.out.println("2. Use existing student (by roll number)");
            System.out.print("\nEnter choice (1-2): ");
            
            int choice = Integer.parseInt(scanner.nextLine().trim());
            
            Student student = null;
            switch (choice) {
                case 1:
                    System.out.print("Enter student ID: ");
                    int studentId = Integer.parseInt(scanner.nextLine().trim());
                    student = studentController.getStudentById(studentId);
                    break;
                case 2:
                    System.out.print("Enter student roll number: ");
                    String rollNumber = scanner.nextLine().trim();
                    student = studentController.getStudentByRollNumber(rollNumber);
                    break;
                default:
                    System.out.println("\nInvalid choice.");
                    MainView.pressEnterToContinue();
                    return;
            }
            
            if (student == null) {
                System.out.println("\nStudent not found.");
                MainView.pressEnterToContinue();
                return;
            }
            
            // Check if student is already registered
            if (registrationController.isStudentRegisteredForEvent(eventId, student.getStudentId())) {
                System.out.println("\nStudent is already registered for this event.");
                MainView.pressEnterToContinue();
                return;
            }
            
            // Register the student
            Registration registration = registrationController.registerStudentForEvent(eventId, student.getStudentId());
            
            System.out.println("\nRegistration successful!");
            System.out.println("Registration ID: " + registration.getRegistrationId());
            System.out.println("Student: " + student.getFullName());
            System.out.println("Event: " + event.getEventName());
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid input. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError registering student: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("\n" + e.getMessage());
        } catch (IllegalStateException e) {
            System.out.println("\n" + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Update attendance status for a registration
     */
    private void updateAttendanceStatus() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|     UPDATE ATTENDANCE STATUS   |");
        System.out.println("==================================");
        
        System.out.print("\nEnter registration ID: ");
        try {
            int registrationId = Integer.parseInt(scanner.nextLine().trim());
            
            // Verify registration exists
            Registration registration = registrationController.getRegistrationById(registrationId);
            if (registration == null) {
                System.out.println("\nRegistration not found with ID: " + registrationId);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Display current details
            System.out.println("\nCurrent Registration Details:");
            System.out.println("Registration ID: " + registration.getRegistrationId());
            System.out.println("Student: " + registration.getStudentName() + " (" + registration.getStudentRollNumber() + ")");
            System.out.println("Event: " + registration.getEventName());
            System.out.println("Current Status: " + registration.getAttendanceStatus());
            
            // Get new status
            System.out.println("\nSelect new attendance status:");
            System.out.println("1. Registered");
            System.out.println("2. Attended");
            System.out.println("3. Absent");
            System.out.print("\nEnter choice (1-3): ");
            
            int choice = Integer.parseInt(scanner.nextLine().trim());
            String newStatus;
            
            switch (choice) {
                case 1:
                    newStatus = "Registered";
                    break;
                case 2:
                    newStatus = "Attended";
                    break;
                case 3:
                    newStatus = "Absent";
                    break;
                default:
                    System.out.println("\nInvalid choice. Status update cancelled.");
                    MainView.pressEnterToContinue();
                    return;
            }
            
            // Update status
            boolean success = registrationController.updateAttendanceStatus(registrationId, newStatus);
            
            if (success) {
                System.out.println("\nAttendance status updated to " + newStatus + ".");
            } else {
                System.out.println("\nFailed to update attendance status.");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid input. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError updating attendance status: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("\n" + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Add feedback for a registration
     */
    private void addFeedback() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|          ADD FEEDBACK          |");
        System.out.println("==================================");
        
        System.out.print("\nEnter registration ID: ");
        try {
            int registrationId = Integer.parseInt(scanner.nextLine().trim());
            
            // Verify registration exists
            Registration registration = registrationController.getRegistrationById(registrationId);
            if (registration == null) {
                System.out.println("\nRegistration not found with ID: " + registrationId);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Display current details
            System.out.println("\nCurrent Registration Details:");
            System.out.println("Registration ID: " + registration.getRegistrationId());
            System.out.println("Student: " + registration.getStudentName() + " (" + registration.getStudentRollNumber() + ")");
            System.out.println("Event: " + registration.getEventName());
            System.out.println("Current Feedback: " + (registration.getFeedback() != null ? registration.getFeedback() : "None"));
            
            // Get new feedback
            System.out.print("\nEnter new feedback: ");
            String feedback = scanner.nextLine().trim();
            
            if (feedback.isEmpty()) {
                System.out.println("\nFeedback cannot be empty.");
                MainView.pressEnterToContinue();
                return;
            }
            
            // Update feedback
            boolean success = registrationController.updateFeedback(registrationId, feedback);
            
            if (success) {
                System.out.println("\nFeedback updated successfully.");
            } else {
                System.out.println("\nFailed to update feedback.");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid input. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError updating feedback: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Cancel a registration
     */
    private void cancelRegistration() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|       CANCEL REGISTRATION      |");
        System.out.println("==================================");
        
        System.out.print("\nEnter registration ID: ");
        try {
            int registrationId = Integer.parseInt(scanner.nextLine().trim());
            
            // Verify registration exists
            Registration registration = registrationController.getRegistrationById(registrationId);
            if (registration == null) {
                System.out.println("\nRegistration not found with ID: " + registrationId);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Display current details
            System.out.println("\nRegistration to cancel:");
            System.out.println("Registration ID: " + registration.getRegistrationId());
            System.out.println("Student: " + registration.getStudentName() + " (" + registration.getStudentRollNumber() + ")");
            System.out.println("Event: " + registration.getEventName());
            
            // Confirm cancellation
            System.out.print("\nAre you sure you want to cancel this registration? (y/n): ");
            String confirm = scanner.nextLine().trim().toLowerCase();
            
            if (confirm.equals("y") || confirm.equals("yes")) {
                try {
                    boolean success = registrationController.cancelRegistration(registrationId);
                    
                    if (success) {
                        System.out.println("\nRegistration cancelled successfully.");
                    } else {
                        System.out.println("\nFailed to cancel registration.");
                    }
                } catch (IllegalStateException e) {
                    System.out.println("\n" + e.getMessage());
                }
            } else {
                System.out.println("\nCancellation aborted.");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid input. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError cancelling registration: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("\n" + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Display a list of registrations
     * @param registrations List of registrations to display
     */
    private void displayRegistrationsList(List<Registration> registrations) {
        System.out.println("\n------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("%-5s | %-30s | %-20s | %-20s | %-10s%n",
                        "ID", "Event", "Student", "Registration Date", "Status");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");
        
        for (Registration registration : registrations) {
            System.out.printf("%-5d | %-30s | %-20s | %-20s | %-10s%n",
                            registration.getRegistrationId(),
                            truncateString(registration.getEventName(), 30),
                            truncateString(registration.getStudentName(), 20),
                            registration.getRegistrationDate().format(dateTimeFormatter),
                            registration.getAttendanceStatus());
        }
        
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("Total Registrations: " + registrations.size());
    }
    
    /**
     * Truncate a string if it's longer than the specified length
     * @param str String to truncate
     * @param length Maximum length
     * @return Truncated string
     */
    private String truncateString(String str, int length) {
        if (str == null) {
            return "";
        }
        return str.length() <= length ? str : str.substring(0, length - 3) + "...";
    }
}
package main.java.com.collegeevent.view;

import main.java.com.collegeevent.controller.StudentController;
import main.java.com.collegeevent.model.Student;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

/**
 * View class for Student-related operations
 */
public class StudentView {
    private Scanner scanner;
    private StudentController studentController;
    
    /**
     * Constructor
     * @param scanner Scanner for input
     */
    public StudentView(Scanner scanner) {
        this.scanner = scanner;
        this.studentController = new StudentController();
    }
    
    /**
     * Display student menu and handle user selections
     */
    public void displayStudentMenu() {
        boolean running = true;
        
        while (running) {
            MainView.clearScreen();
            System.out.println("\n==================================");
            System.out.println("|       STUDENT MANAGEMENT       |");
            System.out.println("==================================");
            System.out.println("\nSTUDENT MENU:");
            System.out.println("1. View All Students");
            System.out.println("2. Search Students");
            System.out.println("3. Add New Student");
            System.out.println("4. Edit Student");
            System.out.println("5. Delete Student");
            System.out.println("6. View Student Details");
            System.out.println("7. View Students by Department");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nEnter your choice: ");
            
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                
                switch (choice) {
                    case 1:
                        viewAllStudents();
                        break;
                    case 2:
                        searchStudents();
                        break;
                    case 3:
                        addStudent();
                        break;
                    case 4:
                        editStudent();
                        break;
                    case 5:
                        deleteStudent();
                        break;
                    case 6:
                        viewStudentDetails();
                        break;
                    case 7:
                        viewStudentsByDepartment();
                        break;
                    case 0:
                        running = false;
                        break;
                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                        MainView.pressEnterToContinue();
                }
            } catch (NumberFormatException e) {
                System.out.println("\nInvalid input. Please enter a number.");
                MainView.pressEnterToContinue();
            }
        }
    }
    
    /**
     * View all students
     */
    private void viewAllStudents() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|          ALL STUDENTS          |");
        System.out.println("==================================");
        
        try {
            List<Student> students = studentController.getAllStudents();
            
            if (students.isEmpty()) {
                System.out.println("\nNo students found.");
            } else {
                displayStudentsList(students);
            }
        } catch (SQLException e) {
            System.out.println("\nError fetching students: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Search students
     */
    private void searchStudents() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|         SEARCH STUDENTS        |");
        System.out.println("==================================");
        
        System.out.print("\nEnter search term: ");
        String searchTerm = scanner.nextLine().trim();
        
        if (searchTerm.isEmpty()) {
            System.out.println("\nSearch term cannot be empty.");
            MainView.pressEnterToContinue();
            return;
        }
        
        try {
            List<Student> students = studentController.searchStudents(searchTerm);
            
            if (students.isEmpty()) {
                System.out.println("\nNo students found matching '" + searchTerm + "'.");
            } else {
                System.out.println("\nFound " + students.size() + " students matching '" + searchTerm + "':");
                displayStudentsList(students);
            }
        } catch (SQLException e) {
            System.out.println("\nError searching students: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Add a new student
     */
    private void addStudent() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|           ADD STUDENT          |");
        System.out.println("==================================");
        
        try {
            System.out.print("\nEnter roll number: ");
            String rollNumber = scanner.nextLine().trim();
            
            // Check if roll number already exists
            if (studentController.isRollNumberTaken(rollNumber, null)) {
                System.out.println("\nError: Roll number '" + rollNumber + "' is already taken.");
                MainView.pressEnterToContinue();
                return;
            }
            
            System.out.print("Enter first name: ");
            String firstName = scanner.nextLine().trim();
            
            System.out.print("Enter last name: ");
            String lastName = scanner.nextLine().trim();
            
            System.out.print("Enter email: ");
            String email = scanner.nextLine().trim();
            
            // Check if email already exists
            if (studentController.isEmailTaken(email, null)) {
                System.out.println("\nError: Email '" + email + "' is already taken.");
                MainView.pressEnterToContinue();
                return;
            }
            
            System.out.print("Enter phone: ");
            String phone = scanner.nextLine().trim();
            
            System.out.print("Enter department: ");
            String department = scanner.nextLine().trim();
            
            int yearOfStudy = 0;
            while (yearOfStudy <= 0 || yearOfStudy > 6) {
                System.out.print("Enter year of study (1-6): ");
                try {
                    yearOfStudy = Integer.parseInt(scanner.nextLine().trim());
                    if (yearOfStudy <= 0 || yearOfStudy > 6) {
                        System.out.println("Year of study must be between 1 and 6.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                }
            }
            
            // Create a student object for validation
            Student student = new Student(rollNumber, firstName, lastName, email, phone, department, yearOfStudy);
            
            // Validate student data
            String validationError = studentController.validateStudent(student);
            if (validationError != null) {
                System.out.println("\nError: " + validationError);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Create the student
            Student createdStudent = studentController.createStudent(rollNumber, firstName, lastName, 
                                                                   email, phone, department, yearOfStudy);
            
            System.out.println("\nStudent created successfully with ID: " + createdStudent.getStudentId());
            
        } catch (SQLException e) {
            System.out.println("\nError creating student: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Edit an existing student
     */
    private void editStudent() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|          EDIT STUDENT          |");
        System.out.println("==================================");
        
        System.out.print("\nEnter student ID to edit: ");
        try {
            int studentId = Integer.parseInt(scanner.nextLine().trim());
            
            // Fetch the student
            Student student = studentController.getStudentById(studentId);
            if (student == null) {
                System.out.println("\nStudent not found with ID: " + studentId);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Display current student details
            System.out.println("\nCurrent Student Details:");
            displayStudentDetails(student);
            
            // Update student details
            System.out.println("\nEnter new details (press Enter to keep current value):");
            
            System.out.print("Roll number [" + student.getRollNumber() + "]: ");
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                // Check if new roll number is already taken
                if (!input.equals(student.getRollNumber()) && 
                    studentController.isRollNumberTaken(input, student.getStudentId())) {
                    System.out.println("\nError: Roll number '" + input + "' is already taken. Keeping current value.");
                } else {
                    student.setRollNumber(input);
                }
            }
            
            System.out.print("First name [" + student.getFirstName() + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                student.setFirstName(input);
            }
            
            System.out.print("Last name [" + student.getLastName() + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                student.setLastName(input);
            }
            
            System.out.print("Email [" + student.getEmail() + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                // Check if new email is already taken
                if (!input.equals(student.getEmail()) && 
                    studentController.isEmailTaken(input, student.getStudentId())) {
                    System.out.println("\nError: Email '" + input + "' is already taken. Keeping current value.");
                } else {
                    student.setEmail(input);
                }
            }
            
            System.out.print("Phone [" + student.getPhone() + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                student.setPhone(input);
            }
            
            System.out.print("Department [" + student.getDepartment() + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                student.setDepartment(input);
            }
            
            System.out.print("Year of study [" + student.getYearOfStudy() + "]: ");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                try {
                    int yearOfStudy = Integer.parseInt(input);
                    if (yearOfStudy > 0 && yearOfStudy <= 6) {
                        student.setYearOfStudy(yearOfStudy);
                    } else {
                        System.out.println("Year of study must be between 1 and 6. Keeping current value.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Keeping current value.");
                }
            }
            
            // Validate student data
            String validationError = studentController.validateStudent(student);
            if (validationError != null) {
                System.out.println("\nError: " + validationError);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Update the student
            boolean success = studentController.updateStudent(student);
            
            if (success) {
                System.out.println("\nStudent updated successfully.");
            } else {
                System.out.println("\nFailed to update student.");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid student ID. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError updating student: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Delete a student
     */
    private void deleteStudent() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|         DELETE STUDENT         |");
        System.out.println("==================================");
        
        System.out.print("\nEnter student ID to delete: ");
        try {
            int studentId = Integer.parseInt(scanner.nextLine().trim());
            
            // Fetch the student to confirm it exists
            Student student = studentController.getStudentById(studentId);
            if (student == null) {
                System.out.println("\nStudent not found with ID: " + studentId);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Confirm deletion
            System.out.println("\nStudent to delete:");
            System.out.println("ID: " + student.getStudentId());
            System.out.println("Name: " + student.getFullName());
            System.out.println("Roll Number: " + student.getRollNumber());
            
            System.out.print("\nAre you sure you want to delete this student? (y/n): ");
            String confirm = scanner.nextLine().trim().toLowerCase();
            
            if (confirm.equals("y") || confirm.equals("yes")) {
                boolean success = studentController.deleteStudent(studentId);
                
                if (success) {
                    System.out.println("\nStudent deleted successfully.");
                } else {
                    System.out.println("\nFailed to delete student. They may have associated registrations.");
                }
            } else {
                System.out.println("\nDeletion cancelled.");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid student ID. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError deleting student: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * View detailed information about a student
     */
    private void viewStudentDetails() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|        STUDENT DETAILS         |");
        System.out.println("==================================");
        
        System.out.print("\nEnter student ID: ");
        try {
            int studentId = Integer.parseInt(scanner.nextLine().trim());
            
            // Fetch the student
            Student student = studentController.getStudentById(studentId);
            if (student == null) {
                System.out.println("\nStudent not found with ID: " + studentId);
                MainView.pressEnterToContinue();
                return;
            }
            
            // Display student details
            displayStudentDetails(student);
            
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid student ID. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("\nError fetching student details: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * View students by department
     */
    private void viewStudentsByDepartment() {
        MainView.clearScreen();
        System.out.println("\n==================================");
        System.out.println("|     STUDENTS BY DEPARTMENT     |");
        System.out.println("==================================");
        
        System.out.print("\nEnter department name: ");
        String department = scanner.nextLine().trim();
        
        if (department.isEmpty()) {
            System.out.println("\nDepartment name cannot be empty.");
            MainView.pressEnterToContinue();
            return;
        }
        
        try {
            List<Student> students = studentController.getStudentsByDepartment(department);
            
            if (students.isEmpty()) {
                System.out.println("\nNo students found in department '" + department + "'.");
            } else {
                System.out.println("\nStudents in department '" + department + "':");
                displayStudentsList(students);
            }
        } catch (SQLException e) {
            System.out.println("\nError fetching students: " + e.getMessage());
        }
        
        MainView.pressEnterToContinue();
    }
    
    /**
     * Display a list of students
     * @param students List of students to display
     */
    private void displayStudentsList(List<Student> students) {
        System.out.println("\n------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("%-5s | %-10s | %-25s | %-25s | %-15s | %-5s%n",
                         "ID", "Roll No", "Name", "Email", "Department", "Year");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");
        
        for (Student student : students) {
            System.out.printf("%-5d | %-10s | %-25s | %-25s | %-15s | %-5d%n",
                            student.getStudentId(),
                            student.getRollNumber(),
                            truncateString(student.getFullName(), 25),
                            truncateString(student.getEmail(), 25),
                            truncateString(student.getDepartment(), 15),
                            student.getYearOfStudy());
        }
        
        System.out.println("------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("Total Students: " + students.size());
    }
    
    /**
     * Display detailed information about a student
     * @param student Student to display
     */
    private void displayStudentDetails(Student student) {
        System.out.println("\n==================================");
        System.out.println("Student ID: " + student.getStudentId());
        System.out.println("Roll Number: " + student.getRollNumber());
        System.out.println("Name: " + student.getFullName());
        System.out.println("Email: " + student.getEmail());
        System.out.println("Phone: " + student.getPhone());
        System.out.println("Department: " + student.getDepartment());
        System.out.println("Year of Study: " + student.getYearOfStudy());
        System.out.println("==================================");
    }
    
    /**
     * Truncate a string if it's longer than the specified length
     * @param str String to truncate
     * @param length Maximum length
     * @return Truncated string
     */
    private String truncateString(String str, int length) {
        if (str == null) {
            return "";
        }
        return str.length() <= length ? str : str.substring(0, length - 3) + "...";
    }
}
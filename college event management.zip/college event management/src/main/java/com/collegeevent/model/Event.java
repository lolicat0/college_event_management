package main.java.com.collegeevent.model;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Event model class representing events table
 */
public class Event {
    private int eventId;
    private String eventName;
    private String description;
    private LocalDate eventDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private int venueId;
    private String organizer;
    private int maxParticipants;
    private LocalDate registrationDeadline;
    private String eventStatus;
    private String venueName; // For joining with venue table
    
    // Constructors
    public Event() {
    }
    
    public Event(String eventName, String description, LocalDate eventDate, 
                LocalTime startTime, LocalTime endTime, int venueId, 
                String organizer, int maxParticipants, 
                LocalDate registrationDeadline, String eventStatus) {
        this.eventName = eventName;
        this.description = description;
        this.eventDate = eventDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.venueId = venueId;
        this.organizer = organizer;
        this.maxParticipants = maxParticipants;
        this.registrationDeadline = registrationDeadline;
        this.eventStatus = eventStatus;
    }
    
    // Constructor with ID (for retrieving from database)
    public Event(int eventId, String eventName, String description, 
                LocalDate eventDate, LocalTime startTime, LocalTime endTime, 
                int venueId, String organizer, int maxParticipants, 
                LocalDate registrationDeadline, String eventStatus) {
        this(eventName, description, eventDate, startTime, endTime, venueId, 
             organizer, maxParticipants, registrationDeadline, eventStatus);
        this.eventId = eventId;
    }
    
    // Getters and Setters
    public int getEventId() {
        return eventId;
    }
    
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    
    public String getEventName() {
        return eventName;
    }
    
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public LocalDate getEventDate() {
        return eventDate;
    }
    
    public void setEventDate(LocalDate eventDate) {
        this.eventDate = eventDate;
    }
    
    public LocalTime getStartTime() {
        return startTime;
    }
    
    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }
    
    public LocalTime getEndTime() {
        return endTime;
    }
    
    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }
    
    public int getVenueId() {
        return venueId;
    }
    
    public void setVenueId(int venueId) {
        this.venueId = venueId;
    }
    
    public String getOrganizer() {
        return organizer;
    }
    
    public void setOrganizer(String organizer) {
        this.organizer = organizer;
    }
    
    public int getMaxParticipants() {
        return maxParticipants;
    }
    
    public void setMaxParticipants(int maxParticipants) {
        this.maxParticipants = maxParticipants;
    }
    
    public LocalDate getRegistrationDeadline() {
        return registrationDeadline;
    }
    
    public void setRegistrationDeadline(LocalDate registrationDeadline) {
        this.registrationDeadline = registrationDeadline;
    }
    
    public String getEventStatus() {
        return eventStatus;
    }
    
    public void setEventStatus(String eventStatus) {
        this.eventStatus = eventStatus;
    }
    
    public String getVenueName() {
        return venueName;
    }
    
    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }
    
    @Override
    public String toString() {
        return "Event{" +
                "eventId=" + eventId +
                ", eventName='" + eventName + '\'' +
                ", eventDate=" + eventDate +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", venue=" + (venueName != null ? venueName : "Venue ID: " + venueId) +
                ", organizer='" + organizer + '\'' +
                ", status='" + eventStatus + '\'' +
                '}';
    }
}
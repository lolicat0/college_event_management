package main.java.com.collegeevent.model;

import java.time.LocalDateTime;

/**
 * Registration model class representing registrations table
 */
public class Registration {
    private int registrationId;
    private int eventId;
    private int studentId;
    private LocalDateTime registrationDate;
    private String attendanceStatus;
    private String feedback;
    
    // Extra fields for joined data
    private String eventName;
    private String studentName;
    private String studentRollNumber;
    
    // Constructors
    public Registration() {
    }
    
    public Registration(int eventId, int studentId) {
        this.eventId = eventId;
        this.studentId = studentId;
        this.registrationDate = LocalDateTime.now();
        this.attendanceStatus = "Registered";
    }
    
    public Registration(int eventId, int studentId, String attendanceStatus) {
        this(eventId, studentId);
        this.attendanceStatus = attendanceStatus;
    }
    
    // Constructor with ID (for retrieving from database)
    public Registration(int registrationId, int eventId, int studentId, 
                       LocalDateTime registrationDate, String attendanceStatus, String feedback) {
        this.registrationId = registrationId;
        this.eventId = eventId;
        this.studentId = studentId;
        this.registrationDate = registrationDate;
        this.attendanceStatus = attendanceStatus;
        this.feedback = feedback;
    }
    
    // Getters and Setters
    public int getRegistrationId() {
        return registrationId;
    }
    
    public void setRegistrationId(int registrationId) {
        this.registrationId = registrationId;
    }
    
    public int getEventId() {
        return eventId;
    }
    
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    
    public int getStudentId() {
        return studentId;
    }
    
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
    
    public LocalDateTime getRegistrationDate() {
        return registrationDate;
    }
    
    public void setRegistrationDate(LocalDateTime registrationDate) {
        this.registrationDate = registrationDate;
    }
    
    public String getAttendanceStatus() {
        return attendanceStatus;
    }
    
    public void setAttendanceStatus(String attendanceStatus) {
        this.attendanceStatus = attendanceStatus;
    }
    
    public String getFeedback() {
        return feedback;
    }
    
    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }
    
    public String getEventName() {
        return eventName;
    }
    
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
    
    public String getStudentName() {
        return studentName;
    }
    
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
    
    public String getStudentRollNumber() {
        return studentRollNumber;
    }
    
    public void setStudentRollNumber(String studentRollNumber) {
        this.studentRollNumber = studentRollNumber;
    }
    
    @Override
    public String toString() {
        return "Registration{" +
                "registrationId=" + registrationId +
                ", event=" + (eventName != null ? eventName : "Event ID: " + eventId) +
                ", student=" + (studentName != null ? studentName : "Student ID: " + studentId) +
                ", registrationDate=" + registrationDate +
                ", status='" + attendanceStatus + '\'' +
                '}';
    }
}
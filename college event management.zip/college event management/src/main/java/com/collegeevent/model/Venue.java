package main.java.com.collegeevent.model;

/**
 * Venue model class representing venues table
 */
public class Venue {
    private int venueId;
    private String venueName;
    private String location;
    private int capacity;
    private String facilities;
    
    // Constructors
    public Venue() {
    }
    
    public Venue(String venueName, String location, int capacity, String facilities) {
        this.venueName = venueName;
        this.location = location;
        this.capacity = capacity;
        this.facilities = facilities;
    }
    
    // Constructor with ID (for retrieving from database)
    public Venue(int venueId, String venueName, String location, int capacity, String facilities) {
        this(venueName, location, capacity, facilities);
        this.venueId = venueId;
    }
    
    // Getters and Setters
    public int getVenueId() {
        return venueId;
    }
    
    public void setVenueId(int venueId) {
        this.venueId = venueId;
    }
    
    public String getVenueName() {
        return venueName;
    }
    
    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public int getCapacity() {
        return capacity;
    }
    
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    
    public String getFacilities() {
        return facilities;
    }
    
    public void setFacilities(String facilities) {
        this.facilities = facilities;
    }
    
    @Override
    public String toString() {
        return "Venue{" +
                "venueId=" + venueId +
                ", venueName='" + venueName + '\'' +
                ", location='" + location + '\'' +
                ", capacity=" + capacity +
                '}';
    }
}
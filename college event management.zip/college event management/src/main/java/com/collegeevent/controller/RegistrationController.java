package main.java.com.collegeevent.controller;

import main.java.com.collegeevent.dao.EventDAO;
import main.java.com.collegeevent.dao.RegistrationDAO;
import main.java.com.collegeevent.dao.StudentDAO;
import main.java.com.collegeevent.model.Event;
import main.java.com.collegeevent.model.Registration;
import main.java.com.collegeevent.model.Student;

import java.sql.SQLException;
import java.util.List;

/**
 * Controller class for Registration-related operations
 */
public class RegistrationController {
    private final RegistrationDAO registrationDAO;
    private final EventDAO eventDAO;
    private final StudentDAO studentDAO;
    
    /**
     * Constructor
     */
    public RegistrationController() {
        this.registrationDAO = new RegistrationDAO();
        this.eventDAO = new EventDAO();
        this.studentDAO = new StudentDAO();
    }
    
    /**
     * Register a student for an event
     * @param eventId ID of the event
     * @param studentId ID of the student
     * @return The created registration with ID
     * @throws SQLException if database operation fails
     * @throws IllegalStateException if registration is not possible
     */
    public Registration registerStudentForEvent(int eventId, int studentId) throws SQLException, IllegalStateException {
        // Verify that the event exists
        Event event = eventDAO.getEventById(eventId);
        if (event == null) {
            throw new IllegalArgumentException("Event not found with ID: " + eventId);
        }
        
        // Verify that the student exists
        Student student = studentDAO.getStudentById(studentId);
        if (student == null) {
            throw new IllegalArgumentException("Student not found with ID: " + studentId);
        }
        
        // Check if registration is open
        if (!"Upcoming".equals(event.getEventStatus()) && !"Ongoing".equals(event.getEventStatus())) {
            throw new IllegalStateException("Registration is closed for this event.");
        }
        
        // Check if registration deadline has passed
        if (event.getRegistrationDeadline().isBefore(java.time.LocalDate.now())) {
            throw new IllegalStateException("Registration deadline has passed for this event.");
        }
        
        // Check if the event is full
        int currentRegistrations = registrationDAO.getRegistrationCountForEvent(eventId);
        if (currentRegistrations >= event.getMaxParticipants()) {
            throw new IllegalStateException("Event is full. No more registrations allowed.");
        }
        
        // Check if student is already registered
        if (registrationDAO.isStudentRegisteredForEvent(eventId, studentId)) {
            throw new IllegalStateException("Student is already registered for this event.");
        }
        
        // Create registration
        Registration registration = new Registration(eventId, studentId);
        return registrationDAO.createRegistration(registration);
    }
    
    /**
     * Get registration by ID
     * @param registrationId ID of the registration to retrieve
     * @return Registration object or null if not found
     * @throws SQLException if database operation fails
     */
    public Registration getRegistrationById(int registrationId) throws SQLException {
        return registrationDAO.getRegistrationById(registrationId);
    }
    
    /**
     * Get all registrations
     * @return List of all registrations
     * @throws SQLException if database operation fails
     */
    public List<Registration> getAllRegistrations() throws SQLException {
        return registrationDAO.getAllRegistrations();
    }
    
    /**
     * Get registrations by event
     * @param eventId ID of the event
     * @return List of registrations for the event
     * @throws SQLException if database operation fails
     */
    public List<Registration> getRegistrationsByEvent(int eventId) throws SQLException {
        return registrationDAO.getRegistrationsByEvent(eventId);
    }
    
    /**
     * Get registrations by student
     * @param studentId ID of the student
     * @return List of registrations for the student
     * @throws SQLException if database operation fails
     */
    public List<Registration> getRegistrationsByStudent(int studentId) throws SQLException {
        return registrationDAO.getRegistrationsByStudent(studentId);
    }
    
    /**
     * Update attendance status for a registration
     * @param registrationId ID of the registration
     * @param attendanceStatus New attendance status
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateAttendanceStatus(int registrationId, String attendanceStatus) throws SQLException {
        if (!isValidAttendanceStatus(attendanceStatus)) {
            throw new IllegalArgumentException("Invalid attendance status: " + attendanceStatus);
        }
        
        return registrationDAO.updateAttendanceStatus(registrationId, attendanceStatus);
    }
    
    /**
     * Update feedback for a registration
     * @param registrationId ID of the registration
     * @param feedback Feedback text
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateFeedback(int registrationId, String feedback) throws SQLException {
        return registrationDAO.updateFeedback(registrationId, feedback);
    }
    
    /**
     * Cancel a registration
     * @param registrationId ID of the registration to cancel
     * @return true if cancelled successfully, false otherwise
     * @throws SQLException if database operation fails
     * @throws IllegalStateException if cancellation is not possible
     */
    public boolean cancelRegistration(int registrationId) throws SQLException, IllegalStateException {
        Registration registration = registrationDAO.getRegistrationById(registrationId);
        if (registration == null) {
            throw new IllegalArgumentException("Registration not found with ID: " + registrationId);
        }
        
        Event event = eventDAO.getEventById(registration.getEventId());
        if (event == null) {
            throw new IllegalStateException("Event associated with this registration no longer exists.");
        }
        
        if ("Completed".equals(event.getEventStatus())) {
            throw new IllegalStateException("Cannot cancel registration for a completed event.");
        }
        
        return registrationDAO.deleteRegistration(registrationId);
    }
    
    /**
     * Check if a student is registered for an event
     * @param eventId ID of the event
     * @param studentId ID of the student
     * @return true if registered, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean isStudentRegisteredForEvent(int eventId, int studentId) throws SQLException {
        return registrationDAO.isStudentRegisteredForEvent(eventId, studentId);
    }
    
    /**
     * Get registration count for an event
     * @param eventId ID of the event
     * @return Number of registrations
     * @throws SQLException if database operation fails
     */
    public int getRegistrationCountForEvent(int eventId) throws SQLException {
        return registrationDAO.getRegistrationCountForEvent(eventId);
    }
    
    /**
     * Validate attendance status
     * @param status Status to validate
     * @return true if valid, false otherwise
     */
    private boolean isValidAttendanceStatus(String status) {
        return "Registered".equals(status) || "Attended".equals(status) || "Absent".equals(status);
    }
}
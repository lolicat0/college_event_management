package main.java.com.collegeevent.controller;

import main.java.com.collegeevent.dao.StudentDAO;
import main.java.com.collegeevent.model.Student;

import java.sql.SQLException;
import java.util.List;

/**
 * Controller class for Student-related operations
 */
public class StudentController {
    private final StudentDAO studentDAO;
    
    /**
     * Constructor
     */
    public StudentController() {
        this.studentDAO = new StudentDAO();
    }
    
    /**
     * Create a new student
     * @param rollNumber Roll number of the student
     * @param firstName First name of the student
     * @param lastName Last name of the student
     * @param email Email of the student
     * @param phone Phone of the student
     * @param department Department of the student
     * @param yearOfStudy Year of study
     * @return The created student with ID
     * @throws SQLException if database operation fails
     */
    public Student createStudent(String rollNumber, String firstName, String lastName,
                               String email, String phone, String department,
                               int yearOfStudy) throws SQLException {
        
        Student student = new Student(rollNumber, firstName, lastName, email, phone, department, yearOfStudy);
        
        return studentDAO.createStudent(student);
    }
    
    /**
     * Get student by ID
     * @param studentId ID of the student to retrieve
     * @return Student object or null if not found
     * @throws SQLException if database operation fails
     */
    public Student getStudentById(int studentId) throws SQLException {
        return studentDAO.getStudentById(studentId);
    }
    
    /**
     * Get student by roll number
     * @param rollNumber Roll number of the student
     * @return Student object or null if not found
     * @throws SQLException if database operation fails
     */
    public Student getStudentByRollNumber(String rollNumber) throws SQLException {
        return studentDAO.getStudentByRollNumber(rollNumber);
    }
    
    /**
     * Get student by email
     * @param email Email of the student
     * @return Student object or null if not found
     * @throws SQLException if database operation fails
     */
    public Student getStudentByEmail(String email) throws SQLException {
        return studentDAO.getStudentByEmail(email);
    }
    
    /**
     * Get all students
     * @return List of all students
     * @throws SQLException if database operation fails
     */
    public List<Student> getAllStudents() throws SQLException {
        return studentDAO.getAllStudents();
    }
    
    /**
     * Update a student
     * @param student Student object to update
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateStudent(Student student) throws SQLException {
        return studentDAO.updateStudent(student);
    }
    
    /**
     * Delete a student
     * @param studentId ID of the student to delete
     * @return true if deleted successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean deleteStudent(int studentId) throws SQLException {
        return studentDAO.deleteStudent(studentId);
    }
    
    /**
     * Search students by name, roll number, email, or department
     * @param searchTerm Term to search for
     * @return List of matching students
     * @throws SQLException if database operation fails
     */
    public List<Student> searchStudents(String searchTerm) throws SQLException {
        return studentDAO.searchStudents(searchTerm);
    }
    
    /**
     * Get students by department
     * @param department Department name
     * @return List of students in the department
     * @throws SQLException if database operation fails
     */
    public List<Student> getStudentsByDepartment(String department) throws SQLException {
        return studentDAO.getStudentsByDepartment(department);
    }
    
    /**
     * Validate student data
     * @param student Student to validate
     * @return Error message or null if valid
     */
    public String validateStudent(Student student) {
        if (student.getRollNumber() == null || student.getRollNumber().trim().isEmpty()) {
            return "Roll number is required";
        }
        
        if (student.getFirstName() == null || student.getFirstName().trim().isEmpty()) {
            return "First name is required";
        }
        
        if (student.getLastName() == null || student.getLastName().trim().isEmpty()) {
            return "Last name is required";
        }
        
        if (student.getEmail() == null || student.getEmail().trim().isEmpty()) {
            return "Email is required";
        }
        
        if (!student.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            return "Invalid email format";
        }
        
        if (student.getYearOfStudy() < 1 || student.getYearOfStudy() > 6) {
            return "Year of study should be between 1 and 6";
        }
        
        return null; // No errors
    }
    
    /**
     * Check if roll number already exists
     * @param rollNumber Roll number to check
     * @param excludeStudentId Optional student ID to exclude from check (for updates)
     * @return true if exists, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean isRollNumberTaken(String rollNumber, Integer excludeStudentId) throws SQLException {
        Student existingStudent = studentDAO.getStudentByRollNumber(rollNumber);
        if (existingStudent == null) {
            return false;
        }
        
        if (excludeStudentId != null && existingStudent.getStudentId() == excludeStudentId) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Check if email already exists
     * @param email Email to check
     * @param excludeStudentId Optional student ID to exclude from check (for updates)
     * @return true if exists, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean isEmailTaken(String email, Integer excludeStudentId) throws SQLException {
        Student existingStudent = studentDAO.getStudentByEmail(email);
        if (existingStudent == null) {
            return false;
        }
        
        if (excludeStudentId != null && existingStudent.getStudentId() == excludeStudentId) {
            return false;
        }
        
        return true;
    }
}
package main.java.com.collegeevent.controller;

import main.java.com.collegeevent.dao.VenueDAO;
import main.java.com.collegeevent.model.Venue;

import java.sql.SQLException;
import java.util.List;

/**
 * Controller class for Venue-related operations
 */
public class VenueController {
    private final VenueDAO venueDAO;
    
    /**
     * Constructor
     */
    public VenueController() {
        this.venueDAO = new VenueDAO();
    }
    
    /**
     * Create a new venue
     * @param venueName Name of the venue
     * @param location Location of the venue
     * @param capacity Capacity of the venue
     * @param facilities Facilities available at the venue
     * @return The created venue with ID
     * @throws SQLException if database operation fails
     */
    public Venue createVenue(String venueName, String location, int capacity, String facilities) throws SQLException {
        Venue venue = new Venue(venueName, location, capacity, facilities);
        return venueDAO.createVenue(venue);
    }
    
    /**
     * Get venue by ID
     * @param venueId ID of the venue to retrieve
     * @return Venue object or null if not found
     * @throws SQLException if database operation fails
     */
    public Venue getVenueById(int venueId) throws SQLException {
        return venueDAO.getVenueById(venueId);
    }
    
    /**
     * Get all venues
     * @return List of all venues
     * @throws SQLException if database operation fails
     */
    public List<Venue> getAllVenues() throws SQLException {
        return venueDAO.getAllVenues();
    }
    
    /**
     * Update a venue
     * @param venue Venue object to update
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateVenue(Venue venue) throws SQLException {
        return venueDAO.updateVenue(venue);
    }
    
    /**
     * Delete a venue
     * @param venueId ID of the venue to delete
     * @return true if deleted successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean deleteVenue(int venueId) throws SQLException {
        return venueDAO.deleteVenue(venueId);
    }
    
    /**
     * Get venues by capacity
     * @param minCapacity Minimum capacity required
     * @return List of venues with sufficient capacity
     * @throws SQLException if database operation fails
     */
    public List<Venue> getVenuesByCapacity(int minCapacity) throws SQLException {
        return venueDAO.getVenuesByCapacity(minCapacity);
    }
    
    /**
     * Search venues by name or location
     * @param searchTerm Term to search for
     * @return List of matching venues
     * @throws SQLException if database operation fails
     */
    public List<Venue> searchVenues(String searchTerm) throws SQLException {
        return venueDAO.searchVenues(searchTerm);
    }
    
    /**
     * Validate venue data
     * @param venue Venue to validate
     * @return Error message or null if valid
     */
    public String validateVenue(Venue venue) {
        if (venue.getVenueName() == null || venue.getVenueName().trim().isEmpty()) {
            return "Venue name is required";
        }
        
        if (venue.getLocation() == null || venue.getLocation().trim().isEmpty()) {
            return "Location is required";
        }
        
        if (venue.getCapacity() <= 0) {
            return "Capacity must be greater than zero";
        }
        
        return null; // No errors
    }
}
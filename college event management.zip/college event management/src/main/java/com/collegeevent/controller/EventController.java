package main.java.com.collegeevent.controller;

import main.java.com.collegeevent.dao.EventDAO;
import main.java.com.collegeevent.dao.RegistrationDAO;
import main.java.com.collegeevent.model.Event;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * Controller class for Event-related operations
 */
public class EventController {
    private final EventDAO eventDAO;
    private final RegistrationDAO registrationDAO;
    
    /**
     * Constructor
     */
    public EventController() {
        this.eventDAO = new EventDAO();
        this.registrationDAO = new RegistrationDAO();
    }
    
    /**
     * Create a new event
     * @param eventName Name of the event
     * @param description Description of the event
     * @param eventDate Date of the event
     * @param startTime Start time of the event
     * @param endTime End time of the event
     * @param venueId ID of the venue
     * @param organizer Organizer of the event
     * @param maxParticipants Maximum number of participants
     * @param registrationDeadline Registration deadline
     * @param eventStatus Status of the event
     * @return The created event with ID
     * @throws SQLException if database operation fails
     */
    public Event createEvent(String eventName, String description, LocalDate eventDate,
                           LocalTime startTime, LocalTime endTime, int venueId,
                           String organizer, int maxParticipants,
                           LocalDate registrationDeadline, String eventStatus) throws SQLException {
        
        Event event = new Event(eventName, description, eventDate, startTime, endTime,
                              venueId, organizer, maxParticipants, registrationDeadline, eventStatus);
        
        return eventDAO.createEvent(event);
    }
    
    /**
     * Get event by ID
     * @param eventId ID of the event to retrieve
     * @return Event object or null if not found
     * @throws SQLException if database operation fails
     */
    public Event getEventById(int eventId) throws SQLException {
        return eventDAO.getEventById(eventId);
    }
    
    /**
     * Get all events
     * @return List of all events
     * @throws SQLException if database operation fails
     */
    public List<Event> getAllEvents() throws SQLException {
        return eventDAO.getAllEvents();
    }
    
    /**
     * Get upcoming events
     * @return List of upcoming events
     * @throws SQLException if database operation fails
     */
    public List<Event> getUpcomingEvents() throws SQLException {
        return eventDAO.getUpcomingEvents();
    }
    
    /**
     * Update an event
     * @param event Event object to update
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateEvent(Event event) throws SQLException {
        return eventDAO.updateEvent(event);
    }
    
    /**
     * Delete an event
     * @param eventId ID of the event to delete
     * @return true if deleted successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean deleteEvent(int eventId) throws SQLException {
        return eventDAO.deleteEvent(eventId);
    }
    
    /**
     * Search events by name, description, or organizer
     * @param searchTerm Term to search for
     * @return List of matching events
     * @throws SQLException if database operation fails
     */
    public List<Event> searchEvents(String searchTerm) throws SQLException {
        return eventDAO.searchEvents(searchTerm);
    }
    
    /**
     * Get events by venue
     * @param venueId ID of the venue
     * @return List of events at the venue
     * @throws SQLException if database operation fails
     */
    public List<Event> getEventsByVenue(int venueId) throws SQLException {
        return eventDAO.getEventsByVenue(venueId);
    }
    
    /**
     * Check if an event is full
     * @param eventId ID of the event
     * @return true if event is full, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean isEventFull(int eventId) throws SQLException {
        Event event = eventDAO.getEventById(eventId);
        if (event == null) {
            throw new IllegalArgumentException("Event not found with ID: " + eventId);
        }
        
        int currentRegistrations = registrationDAO.getRegistrationCountForEvent(eventId);
        return currentRegistrations >= event.getMaxParticipants();
    }
    
    /**
     * Check if event registration is open
     * @param eventId ID of the event
     * @return true if registration is open, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean isRegistrationOpen(int eventId) throws SQLException {
        Event event = eventDAO.getEventById(eventId);
        if (event == null) {
            throw new IllegalArgumentException("Event not found with ID: " + eventId);
        }
        
        LocalDate today = LocalDate.now();
        return !today.isAfter(event.getRegistrationDeadline()) && 
               !"Completed".equals(event.getEventStatus()) && 
               !"Cancelled".equals(event.getEventStatus());
    }
    
    /**
     * Update event status
     * @param eventId ID of the event
     * @param newStatus New status for the event
     * @return true if updated successfully, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean updateEventStatus(int eventId, String newStatus) throws SQLException {
        Event event = eventDAO.getEventById(eventId);
        if (event == null) {
            throw new IllegalArgumentException("Event not found with ID: " + eventId);
        }
        
        event.setEventStatus(newStatus);
        return eventDAO.updateEvent(event);
    }
}